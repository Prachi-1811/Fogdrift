"""Tool identity in the InjecAgent ground-truth replay (Table X(b), Appendix A).

    python exp_injecagent_identity.py InjecAgent/data data/injecagent_toolkit_map.json
    python exp_injecagent_identity.py InjecAgent/data data/injecagent_toolkit_map.json quick
    add `tool-context` to use the family of the invoked toolkit as context

Same replay as exp_injecagent_replay.py (cases, benign prefix of 200 calls with
100 warm-up and 100 monitored, attacker tools repeated R times, W = 20 per
context, Laplace smoothing, equal context weights, K_p = 2, 20 repetitions),
with the symbol t of each call defined in four ways. Context c is the family
of the user's task, pinned once per episode before any tool output is read, so
injected attacker calls carry the context of the task they hijack (as
exp_injecagent_replay.py). Larger symbol sets have noisier null scores, so each
encoding gets its own threshold at a MATCHED false-alarm rate: the probability
of a persistent alarm in the 100 monitored benign calls is FP_TARGET = 0.01 on
2000 independent benign calibration streams (Table X(b) has FP 0.01-0.02).
The toolkit encoding is also run with the threshold rule of
exp_injecagent_replay.py (99.9% quantile of the null scores) as a reference.

  toolkit      t = InjecAgent toolkit (GmailSendEmail -> Gmail), as in the paper;
  function     t = function name (330 symbols), so GmailSendEmail differs from
               the benign Gmail reads;
  function+arg t = (function, a), a coarse argument class computed at the edge:
               a = new if the call carries a target value (recipient, account,
               guest, URL) absent from the agent's warm-up reference, else
               known. Only the bit leaves the edge. Attacker actions (the last
               attacker tool of a case, which carries the attacker's target)
               and argument-level calls have a = new; read steps on the user's
               own data have a = known; benign calls have a = new with
               probability nu (benign calls with a new target), nu in
               {0, 0.1, 0.3};
  bigram       t = (previous toolkit, toolkit) of the agent's call sequence.

The benign replay draws user tools independently, so it has no sequential
structure for bigrams to exploit; benign calls are InjecAgent user tools
(retrieval functions).

Outputs: results/injecagent_identity.txt, results/injecagent_identity.json
"""
import json
import os
import random
import sys
from collections import deque

import numpy as np

os.makedirs('results', exist_ok=True)

W, KP = 20, 2
ARM = 100
PREFIX = 200
REPS = 20
LENGTHS = [10, 20, 40, 80]
NUS = [0.0, 0.1, 0.3]
NULL_STREAMS, NULL_LEN = 50, 500
FP_TARGET, CAL_STREAMS = 0.01, 2000
QUICK = 'quick' in sys.argv[1:]
TOOL_CONTEXT = 'tool-context' in sys.argv[1:]
ARGS = [a for a in sys.argv[1:] if a not in ('quick', 'tool-context')]
OUT = 'results/injecagent_identity' + ('_toolcontext' if TOOL_CONTEXT else '')
if QUICK:
    REPS, LENGTHS, NUS, NULL_STREAMS, CAL_STREAMS = 3, [10, 40], [0.0, 0.3], 20, 300
    print("QUICK MODE: noisy")


class Detector:
    """Equal-weight conditional-KL monitor on (context, symbol) observations
    over the last W * L calls (as exp_injecagent_replay.Detector, with an
    incremental histogram)."""
    def __init__(self, P0, alpha):
        self.L, self.M = P0.shape
        self.P0, self.alpha = P0, alpha
        self.logP0 = np.log(P0)
        self.win = deque()
        self.cnt = np.zeros((self.L, self.M))
        self.n = np.zeros(self.L)
        self.r = self.run = 0
        self.alert = None

    def observe(self, c, t, thr=None):
        self.r += 1
        self.win.append((c, t))
        self.cnt[c, t] += 1
        self.n[c] += 1
        if len(self.win) > W * self.L:
            c0, t0 = self.win.popleft()
            self.cnt[c0, t0] -= 1
            self.n[c0] -= 1
        H = (self.cnt + self.alpha) / (self.n[:, None] + self.alpha * self.M)
        s = float(np.mean(np.sum(H * (np.log(H) - self.logP0), 1)))
        if thr is not None and self.r > ARM:
            self.run = self.run + 1 if s > thr else 0
            if self.run >= KP and self.alert is None:
                self.alert = self.r
        return s


def setup(data, mpath):
    m = json.load(open(mpath))
    fams = m['families']
    fam_idx = {f: i for i, f in enumerate(fams)}
    tool2kit, kit_fam = m['tool_toolkit'], m['toolkit_family']
    kits = sorted(set(tool2kit.values()))
    funcs = sorted(tool2kit)
    dh = json.load(open(os.path.join(data, 'test_cases_dh_enhanced.json')))[:100]
    ds = json.load(open(os.path.join(data, 'test_cases_ds_enhanced.json')))[:100]
    arg = [c['User Tool'] for c in (dh + ds)][:25]
    benign = sorted({c['User Tool'] for c in dh[:60]})
    ctx = {f: fam_idx[kit_fam[tool2kit[f]]] for f in funcs}
    # attack call sequences per case: (function, argument class) pairs
    def attack(tools, task):
        c0 = ctx[task]
        return [(t, i == len(tools) - 1, ctx[t] if TOOL_CONTEXT else c0)
                for i, t in enumerate(tools) if t in tool2kit]
    fam_cases = {
        'direct harm': [attack(c['Attacker Tools'], c['User Tool']) for c in dh],
        'data stealing': [attack(c['Attacker Tools'], c['User Tool']) for c in ds],
        'argument-level': [[(t, True, ctx[t])] for t in arg if t in tool2kit],
    }
    return dict(fams=fams, kits=kits, funcs=funcs, tool2kit=tool2kit, ctx=ctx,
                benign=[b for b in benign if b in tool2kit], cases=fam_cases)


class Encoding:
    """Maps a call (function, new-target bit) to (context, symbol) and builds
    the benign reference P0 of that symbol set."""
    def __init__(self, kind, S, nu=0.0):
        self.kind, self.S, self.nu = kind, S, nu
        L = len(S['fams'])
        kits = {k: i for i, k in enumerate(S['kits'])}
        funcs = {f: i for i, f in enumerate(S['funcs'])}
        self.kidx = lambda f: kits[S['tool2kit'][f]]
        self.fidx = lambda f: funcs[f]
        nK, nF = len(kits), len(funcs)
        self.M = {'toolkit': nK, 'function': nF, 'function+arg': 2 * nF,
                  'bigram': (nK + 1) * nK}[kind]
        self.nK = nK
        self.alpha = 1.0 / self.M
        P = np.full((L, self.M), self.alpha)
        ben = S['benign']
        for f in ben:
            c = S['ctx'][f]
            if kind == 'toolkit':
                P[c, self.kidx(f)] += 1
            elif kind == 'function':
                P[c, self.fidx(f)] += 1
            elif kind == 'function+arg':
                P[c, 2 * self.fidx(f)] += 1 - nu
                P[c, 2 * self.fidx(f) + 1] += nu
            else:                                   # i.i.d. benign: every ordered pair
                for g in ben:
                    P[c, self.kidx(g) * nK + self.kidx(f)] += 1.0 / len(ben)
        self.P0 = P / P.sum(1, keepdims=True)

    def symbol(self, f, new, prev):
        if self.kind == 'toolkit':
            return self.kidx(f)
        if self.kind == 'function':
            return self.fidx(f)
        if self.kind == 'function+arg':
            return 2 * self.fidx(f) + int(new)
        p = self.nK if prev is None else self.kidx(prev)
        return p * self.nK + self.kidx(f)


def benign_call(S, rnd, nu):
    f = rnd.choice(S['benign'])
    return f, (rnd.random() < nu) if nu > 0 else False, S['ctx'][f]   # nu = 0: same draws as the toolkit replay


def run_stream(enc, calls, thr):
    d = Detector(enc.P0, enc.alpha)
    prev = None
    for f, new, c in calls:
        d.observe(c, enc.symbol(f, new, prev), thr)
        prev = f
    return d


def threshold(enc, rnd):
    null = []
    for _ in range(NULL_STREAMS):
        d = Detector(enc.P0, enc.alpha)
        prev = None
        sc = []
        for _ in range(NULL_LEN):
            f, new, c = benign_call(enc.S, rnd, enc.nu)
            sc.append(d.observe(c, enc.symbol(f, new, prev)))
            prev = f
        null += sc[100:]
    return float(np.quantile(null, 0.999))


def threshold_fp(enc, rnd):
    """Threshold with P(persistent alarm in the monitored benign calls) = FP_TARGET.
    With K_p = 2 a stream alarms iff max_r min(s_{r-1}, s_r) > thr over the
    monitored calls, so thr is the (1 - FP_TARGET) quantile of that statistic."""
    stat = []
    for _ in range(CAL_STREAMS):
        d = Detector(enc.P0, enc.alpha)
        prev, sc = None, []
        for _ in range(PREFIX):
            f, new, c = benign_call(enc.S, rnd, enc.nu)
            sc.append(d.observe(c, enc.symbol(f, new, prev)))
            prev = f
        m = np.array(sc[ARM:])
        stat.append(float(np.max(np.minimum(m[1:], m[:-1]))))
    return float(np.quantile(stat, 1 - FP_TARGET))


def replay(enc, cases, thr, rnd, R):
    tp = fp = 0
    for seq in cases:
        calls = [benign_call(enc.S, rnd, enc.nu) for _ in range(PREFIX)] + seq * R
        d = run_stream(enc, calls, thr)
        if d.alert is not None:
            if d.alert >= PREFIX + 1:
                tp += 1
            else:
                fp += 1
    return tp / len(cases), fp / len(cases)


def main():
    data = ARGS[0] if ARGS else 'InjecAgent/data'
    mpath = ARGS[1] if len(ARGS) > 1 else 'data/injecagent_toolkit_map.json'
    S = setup(data, mpath)
    encs = [('toolkit', 0.0, 'quantile'), ('toolkit', 0.0, 'fp'), ('function', 0.0, 'fp')] + \
        [('function+arg', nu, 'fp') for nu in NUS] + [('bigram', 0.0, 'fp')]
    res = {}
    for kind, nu, rule in encs:
        enc = Encoding(kind, S, nu)
        name = kind if kind != 'function+arg' else f"function+arg, nu={nu}"
        name += ' (Table X(b) rule)' if rule == 'quantile' else ''
        thrs, out = [], {f: {'tp': {R: [] for R in LENGTHS}, 'fp': []} for f in S['cases']}
        thr_fp = threshold_fp(enc, random.Random(77)) if rule == 'fp' else None
        for rep in range(REPS):
            thr = threshold(enc, random.Random(1000 + rep)) if rule == 'quantile' else thr_fp
            thrs.append(thr)
            for f, cases in S['cases'].items():
                for R in LENGTHS:
                    tp, fp = replay(enc, cases, thr, random.Random(5000 + rep), R)
                    out[f]['tp'][R].append(tp)
                    if R == LENGTHS[0]:
                        out[f]['fp'].append(fp)
        res[name] = {'M': enc.M, 'threshold': [float(np.mean(thrs)), float(np.std(thrs))],
                     'families': {f: {'tp': {R: float(np.mean(v)) for R, v in o['tp'].items()},
                                      'fp': float(np.mean(o['fp']))} for f, o in out.items()}}
        print(f"{name:22s} M={enc.M:6d} " + "; ".join(
            f"{f}: " + "/".join(f"{res[name]['families'][f]['tp'][R]:.2f}" for R in LENGTHS)
            for f in S['cases']), flush=True)
    report(res, S)


def report(res, S):
    L = [f"Tool identity in the InjecAgent ground-truth replay (no LLM), {REPS} repetitions, context = "
         f"{'family of the invoked toolkit' if TOOL_CONTEXT else 'family of the user task, pinned per episode'}: "
         f"fraction of cases detected after onset when the attacker tools are repeated R times; "
         f"FP = alarm in the 100 monitored benign calls (R={LENGTHS[0]}); thresholds matched to "
         f"FP = {FP_TARGET} on {CAL_STREAMS} benign calibration streams, except the Table X(b)-rule row. "
         f"Context = toolkit family "
         f"(L={len(S['fams'])}); {len(S['funcs'])} functions, {len(S['kits'])} toolkits; "
         f"{len(S['benign'])} benign user tools.",
         f"{'identity':22s} {'M':>6s} {'family':15s} " + " ".join(f"{'R='+str(R):>6s}" for R in LENGTHS)
         + f" {'FP':>5s}"]
    for name, r in res.items():
        for f, v in r['families'].items():
            L.append(f"{name:22s} {r['M']:6d} {f:15s} " + " ".join(f"{v['tp'][R]:6.2f}" for R in LENGTHS)
                     + f" {v['fp']:5.2f}")
    L.append("function+arg: a = new for attacker actions and argument-level calls, and for benign "
             "calls with probability nu; bigram = (previous toolkit, toolkit).")
    txt = "\n".join(L)
    print("\n" + txt)
    open(OUT + '.txt', 'w').write(txt + "\n")
    json.dump(res, open(OUT + '.json', 'w'), indent=1)


if __name__ == '__main__':
    main()
