"""Scalar and sequential baselines: input stream, calibration parity (Table IV).

    python exp_scalar_parity.py          # ~15 min
    python exp_scalar_parity.py quick    # ~4 min, noisy

In Table IV, ADWIN, Page-Hinkley and DDM run on the pooled conditional-KL
stream: the fleet keeps the last W calls of every (agent, context) (raw
traces), the counts are pooled over the agents, and Eq. (1) is evaluated with
equal context weights and the fog minimum-sample rule (fogdrift_core.FleetPool,
fleet_cond_kl). They are therefore stopping rules on FogDrift's conditional
statistic, not marginal detectors. DDM never alarmed on held-out null data and
ran at threshold 0, and multinomial CUSUM, whose reference value nu_c is
estimated from the 50 warm-up rounds of each run, had a held-out ARL of 2485.

This script, on its own calibration (10 x 5000 rounds), held-out
(10 x 5000 rounds, stationary and with a fresh pi ~ Dir(2) every 100 rounds)
and detection streams (30 seeds per scenario, m = 0.5, onset after 60 rounds,
100 drift rounds), computes per round from the same pooled windows:
  cond   the pooled conditional KL of Table IV
  marg   the unconditional KL of the fleet's tool histogram over the last
         W_pi = 20 rounds (uncapped, so it follows the context mixture)
         against the warm-up marginal sum_c pi0_c P0(t | c)
and evaluates, each with a threshold bisected to ARL0 = 1000 on the
calibration streams:
  ADWIN, Page-Hinkley         on cond (Table IV) and on marg
  DDM, q95                    on cond, Table IV mapping (x > warm-up 95% quantile)
  DDM, q50                    on cond, mapping at the warm-up median
  DDM, q95, 200-round window  on cond, p and s over the last 200 rounds
  CUSUM, per-run nu           Table IV (nu_c = warm-up mean + 1 sd, per run)
  CUSUM, pooled nu            nu = mean + 1 sd of the increments of all
                              calibration rounds, fixed for every run
Reported: calibration and held-out ARL, delay per scenario, and the share of
runs with an alarm within 100 rounds after a pure workload shift
(pi: uniform -> [0.10, 0.40, 0.10, 0.40], P(t | c) unchanged, 30 seeds).

Outputs: results/scalar_parity.txt, results/scalar_parity.json
"""
import json
import os
import sys
import time

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
BURN = 30
ROUNDS = 5000
CAL_SEEDS = list(range(8000, 8010))
VAL_SEEDS = list(range(8100, 8110))
RUN_SEEDS = list(range(8200, 8230))
PRE, POST = 60, 100
SCEN = ['policy', 'prompt', 'deprec']
if QUICK:
    CAL_SEEDS, VAL_SEEDS, ROUNDS, RUN_SEEDS = CAL_SEEDS[:3], VAL_SEEDS[:3], 1500, RUN_SEEDS[:8]
    print("QUICK MODE: noisy")
CFG = fc.DEFAULT                       # the scalar baselines use the default config
UNIFORM = np.full(CFG.L, 1.0 / CFG.L)
SHIFT = np.array([0.10, 0.40, 0.10, 0.40])
WARM_FILL = 15                         # warm-up rounds before the pooled windows are full
DDM_MIN_N = 30                         # DDM tracks its minimum only after 30 rounds (Gama et al.)
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def stream(seed, rounds, scenario=None, m=0.5, onset=None, sched=None):
    """Per-round cond, marg, CUSUM increments (L,), and warm-up values."""
    rng = np.random.default_rng(seed)
    Pt = fc.build_P0(rng, CFG)
    P0 = fc.estimate_P0(rng, Pt, UNIFORM, CFG)
    Pm = UNIFORM @ P0                                      # warm-up marginal
    cus = fc.MultinomialCUSUM(P0, CFG)
    warm_cond, warm_marg, warm_inc, warm_cond1 = [], [], [], []
    wpool = fc.FleetPool(P0, CFG)
    ring = []
    for w in range(CFG.W0):                                # clean reference rounds
        cs, ts = fc.gen_round(rng, Pt, UNIFORM, CFG)
        cnt1, _ = fc._pool_counts(cs, ts, CFG)
        warm_cond1.append(fc.fleet_cond_kl(cnt1, cnt1.sum(-1), P0, CFG))   # Table IV mapping
        cnt, pic = wpool.step(cs, ts)
        ring = (ring + [cnt1.sum(0)])[-CFG.W_PI:]
        if w >= WARM_FILL:                                 # windows full: same scale as monitoring
            warm_cond.append(fc.fleet_cond_kl(cnt, pic, P0, CFG))
        if len(ring) == CFG.W_PI:
            warm_marg.append(marg_kl(ring, Pm))
        warm_inc.append(cus._inc(cs, ts))
    pool = fc.FleetPool(P0, CFG)
    Pd = fc.drifted(Pt, scenario, m, seed) if scenario else None
    cond, marg, inc = [], [], []
    for r in range(rounds):
        P = Pd if scenario and r >= onset else Pt
        pi = sched(r) if sched else UNIFORM
        cs, ts = fc.gen_round(rng, P, pi, CFG)
        cnt, pic = pool.step(cs, ts)
        cond.append(fc.fleet_cond_kl(cnt, pic, P0, CFG))
        ring = (ring + [fc._pool_counts(cs, ts, CFG)[0].sum(0)])[-CFG.W_PI:]
        marg.append(marg_kl(ring, Pm))
        inc.append(cus._inc(cs, ts))
    return {'cond': np.array(cond), 'marg': np.array(marg), 'inc': np.array(inc),
            'warm_cond': np.array(warm_cond), 'warm_marg': np.array(warm_marg),
            'warm_cond1': np.array(warm_cond1),
            'warm_inc': np.array(warm_inc)}


def marg_kl(ring, Pm):
    p = fc.smooth(np.sum(ring, 0), CFG)
    return float(np.sum(p * np.log(p / Pm)))


def run_scalar(det, x):
    return np.array([det.update(v) for v in x])


class DDM:
    """DDM on a 0/1 stream: p, s cumulative (win=None) or over the last `win`
    rounds; the minimum of p + s is tracked once DDM_MIN_N rounds are seen."""
    def __init__(self, win=None):
        self.win, self.h = win, []
        self.pmin = self.smin = np.inf

    def update(self, b):
        self.h.append(b)
        h = self.h if self.win is None else self.h[-self.win:]
        n = len(h)
        p = sum(h) / n
        s = np.sqrt(p * (1 - p) / n)
        if len(self.h) < DDM_MIN_N:
            return 0.0
        if p + s < self.pmin + self.smin:
            self.pmin, self.smin = p, s
        return max(0.0, (p + s) - (self.pmin + self.smin))


def ddm_scores(s, key, q, win=None, warm='warm_cond'):
    thr = float(np.quantile(s[warm], q))
    b = (s[key] > thr).astype(float)
    if warm == 'warm_cond1':                               # Table IV implementation
        d = fc.DDMBinary()
        d.q = 0.5
        return run_scalar(d, b)
    d = DDM(win)
    return np.array([d.update(v) for v in b])


def cusum_scores(inc, nu):
    S = np.zeros(inc.shape[1])
    out = np.empty(len(inc))
    for r, x in enumerate(inc):
        S = np.maximum(0.0, S + x - nu)
        out[r] = S.max()
    return out


def scores(s, nu_pool):
    w = s['warm_inc']
    return {
        'ADWIN (cond)': run_scalar(fc.ADWINScalar(), s['cond']),
        'Page-Hinkley (cond)': run_scalar(fc.PageHinkley(), s['cond']),
        'ADWIN (marg)': run_scalar(fc.ADWINScalar(), s['marg']),
        'Page-Hinkley (marg)': run_scalar(fc.PageHinkley(), s['marg']),
        'DDM, Table IV mapping (cond)': ddm_scores(s, 'cond', 0.95, warm='warm_cond1'),
        'DDM q95 (cond)': ddm_scores(s, 'cond', 0.95),
        'DDM q50 (cond)': ddm_scores(s, 'cond', 0.50),
        'DDM q95, 200-round window (cond)': ddm_scores(s, 'cond', 0.95, 200),
        'CUSUM, per-run nu': cusum_scores(s['inc'], w.mean(0) + w.std(0)),
        'CUSUM, pooled nu': cusum_scores(s['inc'], nu_pool),
    }


def arl(xs, thr):
    return fx.arl_of([fc.endpoint_scalar(x[BURN:], thr, KP)[0] for x in xs])


def calibrate(xs):
    allx = np.concatenate([x[BURN:] for x in xs])
    lo = max(float(np.quantile(allx, 0.90)), 1e-9)
    hi = float(allx.max()) * 3 + 1e-6
    if arl(xs, lo)[0] >= T:
        return lo if np.isfinite(arl(xs, lo)[0]) else None
    for _ in range(40):
        mid = np.sqrt(lo * hi)
        if arl(xs, mid)[0] < T:
            lo = mid
        else:
            hi = mid
    return hi


def main():
    cal = [stream(s, ROUNDS) for s in CAL_SEEDS]
    nu_pool = float(np.concatenate([c['inc'][BURN:].ravel() for c in cal]).mean() +
                    np.concatenate([c['inc'][BURN:].ravel() for c in cal]).std())
    log(f"calibration streams done, pooled nu = {nu_pool:.3f}")
    res_map = {'single_round_q95': float(np.mean([np.quantile(c['warm_cond1'], 0.95) for c in cal])),
               'window_q95': float(np.mean([np.quantile(c['warm_cond'], 0.95) for c in cal])),
               'monitored_median': float(np.mean([np.median(c['cond'][BURN:]) for c in cal]))}
    cal_sc = [scores(c, nu_pool) for c in cal]
    names = list(cal_sc[0])
    res = {'nu_pool': nu_pool, 'ddm_mapping': res_map, 'det': {}}
    thr = {}
    for k in names:
        thr[k] = calibrate([c[k] for c in cal_sc])
        a = arl([c[k] for c in cal_sc], thr[k]) if thr[k] is not None else (np.nan, 0, 0)
        res['det'][k] = {'thr': thr[k], 'cal_ARL': a[0]}
        log(f"{k}: thr {thr[k]}, calibration ARL {a[0]}")
    for cond in ('stationary', 'workload drift'):
        val = []
        for s in VAL_SEEDS:
            sched = None
            if cond == 'workload drift':
                wr = np.random.default_rng(s + 300_000)
                pis = [wr.dirichlet(np.full(CFG.L, 2.0)) for _ in range(ROUNDS // 100 + 1)]
                sched = lambda r, pis=pis: pis[r // 100]
            val.append(scores(stream(s, ROUNDS, sched=sched), nu_pool))
        for k in names:
            if thr[k] is None:
                res['det'][k][cond] = None
                continue
            a = arl([v[k] for v in val], thr[k])
            lo, hi = fx.poisson_ci(a[1], a[2])
            res['det'][k][cond] = {'ARL': a[0], 'events': a[1], 'lo': lo, 'hi': hi}
        log(f"held-out {cond} done")
    for sc in SCEN + ['workload shift']:
        d = {k: [] for k in names}
        for s in RUN_SEEDS:
            if sc == 'workload shift':
                st = stream(s, PRE + POST, sched=lambda r: UNIFORM if r < PRE else SHIFT)
            else:
                st = stream(s, PRE + POST, scenario=sc, onset=PRE)
            sg = scores(st, nu_pool)
            for k in names:
                if thr[k] is None:
                    d[k].append(None)
                    continue
                a, stb, sr = fc.endpoint_scalar(sg[k], thr[k], KP)
                d[k].append(fc.detection_delay(stb, sr, PRE, KP))
        for k in names:
            res['det'][k][sc] = {'median': fx.med(d[k]), 'n': len(d[k]),
                                 'detected': sum(x is not None for x in d[k])}
        log(f"{sc} done")
    txt = report(res, names)
    print(txt)
    open('results/scalar_parity.txt', 'w').write(txt + "\n")
    json.dump(res, open('results/scalar_parity.json', 'w'), indent=2, default=float)


def report(res, names):
    L = ["Scalar and sequential baselines on the pooled raw-trace windows (fleet level). cond = "
         "pooled conditional KL of Table IV; marg = KL of the fleet tool histogram over the last 20 rounds (uncapped) against the "
         f"warm-up marginal. Thresholds bisected to ARL0 = {T} on {len(CAL_SEEDS)} x {ROUNDS} "
         f"calibration rounds; pooled CUSUM nu = {res['nu_pool']:.3f}.",
         "DDM mapping (mean over calibration seeds): 95% quantile of single-round warm-up scores "
         f"(Table IV) {res['ddm_mapping']['single_round_q95']:.4f}; of pooled-window warm-up scores "
         f"{res['ddm_mapping']['window_q95']:.4f}; median monitored score "
         f"{res['ddm_mapping']['monitored_median']:.4f}.", "",
         f"(a) ARL, held-out {len(VAL_SEEDS)} x {ROUNDS} rounds after a {BURN}-round burn-in "
         "[95% CI] (events)",
         f"{'detector':34s} {'thr':>9s} {'cal':>6s} {'stationary':>26s} {'workload drift':>26s}"]
    for k in names:
        r = res['det'][k]
        if r['thr'] is None:
            L.append(f"{k:34s} {'none':>9s}  (no threshold reaches the target ARL)")
            continue
        c = [f"{r[x]['ARL']:.0f} [{r[x]['lo']:.0f}, {r[x]['hi']:.0f}] ({r[x]['events']})"
             for x in ('stationary', 'workload drift')]
        L.append(f"{k:34s} {r['thr']:9.4g} {r['cal_ARL']:6.0f} {c[0]:>26s} {c[1]:>26s}")
    L += ["", f"(b) Delay, m = 0.5, onset after {PRE} rounds, {len(RUN_SEEDS)} seeds: median rounds "
          "(detected/runs); workload shift: runs with an alarm within 100 rounds of a pure "
          "workload shift (false alarms)",
          f"{'detector':34s} " + " ".join(f"{s:>13s}" for s in SCEN) + f" {'workload shift':>15s}"]
    for k in names:
        r = res['det'][k]
        if r['thr'] is None:
            continue
        L.append(f"{k:34s} " + " ".join(
            f"{fx.fmt(r[s]['median'], 1)} ({r[s]['detected']}/{r[s]['n']})".rjust(13) for s in SCEN) +
            f" {r['workload shift']['detected']:>9d}/{r['workload shift']['n']}")
    return "\n".join(L)


if __name__ == '__main__':
    main()
