"""Adaptive attacks (Table VIII), attack-magnitude sweep (Sec. V-H) and
reference poisoning (Sec. V-K).

    python exp_adaptive.py          # ~8 min
    python exp_adaptive.py quick    # ~1.5 min (sanity only)

Needs edge_params.json and calibration.json (calibrate.py).

Every attack is run against FogDrift AND against the same detector with the
event trigger switched off (Centralised-Histogram: every agent reports every
round). If an attack evades both, the evasion is caused by the size of the
distribution shift, not by the trigger.
Thresholds = matched ARL0 = 1000 from calibrate.py, calibrated on a CLEAN
reference; for reference poisoning this is optimistic for the defender.

Attack definitions (drift starts at onset, policy poisoning unless noted):
  K1 baseline   m = 0.5 on every agent
  AA1           tiny shift: +0.024 probability mass on the suspicious tool
                (threshold-aware attack), every agent
  AA2           m = 0.5 on even rounds only, clean on odd rounds
  AA3           m = 0.5 except every T_hb-th round (clean when heartbeats fire)
  AA4           m = 0.5 in context 0 only, context 0 carries 10 % of the workload
  AA5           m = 0.5 on ONE agent (q = 1)
  AA6           linear ramp from 0 to m = 0.5 over 30 rounds
  AA7           10 % of warm-up rounds poisoned, then m = 0.5
  AA8           AA1 on ONE agent
Outputs: results/adaptive.txt, results/adaptive.png,
         results/reference_poisoning.png
"""
import json
import os
import sys
import time
from dataclasses import fields
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

SEEDS = list(range(300, 330))
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS = list(range(600, 605))
    print("QUICK MODE: numbers are noisy")
KP = fc.DEFAULT.KP
DETS = ['FogDrift', 'Cent-Hist']


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def aa1(Pt):
    Pd = Pt.copy()
    Pd[:, 6] += 0.024
    return Pd / Pd.sum(1, keepdims=True)


def rare_ctx(Pt):
    Pd = Pt.copy()
    Pd[0] = fc.policy_poison(Pt, 0.5)[0]
    return Pd


def aa8(r, Pt, Pd):
    """AA1 distribution on the compromised agent(s) only."""
    full = np.broadcast_to(Pt, Pd.shape)
    comp = ~np.isclose(Pd, full).all(axis=(1, 2))
    out = full.copy()
    out[comp] = aa1(Pt)
    return out


THB = fc.DEFAULT.THB
ATTACKS = {
    'K1 baseline': dict(scenario='policy', m=0.5),
    'AA1 tiny shift': dict(scenario='policy', m=0.5, attack=lambda r, Pt, Pd: aa1(Pt)),
    'AA2 alternating': dict(scenario='policy', m=0.5,
                            attack=lambda r, Pt, Pd: Pd if r % 2 == 0 else Pt),
    'AA3 heartbeat-timed': dict(scenario='policy', m=0.5,
                                attack=lambda r, Pt, Pd: Pt if r % THB == THB - 1 else Pd),
    'AA4 rare context': dict(scenario='policy', m=0.5, pi_c=np.array([0.1, 0.3, 0.3, 0.3]),
                             attack=lambda r, Pt, Pd: rare_ctx(Pt)),
    'AA5 one agent': dict(scenario='policy', m=0.5, q=1),
    'AA6 slow ramp': dict(scenario='policy', m=0.5,
                          attack=lambda r, Pt, Pd: fc.policy_poison(Pt, 0.5 * min(1, (r + 1) / 30))),
    'AA7 ref-poison 10%': dict(scenario='policy', m=0.5, warm_poison=0.10),
    'AA8 tiny + one agent': dict(scenario='policy', m=0.5, q=1, attack=aa8),
}
MAGS = [0.05, 0.10, 0.15, 0.25, 0.50]
ALPHAS = [0.0, 0.10, 0.25, 0.50]


def aa3_alignment(cfg, seeds, pre=60, post=100):
    """Heartbeat transmissions after onset, and how many fall on AA3's clean rounds."""
    hb = clean = 0
    pi = np.full(cfg.L, 1.0 / cfg.L)
    for seed in seeds:
        rng = np.random.default_rng(seed)
        Pt = fc.build_P0(rng, cfg)
        P0 = fc.estimate_P0(rng, Pt, pi, cfg)
        Pd = fc.policy_poison(Pt, 0.5)
        det = fc.HCDD(P0, cfg)
        for r in range(pre + post):
            k = r - pre
            is_clean = k >= 0 and k % cfg.THB == cfg.THB - 1
            before = det.tx_cause['hb']
            det.step(*fc.gen_round(rng, Pt if k < 0 or is_clean else Pd, pi, cfg))
            if k >= 0:
                n = det.tx_cause['hb'] - before
                hb += n
                clean += n if is_clean else 0
    return hb, clean


def run_set(cfg, th, kw):
    out = {d: [] for d in DETS}
    extra = {'Cent-Hist': lambda P0, c: fc.HCDD(P0, c, trigger=False, name='Cent-Hist')}
    for seed in SEEDS:
        o = fc.run_stream(seed, fd_cfg=cfg, base_dets=False, scalars=False,
                          keep_agent=False, extra=extra, pre=60, post=100, **kw)
        for d in DETS:
            _, st, sr = fc.endpoint_fog(o[d], th[d]['tau_a'], th[d]['tau_l'], KP)
            out[d].append(fc.detection_delay(st, sr, o['onset'], KP))
    return out


def stats(v):
    x = np.array([np.inf if a is None else a for a in v], float)
    det = np.isfinite(x)
    rate = det.mean()
    med = float(np.median(x[det])) if det.any() else np.nan     # median over detected runs
    return rate, med


def fmt(rate, med):
    return f"{100*rate:5.0f}%  {'-' if np.isnan(med) else f'{med:5.1f}':>5s}"


def main():
    t0 = time.time()
    cfg = load_cfg()
    th = json.load(open('calibration.json'))['1000']
    L = []
    P = L.append
    res = {}
    for name, kw in ATTACKS.items():
        res[name] = run_set(cfg, th, kw)
        print(f"[{(time.time()-t0)/60:4.1f} min] {name}", flush=True)
    base = {d: stats(res['K1 baseline'][d])[1] for d in DETS}
    P(f"Table VIII: adaptive attacks at matched ARL0 = 1000, {len(SEEDS)} seeds")
    P("rate = detected within 100 rounds; delay = median over detected runs (rounds); "
      "slowdown = delay / K1 delay of the same detector")
    P(f"{'attack':22s} {'FogDrift rate  delay  slow':>28s}   {'trigger off (Cent-Hist)':>28s}")
    for name in ATTACKS:
        row = f"{name:22s}"
        for d in DETS:
            r, m = stats(res[name][d])
            sd = '-' if np.isnan(m) else f"{m / base[d]:.1f}x"
            row += f"   {fmt(r, m)} {sd:>6s}     "
        P(row)
    P("")

    mag = {}
    for m in MAGS:
        mag[m] = run_set(cfg, th, dict(scenario='policy', m=m))
    print(f"[{(time.time()-t0)/60:4.1f} min] magnitude sweep", flush=True)
    P(f"Policy-poisoning magnitude sweep (Sec. V-H), {len(SEEDS)} seeds")
    P(f"{'m':>5s} {'FogDrift rate  delay':>22s}   {'Cent-Hist rate  delay':>22s}")
    for m in MAGS:
        P(f"{m:5.2f}   " + "   ".join(fmt(*stats(mag[m][d])) for d in DETS))
    P("")

    poi = {}
    for a in ALPHAS:
        poi[a] = run_set(cfg, th, dict(scenario='policy', m=0.5, warm_poison=a))
    print(f"[{(time.time()-t0)/60:4.1f} min] reference poisoning", flush=True)
    P(f"Reference poisoning (Sec. V-K), fraction beta of warm-up rounds drawn from "
      f"the attack, then m = 0.5; thresholds from a clean reference (optimistic), "
      f"{len(SEEDS)} seeds")
    P(f"{'beta':>5s} {'FogDrift rate  delay':>22s}   {'Cent-Hist rate  delay':>22s}")
    for a in ALPHAS:
        P(f"{a:5.2f}   " + "   ".join(fmt(*stats(poi[a][d])) for d in DETS))
    P("")
    hb, clean = aa3_alignment(cfg, SEEDS[:10])
    P(f"AA3: of {hb} heartbeat transmissions after onset ({min(10, len(SEEDS))} runs), {clean} fell "
      f"on a clean round (the trigger moves heartbeats under drift)")
    txt = "\n".join(L)
    print("\n" + txt)
    open('results/adaptive.txt', 'w').write(txt + "\n")

    plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})
    names = list(ATTACKS)
    short = [n.split(' ')[0] for n in names]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.3))
    w = 0.38
    xs = np.arange(len(names))
    for i, d in enumerate(DETS):
        rr = [100 * stats(res[n][d])[0] for n in names]
        dd = [stats(res[n][d])[1] for n in names]
        a1.bar(xs + (i - .5) * w, rr, w, label=d if d == 'FogDrift' else 'trigger off',
               edgecolor='black', linewidth=.5)
        a2.bar(xs + (i - .5) * w, [0 if np.isnan(v) else v for v in dd], w,
               edgecolor='black', linewidth=.5)
        for x, v in zip(xs + (i - .5) * w, dd):
            if np.isnan(v):
                a2.text(x, 1, 'none\ndetected', ha='center', fontsize=6, rotation=90)
    for a in (a1, a2):
        a.set_xticks(xs); a.set_xticklabels(short); a.grid(axis='y', alpha=.3, ls='--')
    a1.set_ylabel('Detected within 100 rounds (%)'); a1.set_ylim(0, 115); a1.legend(fontsize=8, loc='upper center', ncol=2)
    a2.set_ylabel('Median delay of detected runs (rounds)')
    plt.tight_layout(); plt.savefig('results/adaptive.png', dpi=200)

    fig, a1 = plt.subplots(figsize=(7, 4.3))
    a2 = a1.twinx()
    al = np.array(ALPHAS) * 100
    r = [100 * stats(poi[a]['FogDrift'])[0] for a in ALPHAS]
    dl = [stats(poi[a]['FogDrift'])[1] for a in ALPHAS]
    a1.plot(al, [np.nan if np.isnan(v) else v for v in dl], 'o-', color='tab:blue',
            label='delay (detected runs)')
    for x, v in zip(al, dl):
        if np.isnan(v):
            a1.plot(x, 0, 'x', color='tab:blue', ms=9)
            a1.annotate('no detection', (x, 0), xytext=(-30, 8), textcoords='offset points',
                        fontsize=8, color='tab:blue')
    a2.plot(al, r, 's--', color='tab:red', label='detection rate')
    a1.set_xlabel(r'Poisoned warm-up fraction $\alpha$ (%)')
    a1.set_ylabel('Median delay (rounds)', color='tab:blue')
    a2.set_ylabel('Detected within 100 rounds (%)', color='tab:red')
    a2.set_ylim(0, 105); a1.set_ylim(bottom=0); a1.grid(alpha=.3, ls='--')
    plt.tight_layout(); plt.savefig('results/reference_poisoning.png', dpi=200)
    print(f"\nSaved results/adaptive.txt, adaptive.png, reference_poisoning.png "
          f"[{(time.time()-t0)/60:.1f} min]")


if __name__ == '__main__':
    main()
