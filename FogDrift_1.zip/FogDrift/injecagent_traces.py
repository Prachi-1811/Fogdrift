"""InjecAgent ground-truth cases as episode traces for the fleet replay.

    git clone https://github.com/uiuc-kang-lab/InjecAgent
    python injecagent_traces.py InjecAgent/data data/injecagent_toolkit_map.json
    python exp_agentdojo_replay.py data/injecagent_gt_dh.jsonl data/injecagent_gt_ds.jsonl

Writes the cases used by exp_injecagent_replay.py in the trace format of
agentdojo_collect.py, so that they run through the same 50-agent HCDD fleet
(edge trigger, tracker, heartbeats, fog tiers, matched ARL0 calibration) as
the AgentDojo traces. No LLM is involved: an attacked episode assumes that
the agent follows the injection.
  * Context ('suite' field) = documented family of the case's user tool,
    fixed for the whole episode, attacker calls included.
  * Tool identity = InjecAgent toolkit.
  * Benign episodes: one call to each distinct user tool of the 200 cases
    (17 tools in 5 families; no user tool belongs to 'home').
  * Attacked episodes: the user tool call followed by the case's attacker
    tools (direct harm: 1 call; data stealing: 2 calls), security = True.
Outputs: data/injecagent_gt_dh.jsonl (direct harm), data/injecagent_gt_ds.jsonl
(data stealing); the benign episodes are in both files.
"""
import json
import os
import sys


def main(data, mpath):
    m = json.load(open(mpath))
    t2k, kfam = m['tool_toolkit'], m['toolkit_family']
    dh = json.load(open(os.path.join(data, 'test_cases_dh_enhanced.json')))[:100]
    ds = json.load(open(os.path.join(data, 'test_cases_ds_enhanced.json')))[:100]
    users = sorted({c['User Tool'] for c in dh + ds})

    def rec(model, user_tool, attacker, case):
        kits = [t2k[t] for t in [user_tool] + list(attacker) if t in t2k]
        att = [t2k[t] for t in attacker if t in t2k]
        return {'model': model, 'suite': kfam[t2k[user_tool]], 'user_task': user_tool,
                'injection_task': case, 'attack': 'injecagent-enhanced' if case else None,
                'rep': 0, 'utility': None, 'security': True if case else None,
                'calls': kits, 'args': [], 'n_calls': len(kits),
                'harm_tools': sorted(set(att)), 'user_gt_tools': [t2k[user_tool]],
                'error': None, 'benchmark_version': 'injecagent', 'source': 'InjecAgent ground truth'}

    os.makedirs('data', exist_ok=True)
    for tag, cases in (('dh', dh), ('ds', ds)):
        model = 'injecagent-direct-harm' if tag == 'dh' else 'injecagent-data-stealing'
        out = f'data/injecagent_gt_{tag}.jsonl'
        with open(out, 'w') as fh:
            for u in users:
                fh.write(json.dumps(rec(model, u, [], None)) + "\n")
            for i, c in enumerate(cases):
                fh.write(json.dumps(rec(model, c['User Tool'], c['Attacker Tools'], f'case_{i}')) + "\n")
        print(f"{out}: {len(users)} benign, {len(cases)} attacked episodes")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else 'data/injecagent_toolkit_map.json')
