"""Fog aggregate under partial coverage (Sec. III-C, III-F; Alg. 1, lines 12-17).

    python exp_partial_coverage.py          # ~25 min
    python exp_partial_coverage.py quick    # ~3 min, noisy

The fog computes per-agent scores and top-k for every agent with a fresh
summary, and the aggregate score only when every member is fresh
(MIN_COV = 1). A single silent agent therefore switches the aggregate branch
off for its fog. Here k agents of every fog are silent for the whole stream
(their link is down, so their summaries never arrive), and the aggregate is
computed under three rules; tau_a and the full-coverage tau_l are the
matched-ARL thresholds of calibration.json (target 1000):
  full coverage   MIN_COV = 1 (paper): aggregate off while a member is silent
  partial         MIN_COV = 0.8: aggregate over the fresh members if at
                  least 8 of 10 are fresh, with the full-coverage tau_l
  partial, tau_l(n_fresh)
                  as partial, with tau_l chosen by the number of fresh
                  members: tau_l(10) = full-coverage tau_l, tau_l(9) and
                  tau_l(8) bisected so that the any-fog ARL with 1 or 2
                  silent agents per fog is 1000 on 10 x 5000 calibration
                  rounds (seeds disjoint from the held-out ones)
k = 0 checks that the rules agree with every agent fresh.

Reported: held-out ARL after a 30-round burn-in (any-fog endpoint,
10 x 5000 rounds); detection delay of policy poisoning at m = 0.15 and
m = 0.05 on every agent and of a +0.024 shift on every agent (30 seeds,
onset at round 60; silent agents' calls are drifted too but never seen).

Outputs: results/partial_coverage.txt, results/partial_coverage.json
"""
import json
import os
import sys
import time
from dataclasses import fields, replace

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
BURN = 30
ROUNDS = 5000
CAL_SEEDS = list(range(6500, 6510))
NULL_SEEDS = list(range(6300, 6310))
RUN_SEEDS = list(range(6400, 6430))
PRE, POST = 60, 100
SILENT = [0, 1, 2]
if QUICK:
    CAL_SEEDS, NULL_SEEDS, ROUNDS, RUN_SEEDS = CAL_SEEDS[:3], NULL_SEEDS[:3], 1500, RUN_SEEDS[:8]
    print("QUICK MODE: noisy")
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


CFG = load_cfg()
TH = json.load(open('calibration.json'))[str(T)]['FogDrift']
TA, TL = TH['tau_a'], TH['tau_l']
PER = CFG.N // CFG.F
FOG_OF = np.arange(CFG.N) % CFG.F
UNIFORM = np.full(CFG.L, 1.0 / CFG.L)
RULES = ['full coverage', 'partial', 'partial, tau_l(n_fresh)']


def stream(seed, rounds, k, onset=None, m=0.5, attack=None):
    rng = np.random.default_rng(seed)
    Pt = fc.build_P0(rng, CFG)
    P0 = fc.estimate_P0(rng, Pt, UNIFORM, CFG)
    dets = {'full coverage': fc.HCDD(P0, CFG),
            'partial': fc.HCDD(P0, replace(CFG, MIN_COV=0.8))}
    up = np.ones(CFG.N, bool)
    for f in range(CFG.F):                       # first k members of every fog
        up[np.flatnonzero(FOG_OF == f)[:k]] = False
    Pd = fc.drifted(Pt, 'policy', m, seed) if onset is not None else None
    sig = {r: {'fog_score': [], 'fog_amax': [], 'fog_has': [], 'n_fresh': []} for r in dets}
    for r in range(rounds):
        P = Pt
        if onset is not None and r >= onset:
            P = Pd if attack is None else attack(Pt)
        cs, ts = fc.gen_round(rng, P, UNIFORM, CFG)
        for name, d in dets.items():
            o = d.step(cs, ts, up)
            o['n_fresh'] = np.bincount(FOG_OF[(d.r - d.fts) <= CFG.TFRESH], minlength=CFG.F)
            for key in sig[name]:
                sig[name][key].append(o[key])
    out = {r: {k2: np.array(v) for k2, v in s.items()} for r, s in sig.items()}
    out['partial, tau_l(n_fresh)'] = out['partial']
    return out


def endpoint(sig, rule, tl_by_fresh):
    """Any-fog endpoint; the last rule picks tau_l by the number of fresh members."""
    if rule != 'partial, tau_l(n_fresh)':
        return fc.endpoint_fog(sig, TA, TL, KP)
    tl = np.vectorize(lambda n: tl_by_fresh.get(int(n), np.inf))(sig['n_fresh'])
    raw = ((sig['fog_score'] > tl) | (sig['fog_amax'] > TA)) & sig['fog_has']
    st, sr = fc.stable_alarm(raw, KP)
    return st.any(1), st, sr


def calibrate_tl(k):
    """tau_l for PER - k fresh members: any-fog ARL = T with k silent per fog."""
    streams = [fx.trim(stream(s, ROUNDS, k)['partial'], BURN) for s in CAL_SEEDS]
    lo, hi = TL, 3 * TL
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        al = [endpoint(sg, 'partial, tau_l(n_fresh)', {PER - k: mid})[0] for sg in streams]
        if fx.arl_of(al)[0] < T:
            lo = mid
        else:
            hi = mid
    return hi


def tiny(Pt):
    Pd = Pt.copy()
    Pd[:, 6] += 0.024
    return Pd / Pd.sum(1, keepdims=True)


ATTACKS = [('m=0.15', dict(m=0.15)), ('m=0.05', dict(m=0.05)),
           ('tiny shift (+0.024)', dict(m=0.5, attack=tiny))]


def main():
    tl_by_fresh = {PER: TL}
    for k in SILENT[1:]:
        tl_by_fresh[PER - k] = calibrate_tl(k)
        log(f"tau_l({PER - k} fresh) = {tl_by_fresh[PER - k]:.4f}")
    res = {'tau_l_by_fresh': {str(n): v for n, v in tl_by_fresh.items()}, 'null': {}, 'delay': {}}
    for k in SILENT:
        streams = [stream(s, ROUNDS, k) for s in NULL_SEEDS]
        res['null'][k] = {}
        for rule in RULES:
            al = [endpoint(fx.trim(sg[rule], BURN), rule, tl_by_fresh)[0] for sg in streams]
            arl, ev, n = fx.arl_of(al)
            lo, hi = fx.poisson_ci(ev, n)
            res['null'][k][rule] = {'ARL': arl, 'events': ev, 'rounds': n, 'lo': lo, 'hi': hi}
        log(f"null k={k}: {res['null'][k]}")
        res['delay'][k] = {}
        for name, kw in ATTACKS:
            d = {r: [] for r in RULES}
            for s in RUN_SEEDS:
                sg = stream(s, PRE + POST, k, onset=PRE, **kw)
                for rule in RULES:
                    _, st, sr = endpoint(sg[rule], rule, tl_by_fresh)
                    d[rule].append(fc.detection_delay(st, sr, PRE, KP))
            res['delay'][k][name] = {r: {'median': fx.med(v), 'n': len(v),
                                         'detected': sum(x is not None for x in v)}
                                     for r, v in d.items()}
            log(f"delay k={k} {name}: {res['delay'][k][name]}")
    txt = report(res)
    print(txt)
    open('results/partial_coverage.txt', 'w').write(txt + "\n")
    json.dump(res, open('results/partial_coverage.json', 'w'), indent=2, default=float)


def report(res):
    tl = res['tau_l_by_fresh']
    L = [f"Fog aggregate with k silent agents in every fog ({PER} agents per fog). Calibrated "
         f"edge parameters and full-coverage thresholds (tau_a = {TA:.3f}, tau_l = {TL:.4f}, "
         f"ARL0 = {T}). full coverage: MIN_COV = 1 (paper); partial: MIN_COV = 0.8 with the "
         "full-coverage tau_l; partial, tau_l(n_fresh): tau_l by number of fresh members, "
         "calibrated with k silent agents per fog: " +
         ", ".join(f"tau_l({n}) = {v:.4f}" for n, v in sorted(tl.items(), reverse=True)) + ".", "",
         f"(a) Held-out ARL after a {BURN}-round burn-in, {len(NULL_SEEDS)} x {ROUNDS} rounds: "
         "ARL [95% CI] (events)",
         f"{'k':>2s} " + " ".join(f"{r:>28s}" for r in RULES)]
    for k, row in res['null'].items():
        L.append(f"{k:>2} " + " ".join(
            f"{row[r]['ARL']:.0f} [{row[r]['lo']:.0f}, {row[r]['hi']:.0f}] ({row[r]['events']})".rjust(28)
            for r in RULES))
    L += ["", f"(b) Detection delay, onset at round {PRE}, {len(RUN_SEEDS)} seeds: "
          "median rounds (detected / runs)",
          f"{'k':>2s} {'attack':22s} " + " ".join(f"{r:>24s}" for r in RULES)]
    for k, rows in res['delay'].items():
        for name, row in rows.items():
            L.append(f"{k:>2} {name:22s} " + " ".join(
                f"{fx.fmt(row[r]['median'], 1)} ({row[r]['detected']}/{row[r]['n']})".rjust(24)
                for r in RULES))
    return "\n".join(L)


if __name__ == '__main__':
    main()
