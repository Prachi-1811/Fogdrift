"""Partial compromise and localisation (Table V).

    python exp_localisation.py          # ~6 min
    python exp_localisation.py quick    # ~1 min

Needs edge_params.json and calibration.json (calibrate.py).

q of the 50 agents are compromised (policy poisoning m = 0.5), the rest stay
clean. At the round of the first operator-visible alarm, agents are ranked by
their per-agent conditional score as held at the fog/cloud:
  precision@5 = |top-5 ∩ compromised| / 5           (at most min(q, 5) / 5: 0.2 for q = 1)
  recall@5    = |top-5 ∩ compromised| / q           (at most min(q, 5) / q: 0.5 for q = 10)
  top-1       = 1 if the highest-scoring agent is compromised
  MRR         = 1 / rank of the highest-ranked compromised agent
FogDrift ranks from its (event-triggered) stored summaries; Centralised-
Histogram from summaries sent every round; Centralised-Tuples (B=5) from the
tuples received so far. Localisation is scored only on detected runs.
Output: results/localisation.txt
"""
import json
import os
import sys
from dataclasses import fields
import numpy as np
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

SEEDS = list(range(300, 330))
QS = [1, 5, 10]
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS = list(range(900, 905))
KP = fc.DEFAULT.KP
DETS = ['FogDrift', 'Cent-Hist', 'CT(B=5)']


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def main():
    cfg = load_cfg()
    th = json.load(open('calibration.json'))['1000']
    extra = {'Cent-Hist': lambda P0, c: fc.HCDD(P0, c, trigger=False, name='Cent-Hist'),
             'CT(B=5)': lambda P0, c: fc.CentralTuples(P0, c, B=5)}
    L = [f"Table V: partial compromise and localisation, policy poisoning m=0.5, "
         f"matched ARL0=1000, {len(SEEDS)} seeds per q",
         "localisation metrics at the first alarm, mean over detected runs",
         f"{'q':>3s} {'detector':10s} {'det':>6s} {'delay':>6s} {'prec@5':>7s} {'rec@5':>7s} "
         f"{'top-1':>6s} {'MRR':>6s}"]
    ties, ranked = 0, 0
    for q in QS:
        acc = {d: {'delay': [], 'p5': [], 'r5': [], 't1': [], 'mrr': []} for d in DETS}
        fogs = []
        for seed in SEEDS:
            out = fc.run_stream(seed, fd_cfg=cfg, base_dets=False, scalars=False,
                                keep_agent=True, extra=extra, scenario='policy', m=0.5,
                                q=q, pre=60, post=100)
            comp = set(out['compromised'].tolist())
            fogs.append(len({i % cfg.F for i in comp}))
            on = out['onset']
            for d in DETS:
                t = th[d]
                _, st, sr = fc.endpoint_fog(out[d], t['tau_a'], t['tau_l'], KP)
                dl = fc.detection_delay(st, sr, on, KP)
                a = acc[d]
                a['delay'].append(dl)
                if dl is None:
                    continue
                score = out[d]['agent'][on + dl - 1]
                if d == 'FogDrift':
                    nz = score[score > 0]
                    ranked += 1
                    ties += int(len(np.unique(nz)) < len(nz))
                order = np.argsort(-score)
                top5 = set(order[:5].tolist())
                hit = len(top5 & comp)
                a['p5'].append(hit / 5)
                a['r5'].append(hit / q)
                a['t1'].append(float(order[0] in comp))
                rank = next(k for k, i in enumerate(order, 1) if i in comp)
                a['mrr'].append(1 / rank)
        for d in DETS:
            a = acc[d]
            x = np.array([np.inf if v is None else v for v in a['delay']], float)
            det = np.isfinite(x)
            md = f"{np.median(x[det]):.1f}" if det.any() else '-'
            m = lambda k: f"{np.mean(a[k]):.2f}" if a[k] else '-'
            L.append(f"{q:3d} {d:10s} {det.sum():3d}/{len(x):<2d} {md:>6s} {m('p5'):>7s} "
                     f"{m('r5'):>7s} {m('t1'):>6s} {m('mrr'):>6s}")
        L.append(f"    compromised agents fall in {np.mean(fogs):.2f} of {cfg.F} fogs on average")
        L.append("")
    L.append(f"FogDrift runs with tied non-zero agent scores at the first alarm: {ties} of {ranked}")
    txt = "\n".join(L)
    print(txt)
    open('results/localisation.txt', 'w').write(txt + "\n")


if __name__ == '__main__':
    main()
