"""Episode-level contexts and asynchronous calls (Sec. IV, simulator realism).

    python exp_episode_workload.py          # ~45 min
    python exp_episode_workload.py quick    # ~4 min, noisy

The core simulator draws the context of every call independently and gives
every agent K = 8 calls per round. Here an agent stays in one context for a
whole episode, and its number of calls per round varies:
  i.i.d. (paper)      K = 8 calls per round, context i.i.d. per call
  episodes            all calls of a round in the agent's current context;
                      the agent starts a new episode (context drawn from pi)
                      with probability 1/E per round, E = 5 rounds (~40 calls)
  episodes, long      as episodes with E = 20 rounds (~160 calls)
  episodes + async    as episodes (E = 5), calls per round ~ Poisson(8),
                      at most 24
The tools of a call are drawn from P(t | c) as before; agents are independent.

For each workload:
(a) window filling: rounds until every context of an agent has n_min = 10
    and W = 20 calls in its window (median and 90th percentile over agents),
    and the share of agents with all windows at n_min after the 30-round
    burn-in;
(b) null ARL after a 400-round burn-in, long enough for full windows under
    every workload (any-fog endpoint, 10 x 5000 held-out rounds)
    at the paper's thresholds (calibration.json), and with tau_a, tau_l
    scaled by one factor recalibrated on that workload (10 x 5000
    calibration rounds, seeds disjoint);
(c) detection delay at the paper's and at the recalibrated thresholds, 30 seeds, onset after 400
    rounds so that windows are full: policy poisoning m = 0.5 and m = 0.15 on
    every agent, and m = 0.5 on 5 agents.

Outputs: results/episode_workload.txt, results/episode_workload.json
"""
import json
import os
import sys
import time
from dataclasses import fields

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
BURN = 30                          # paper's burn-in (fill share reported at it)
SETTLE = 400                       # burn-in used here: windows full under every workload
ROUNDS = 5000
CAL_SEEDS = list(range(7100, 7110))
VAL_SEEDS = list(range(7200, 7210))
RUN_SEEDS = list(range(7300, 7330))
PRE, POST = SETTLE, 100
KMAX = 24
if QUICK:
    CAL_SEEDS, VAL_SEEDS, ROUNDS, RUN_SEEDS = CAL_SEEDS[:3], VAL_SEEDS[:3], 1500, RUN_SEEDS[:8]
    print("QUICK MODE: noisy")
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


CFG = load_cfg()
TH = json.load(open('calibration.json'))[str(T)]['FogDrift']
TA0, TL0 = TH['tau_a'], TH['tau_l']
UNIFORM = np.full(CFG.L, 1.0 / CFG.L)
WORKLOADS = {'i.i.d. (paper)': None,
             'episodes': dict(E=5, poisson=False),
             'episodes, long': dict(E=20, poisson=False),
             'episodes + async': dict(E=5, poisson=True)}


class VarWindows(fc.Windows):
    """Windows that accept padded rounds: tool -1 marks no call."""
    def add_round(self, cs, ts):
        ev = [(cs[i][ts[i] >= 0], ts[i][ts[i] >= 0]) for i in range(cs.shape[0])]
        self.add_events(ev)


class Workload:
    def __init__(self, spec, rng):
        self.spec, self.rng = spec, rng
        self.ctx = rng.choice(CFG.L, CFG.N, p=UNIFORM)

    def round(self, P):
        if self.spec is None:
            return fc.gen_round(self.rng, P, UNIFORM, CFG)
        rng, N = self.rng, CFG.N
        new = rng.random(N) < 1.0 / self.spec['E']
        self.ctx[new] = rng.choice(CFG.L, new.sum(), p=UNIFORM)
        k = np.minimum(rng.poisson(CFG.K, N), KMAX) if self.spec['poisson'] \
            else np.full(N, CFG.K)
        width = KMAX if self.spec['poisson'] else CFG.K
        cs = np.repeat(self.ctx[:, None], width, axis=1)
        Pa = np.broadcast_to(P, (N, CFG.L, CFG.M)) if P.ndim == 2 else P
        rows = np.cumsum(Pa, -1)[np.arange(N)[:, None], cs]
        ts = np.minimum((rng.random((N, width))[..., None] > rows).sum(-1), CFG.M - 1)
        ts[np.arange(width)[None, :] >= k[:, None]] = -1
        return cs, ts


def stream(seed, spec, rounds, onset=None, m=0.5, q=None, fill=False):
    rng = np.random.default_rng(seed)
    Pt = fc.build_P0(rng, CFG)
    wl = Workload(spec, rng)
    cnt = np.zeros((CFG.L, CFG.M))
    for _ in range(CFG.W0):                         # warm-up under the same workload
        cs, ts = wl.round(Pt)
        ok = ts >= 0
        np.add.at(cnt, (cs[ok], ts[ok]), 1)
    P0 = fc.smooth(cnt, CFG)
    det = fc.HCDD(P0, CFG)
    if spec is not None:
        det.win = VarWindows(CFG)
    Pd = None
    if onset is not None:
        Pd = fc.drifted(Pt, 'policy', m, seed)
        if q is not None:
            Pa = np.broadcast_to(Pt, (CFG.N, CFG.L, CFG.M)).copy()
            Pa[np.random.default_rng(seed + 7).choice(CFG.N, q, replace=False)] = Pd
            Pd = Pa
    sig = {'fog_score': [], 'fog_amax': [], 'fog_has': []}
    t_min = np.full(CFG.N, -1)
    t_w = np.full(CFG.N, -1)
    for r in range(rounds):
        P = Pd if onset is not None and r >= onset else Pt
        o = det.step(*wl.round(P))
        for k in sig:
            sig[k].append(o[k])
        if fill:
            f = det.win.fill
            t_min[(t_min < 0) & (f >= CFG.NMIN_AGENT).all(1)] = r + 1
            t_w[(t_w < 0) & (f >= CFG.W).all(1)] = r + 1
    out = {k: np.array(v) for k, v in sig.items()}
    if fill:
        out['t_min'], out['t_w'] = t_min, t_w
    return out


def arl(streams, g):
    al = [fc.endpoint_fog(fx.trim(s, SETTLE), TA0 * g, TL0 * g, KP)[0] for s in streams]
    return fx.arl_of(al)


def calibrate(streams):
    lo, hi = 0.5, 3.0
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if arl(streams, mid)[0] < T:
            lo = mid
        else:
            hi = mid
    return hi


def pct(x, q):
    x = np.where(x < 0, np.inf, x).astype(float)
    return float(np.percentile(x, q))


def main():
    res = {}
    for name, spec in WORKLOADS.items():
        cal = [stream(s, spec, ROUNDS) for s in CAL_SEEDS]
        val = [stream(s, spec, ROUNDS, fill=True) for s in VAL_SEEDS]
        t_min = np.concatenate([v['t_min'] for v in val])
        t_w = np.concatenate([v['t_w'] for v in val])
        g = calibrate(cal)
        a_paper, a_cal = arl(val, 1.0), arl(val, g)
        r = {'fill': {'nmin_median': pct(t_min, 50), 'nmin_p90': pct(t_min, 90),
                      'W_median': pct(t_w, 50), 'W_p90': pct(t_w, 90),
                      'share_nmin_at_burn': float(np.mean((t_min > 0) & (t_min <= BURN)))},
             'factor': g}
        for key, a in (('paper', a_paper), ('recal', a_cal)):
            lo, hi = fx.poisson_ci(a[1], a[2])
            r[key] = {'ARL': a[0], 'events': a[1], 'lo': lo, 'hi': hi}
        log(f"{name}: {r}")
        r['delay'] = {}
        for case, kw in (('m=0.5', dict(m=0.5)), ('m=0.15', dict(m=0.15)),
                         ('m=0.5, 5 agents', dict(m=0.5, q=5))):
            d = {'paper': [], 'recal': []}
            for s in RUN_SEEDS:
                sg = stream(s, spec, PRE + POST, onset=PRE, **kw)
                for key, f in (('paper', 1.0), ('recal', g)):
                    _, st, sr = fc.endpoint_fog(sg, TA0 * f, TL0 * f, KP)
                    d[key].append(fc.detection_delay(st, sr, PRE, KP))
            r['delay'][case] = {key: {'median': fx.med(v), 'n': len(v),
                                      'detected': sum(x is not None for x in v)}
                                for key, v in d.items()}
        log(f"{name} delay: {r['delay']}")
        res[name] = r
    txt = report(res)
    print(txt)
    open('results/episode_workload.txt', 'w').write(txt + "\n")
    json.dump(res, open('results/episode_workload.json', 'w'), indent=2, default=float)


def report(res):
    L = [f"Episode-level contexts and asynchronous calls. Calibrated edge parameters; paper "
         f"thresholds tau_a = {TA0:.3f}, tau_l = {TL0:.4f} (ARL0 = {T}); recal = both scaled by "
         f"one factor calibrated on the workload. ARLs after a {SETTLE}-round burn-in; delays with onset after {PRE} rounds, {len(RUN_SEEDS)} seeds.", "",
         "(a) Rounds until all contexts of an agent reach n_min = 10 / W = 20 calls "
         f"(median, 90th percentile over agents); share of agents at n_min after the paper's {BURN}-round burn-in",
         f"{'workload':18s} {'n_min med':>9s} {'p90':>6s} {'W med':>6s} {'p90':>6s} {'at burn-in':>10s}"]
    for n, r in res.items():
        f = r['fill']
        L.append(f"{n:18s} {f['nmin_median']:9.0f} {f['nmin_p90']:6.0f} {f['W_median']:6.0f} "
                 f"{f['W_p90']:6.0f} {f['share_nmin_at_burn']:10.2f}")
    L += ["", f"(b) Held-out ARL after the {SETTLE}-round burn-in ({len(VAL_SEEDS)} x {ROUNDS} rounds): "
          "ARL [95% CI] (events)",
          f"{'workload':18s} {'paper thresholds':>28s} {'factor':>7s} {'recalibrated':>28s}"]
    for n, r in res.items():
        c = [f"{r[k]['ARL']:.0f} [{r[k]['lo']:.0f}, {r[k]['hi']:.0f}] ({r[k]['events']})"
             for k in ('paper', 'recal')]
        L.append(f"{n:18s} {c[0]:>28s} {r['factor']:7.3f} {c[1]:>28s}")
    for key, title in (('paper', 'paper thresholds'), ('recal', 'recalibrated thresholds')):
        L += ["", f"(c) Detection delay, policy poisoning, {title}: median rounds (detected/runs)",
              f"{'workload':18s} {'m=0.5':>14s} {'m=0.15':>14s} {'m=0.5, 5 agents':>16s}"]
        for n, r in res.items():
            d = r['delay']
            L.append(f"{n:18s} " + " ".join(
                f"{fx.fmt(d[c][key]['median'], 1)} ({d[c][key]['detected']}/{d[c][key]['n']})".rjust(w)
                for c, w in (('m=0.5', 14), ('m=0.15', 14), ('m=0.5, 5 agents', 16))))
    return "\n".join(L)


if __name__ == '__main__':
    main()
