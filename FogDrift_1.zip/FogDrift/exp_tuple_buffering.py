"""Tuple baselines with a bounded, drop-oldest buffer (Sec. V-F, V-G).

    python exp_tuple_buffering.py          # ~45 min
    python exp_tuple_buffering.py quick    # ~6 min, noisy

In Tables VI and VII the tuple baselines keep every unsent tuple: a FIFO
queue under the byte cap and a retransmission buffer with acknowledgement
(both capped at 5000 tuples per agent). A histogram summary, in contrast,
replaces the previous one. Here the tuple baselines keep only the W = 20 most
recent unsent tuples of each context (`buffer='ring'`), at most L*W = 80
tuples per agent. Older tuples would leave the cloud's per-context window
anyway, so the ring loses no window state. Everything else (seeds, harness,
uncapped matched thresholds from calibration.json) is that of the original
experiment:
  (a) per-fog uplink byte cap         exp_bandwidth_cap.py   Table VII(a), Fig. 6
      FIFO, ring drained oldest first, ring drained newest first; null FA
      events per 1000 rounds under each cap (3 x 2000 rounds)
  (b) cap 0.25 KB, onset after 30, 60 or 120 monitored rounds
  (c) random dropout with ACK         exp_dropout.py         Table VI
  (d) 16-round outage of all links    exp_dropout.py         Sec. V-F
  (e) one fog down for o rounds       exp_deployment_stress.py  Table VII(b)
The FIFO rows rerun the paper's configuration.

Outputs: results/tuple_buffering.txt, results/tuple_buffering.json
"""
import json
import os
import sys
import time

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx
import exp_bandwidth_cap as ebc
import exp_dropout as edr
import exp_deployment_stress as eds

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
N_SEEDS = 6 if QUICK else 30
if QUICK:
    ebc.NULL_SEEDS, ebc.NULL_ROUNDS = ebc.NULL_SEEDS[:1], 800
    edr.NULL_SEEDS, edr.NULL_ROUNDS = edr.NULL_SEEDS[:1], 800
    print("QUICK MODE: noisy")
KP = fc.DEFAULT.KP
T0 = time.time()
BUFS = {'FIFO': dict(buffer='fifo'), 'ring': dict(buffer='ring'),
        'ring, newest first': dict(buffer='ring', drain='newest')}


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def med(v):
    return float(np.median([np.inf if a is None else a for a in v]))


def f(x):
    return 'cens' if x is None or not np.isfinite(x) else f"{x:.1f}"


# ---------------------------------------------------------------- (a), (b) byte cap
def capped_make(det, P0, cfg, uplink):
    """det = 'CT(B=b)|<buffer>' or a histogram detector of exp_bandwidth_cap."""
    if '|' not in det:
        return MAKE0(det, P0, cfg, uplink)
    name, buf = det.split('|')
    B = int(name.split('=')[1].rstrip(')'))
    return fx.CappedCT(P0, cfg, B, uplink, **BUFS[buf])


MAKE0 = ebc.make
ebc.make = capped_make


def cap_runs(cfg, cal, det, cap, pre=None):
    th = cal[det.split('|')[0]]
    pre0 = ebc.PRE
    if pre is not None:
        ebc.PRE = pre
    runs = [ebc.one_run(det, cfg, th, s, cap) for s in ebc.SEEDS[:N_SEEDS]]
    ebc.PRE = pre0
    d = [r[0] for r in runs]
    qd = [r[3] for r in runs if r[3] is not None]
    return {'delay': med(d), 'detected': sum(x is not None for x in d), 'n': len(d),
            'qdelay': float(np.mean(qd)) if qd else None,
            'drop': float(np.mean([r[4] for r in runs])),
            'up_pre': float(np.mean([r[5][0] for r in runs]))}


def part_a(cfg, cal):
    res = {}
    for cap in ebc.CAPS:
        for B in (1, 5):
            for buf in BUFS:
                det = f'CT(B={B})|{buf}'
                r = cap_runs(cfg, cal, det, cap)
                r['FA_per_1k'], r['FA_events'], r['FA_rounds'] = ebc.null_fa(
                    det, cfg, cal[f'CT(B={B})'], cap)
                res[f'{cap}|{det}'] = r
        log(f"(a) cap {cap} done")
    return res


def part_b(cfg, cal):
    res = {}
    for pre in (30, 60, 120):
        for det in ('FogDrift', 'CT(B=1)|FIFO', 'CT(B=1)|ring', 'CT(B=5)|FIFO', 'CT(B=5)|ring'):
            res[f'{pre}|{det}'] = cap_runs(cfg, cal, det, 0.25, pre=pre)
        log(f"(b) onset after {pre} rounds done")
    return res


# ---------------------------------------------------------------- (c), (d) dropout, burst
def ct(B, buf):
    return lambda P0, cfg: fc.CentralTuples(P0, cfg, B=B, ack=True, buffer=buf)


DROP_DETS = {f'CT(B={B})+ACK|{buf}': ct(B, buf) for B in (1, 5) for buf in ('fifo', 'ring')}


def th_of(cal, det):
    return cal[det.split('+')[0]]


def part_c(cfg, cal):
    edr.EXTRA = DROP_DETS
    res = {}
    for pi in edr.PIS:
        acc = {d: {'delay': [], 's0': [], 's1': []} for d in DROP_DETS}
        for seed in edr.SEEDS[:N_SEEDS]:
            out = edr.run(seed, cfg, scenario='policy', m=0.5, pre=edr.PRE, post=edr.POST, drop=pi)
            on = out['onset']
            for d in DROP_DETS:
                t = th_of(cal, d)
                _, st, sr = fc.endpoint_fog(out[d], t['tau_a'], t['tau_l'], KP)
                acc[d]['delay'].append(fc.detection_delay(st, sr, on, KP))
                s = edr.per_round(out[d]['sent'])
                acc[d]['s0'].append(s[:on].mean())
                acc[d]['s1'].append(s[on:].mean())
        fa = {d: [0, 0] for d in DROP_DETS}
        for seed in edr.NULL_SEEDS:
            out = edr.run(seed, cfg, scenario=None, pre=edr.NULL_ROUNDS, post=0, drop=pi)
            for d in DROP_DETS:
                t = th_of(cal, d)
                a = fc.endpoint_fog({k: v[30:] for k, v in out[d].items()
                                     if isinstance(v, np.ndarray)},
                                    t['tau_a'], t['tau_l'], KP)[0]
                fa[d][0] += fc.count_events(a)
                fa[d][1] += len(a)
        res[str(pi)] = {d: {'delay': med(a['delay']),
                            'detected': sum(x is not None for x in a['delay']),
                            'n': len(a['delay']), 'KB_pre': float(np.mean(a['s0'])),
                            'KB_att': float(np.mean(a['s1'])), 'null_FA': fa[d]}
                        for d, a in acc.items()}
        log(f"(c) p_d = {pi} done")
    return res


def part_d(cfg, cal):
    edr.EXTRA = DROP_DETS
    res = {}
    for name, (b0, b1) in edr.BURSTS.items():
        acc = {d: {'delay': [], 'steady': [], 'after': [], 'peak': []} for d in DROP_DETS}
        for seed in edr.SEEDS[:N_SEEDS]:
            out = edr.run(seed, cfg, scenario='policy', m=0.5, pre=edr.PRE, post=edr.POST,
                          burst=(b0, b1))
            on = out['onset']
            for d in DROP_DETS:
                t = th_of(cal, d)
                _, st, sr = fc.endpoint_fog(out[d], t['tau_a'], t['tau_l'], KP)
                acc[d]['delay'].append(fc.detection_delay(st, sr, on, KP))
                s = edr.per_round(out[d]['sent'])
                acc[d]['steady'].append(s[:on].mean())
                acc[d]['after'].append(s[on + b1:on + b1 + 10].mean())
                acc[d]['peak'].append(s[on + b1:on + b1 + 10].max())
        res[name] = {d: {'delay': med(a['delay']),
                         'detected': sum(x is not None for x in a['delay']),
                         'n': len(a['delay']), **{k: float(np.mean(a[k]))
                                                  for k in ('steady', 'after', 'peak')}}
                     for d, a in acc.items()}
        log(f"(d) {name} done")
    return res


# ---------------------------------------------------------------- (e) fog outage
def part_e(cfg, cal):
    res = {}
    for buf in ('fifo', 'ring'):
        make = lambda P0, b=buf: fc.CentralTuples(P0, cfg, B=5, ack=True, buffer=b)
        for o in (0, 8, 16):
            v = [eds.run_capped(make, cfg, s, cal['CT(B=5)'], outage=(0, o) if o else None)[0]
                 for s in eds.SEEDS[:N_SEEDS]]
            res[f'{buf}|{o}'] = {'delay': med(v), 'detected': sum(x is not None for x in v),
                                 'n': len(v)}
    log("(e) done")
    return res


# ---------------------------------------------------------------- report
def report(r):
    L = ["Tuple baselines with a bounded drop-oldest buffer: 'ring' keeps only the W = 20 most "
         "recent unsent tuples per context (at most 80 per agent); FIFO = paper (every unsent "
         f"tuple kept, cap 5000/agent). Uncapped matched ARL0 = 1000 thresholds, policy m = 0.5, "
         f"{N_SEEDS} seeds per cell, seeds of the original experiments. Delay: median rounds "
         "(detected/runs).", "",
         "(a) Per-fog uplink byte cap (Table VII(a)). qdelay = tuple backlog at onset in rounds "
         "of capacity; drop = share of generated tuples dropped from the buffer; FA/1k = null "
         f"alarm events per 1000 rounds ({len(ebc.NULL_SEEDS)} x {ebc.NULL_ROUNDS - 30} rounds after the "
         "burn-in), with the null ARL and its exact 95% Poisson CI.",
         f"{'cap':>5s} {'detector':28s} {'delay':>14s} {'qdelay':>7s} {'drop':>6s} {'FA/1k':>6s}"]
    for k, v in r['a'].items():
        cap, det = k.split('|', 1)
        qd = '-' if v['qdelay'] is None else f"{v['qdelay']:.1f}"
        L.append(f"{'none' if cap == 'None' else cap:>5s} {det:28s} "
                 f"{f(v['delay']) + ' (' + str(v['detected']) + '/' + str(v['n']) + ')':>14s} "
                 f"{qd:>7s} {v['drop']:6.3f} {v['FA_per_1k']:6.2f}  "
                 f"{ebc.arl_ci(v['FA_events'], v['FA_rounds'])}")
    L += ["", "(b) Cap 0.25 KB, onset after PRE monitored rounds: delay, qdelay"]
    for k, v in r['b'].items():
        pre, det = k.split('|', 1)
        qd = '-' if v['qdelay'] is None else f"{v['qdelay']:.1f}"
        L.append(f"  PRE={pre:>3s} {det:18s} {f(v['delay']):>6s} ({v['detected']}/{v['n']})  "
                 f"qdelay {qd}")
    L += ["", "(c) Random dropout with ACK (Table VI): delay; KB sent per round before / after "
          "onset (incl. lost, retransmitted, ACK); null FA events / rounds"]
    for pi, row in r['c'].items():
        for d, v in row.items():
            L.append(f"  p_d={pi:<5s} {d:18s} {f(v['delay']):>5s} ({v['detected']}/{v['n']})  "
                     f"KB {v['KB_pre']:5.2f} / {v['KB_att']:5.2f}  FA {v['null_FA'][0]}/{v['null_FA'][1]} "
                     f"{ebc.arl_ci(*v['null_FA'])}")
    L += ["", "(d) 16-round outage of all links: delay; KB per round steady / mean of the 10 rounds "
          "after the outage / peak round"]
    for name, row in r['d'].items():
        for d, v in row.items():
            L.append(f"  {name:26s} {d:18s} {f(v['delay']):>5s} ({v['detected']}/{v['n']})  "
                     f"{v['steady']:5.2f} {v['after']:6.2f} {v['peak']:6.2f}")
    L += ["", "(e) One fog down for the first o rounds of an attack on its agents (Table VII(b)), "
          "CT(B=5)+ACK"]
    for k, v in r['e'].items():
        buf, o = k.split('|')
        L.append(f"  {buf:5s} o={o:<3s} {f(v['delay']):>5s} ({v['detected']}/{v['n']})")
    return "\n".join(L)


def main():
    cfg = ebc.load_cfg()
    cal = json.load(open('calibration.json'))['1000']
    r = {'a': part_a(cfg, cal), 'b': part_b(cfg, cal), 'c': part_c(cfg, cal),
         'd': part_d(cfg, cal), 'e': part_e(cfg, cal)}
    txt = report(r)
    print(txt)
    open('results/tuple_buffering.txt', 'w').write(txt + "\n")
    json.dump(r, open('results/tuple_buffering.json', 'w'), indent=1, default=float)


if __name__ == '__main__':
    main()
