"""InjecAgent ground-truth replay (Table X(b), Fig. 7). No LLM is called.

    git clone https://github.com/uiuc-kang-lab/InjecAgent
    python exp_injecagent_replay.py InjecAgent/data data/injecagent_toolkit_map.json
    python exp_injecagent_replay.py InjecAgent/data data/injecagent_toolkit_map.json tool-context

InjecAgent attacker-tool sequences are replayed into the detector after a
benign prefix, to measure when a frequency-shift monitor catches them.
  * Tool identity is the InjecAgent TOOLKIT (e.g. GmailSendEmail -> Gmail),
    read from data/injecagent_toolkit_map.json.
  * Context is a documented toolkit family in that file (L = 6:
    communication, scheduling, files, finance, home, health), bound once per
    episode from the user's task, i.e. the family of the user tool the request
    asks for, before any tool output is read. Every call of an episode,
    including injected attacker calls, carries that context. With
    `tool-context` the context of each call is instead the family of the
    invoked toolkit (c is then a function of t), for comparison.
  * The detector is warmed up for ARM = 100 calls with no alarms (matching the
    null calibration); false alarms are then counted over 100 monitored benign
    calls; the attack starts after that.
Thresholds: 99.9 % quantile of the null score stream (per-observation ARL0
~ 1000), sliding window of the last W * L = 120 calls (W = 20 per context
on average), Laplace smoothing, equal context weights,
persistence K_p = 2. Every number is a mean over 20 repetitions.
Stream per case: PREFIX = 200 benign user-tool calls (first 100 warm-up, next
100 monitored) then the attacker tools of the case repeated R times (argument-
level cases: the case's own user tool repeated R times, so tool identity never
changes). Attack starts at observation PREFIX + 1.
Outputs: results/injecagent_replay.txt, results/injecagent_replay.png
"""
import json
import os
import random
import sys
from collections import deque
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

os.makedirs('results', exist_ok=True)

W, KP = 20, 2
ARM = 100
PREFIX = 200
REPS = 20
LENGTHS = [10, 20, 40, 80]


def load_mapping(path):
    m = json.load(open(path))
    fams = m['families']
    fam_idx = {f: i for i, f in enumerate(fams)}
    tool2kit = m['tool_toolkit']
    kit_fam = m['toolkit_family']
    L = len(fams)
    kits = sorted(set(tool2kit.values()))
    kit_idx = {k: i for i, k in enumerate(kits)}       # tool identity = toolkit
    M = len(kits)
    return fams, fam_idx, tool2kit, kit_fam, kit_idx, L, M


class Detector:
    """Equal-weight conditional-KL monitor on (family, toolkit) observations."""
    def __init__(self, benign_kits, L, M, kit_fam_idx):
        self.L, self.M = L, M
        self.alpha = 1.0 / M
        self.kf = kit_fam_idx                         # toolkit index -> family index
        cnt = np.full((L, M), self.alpha)
        for k in benign_kits:
            cnt[self.kf[k], k] += 1
        self.P0 = cnt / cnt.sum(1, keepdims=True)
        self.win = deque(maxlen=W * L)
        self.r = 0
        self.run = 0
        self.alert = None

    def observe(self, c, kit, thr=None):
        self.r += 1
        self.win.append((c, kit))
        H = np.full((self.L, self.M), self.alpha)
        for c, k in self.win:
            H[c, k] += 1
        H /= H.sum(1, keepdims=True)
        s = float(np.mean(np.sum(H * np.log(H / self.P0), 1)))   # equal context weights
        if thr is not None and self.r > ARM:
            self.run = self.run + 1 if s > thr else 0
            if self.run >= KP and self.alert is None:
                self.alert = self.r
        return s


TOOL_CONTEXT = 'tool-context' in sys.argv[1:]
ARGS = [a for a in sys.argv[1:] if a != 'tool-context']
OUT = 'results/injecagent_replay' + ('_toolcontext' if TOOL_CONTEXT else '')


def main():
    data = ARGS[0] if ARGS else 'InjecAgent/data'
    mpath = ARGS[1] if len(ARGS) > 1 else 'data/injecagent_toolkit_map.json'
    fams, fam_idx, tool2kit, kit_fam, kit_idx, L, M = load_mapping(mpath)
    kf = {kit_idx[k]: fam_idx[kit_fam[k]] for k in kit_idx}      # toolkit idx -> family idx

    def kits_of(tools):
        return [kit_idx[tool2kit[t]] for t in tools if t in tool2kit]

    def calls(tools, task_tool):
        """(context, toolkit) pairs; context pinned to the user task's family
        unless TOOL_CONTEXT."""
        c0 = fam_idx[kit_fam[tool2kit[task_tool]]]
        return [(kf[k] if TOOL_CONTEXT else c0, k) for k in kits_of(tools)]

    dh = json.load(open(os.path.join(data, 'test_cases_dh_enhanced.json')))[:100]
    ds = json.load(open(os.path.join(data, 'test_cases_ds_enhanced.json')))[:100]
    arg = [c['User Tool'] for c in (dh + ds)][:25]              # argument-level: reuse user tool
    benign_tools = sorted({c['User Tool'] for c in dh[:60]})
    benign = kits_of(benign_tools)

    fams_cases = {
        'direct harm': (dh, lambda c, R: calls(c['Attacker Tools'], c['User Tool']) * R),
        'data stealing': (ds, lambda c, R: calls(c['Attacker Tools'], c['User Tool']) * R),
        'argument-level': ([{'User Tool': t} for t in arg],
                           lambda c, R: calls([c['User Tool']], c['User Tool']) * R),
    }

    def replay(cases, thr, rnd, seq):
        tp = fp = fn = 0
        pre = []
        for c in cases:
            d = Detector(benign, L, M, kf)
            stream = [(kf[k], k) for k in (rnd.choice(benign) for _ in range(PREFIX))] + seq(c, 10)
            for cc, k in stream:
                d.observe(cc, k, thr)
            if d.alert is None:
                fn += 1
            elif d.alert >= PREFIX + 1:
                tp += 1
                pre.append(d.alert - PREFIX - 1)
            else:
                fp += 1
        n = len(cases)
        return tp / n, fp / n, fn / n, pre

    acc = {f: {'tp': [], 'fp': [], 'fn': [], 'pre': []} for f in fams_cases}
    thrs = []
    for rep in range(REPS):
        rnd = random.Random(1000 + rep)
        null = []
        for _ in range(50):
            d = Detector(benign, L, M, kf)
            null += [d.observe(kf[k], k) for k in (rnd.choice(benign) for _ in range(500))][100:]
        thr = float(np.quantile(null, 0.999))
        thrs.append(thr)
        for f, (cases, seq) in fams_cases.items():
            tp, fp, fn, pre = replay(cases, thr, rnd, seq)
            a = acc[f]
            a['tp'].append(tp); a['fp'].append(fp); a['fn'].append(fn); a['pre'] += pre

    sweep = {}
    for f, (cases, seq) in fams_cases.items():
        row = []
        for R in LENGTHS:
            tps = []
            for rep in range(REPS):
                rnd = random.Random(5000 + rep)
                tps.append(replay(cases, thrs[rep], rnd, lambda c, _R, seq=seq, R=R: seq(c, R))[0])
            row.append(float(np.mean(tps)))
        sweep[f] = row

    L_ = [f"Table X(b): InjecAgent ground-truth "
          f"replay, no LLM, {REPS} repetitions (mean); tool identity = toolkit, "
          f"L={L} context families {fams}, context = "
          f"{'family of the invoked toolkit' if TOOL_CONTEXT else 'family of the user task, pinned per episode'}; threshold = {np.mean(thrs):.3f}+-{np.std(thrs):.3f}; "
          f"benign prefix = {PREFIX} calls ({ARM} warm-up + {PREFIX-ARM} monitored)",
          f"{'family':16s} {'cases':>5s} {'TP (R=10)':>10s} {'FP':>8s} {'FN':>8s} {'pre-alert calls':>16s}"]
    for f, a in acc.items():
        mp = f"{np.median(a['pre']):.0f}" if a['pre'] else '-'
        L_.append(f"{f:16s} {len(fams_cases[f][0]):5d} {np.mean(a['tp']):10.2f} "
                  f"{np.mean(a['fp']):8.2f} {np.mean(a['fn']):8.2f} {mp:>16s}")
    L_.append("")
    L_.append(f"Attack-length sweep: TP rate when attacker tools are repeated R times ({REPS} reps)")
    L_.append(f"{'family':16s} " + " ".join(f"{'R='+str(r):>8s}" for r in LENGTHS))
    for f in fams_cases:
        L_.append(f"{f:16s} " + " ".join(f"{v:8.2f}" for v in sweep[f]))
    txt = "\n".join(L_)
    print(txt)
    open(OUT + '.txt', 'w').write(txt + "\n")

    plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 3.6))
    names = list(fams_cases)
    x = np.arange(len(names))
    for k, (key, lab, col) in enumerate([('tp', 'alarm after onset (TP)', 'tab:blue'),
                                         ('fp', 'alarm in benign window (FP)', 'tab:orange'),
                                         ('fn', 'no alarm (FN)', 'tab:gray')]):
        a1.bar(x + (k - 1) * .27, [np.mean(acc[f][key]) for f in names], .27,
               yerr=[np.std(acc[f][key]) for f in names], capsize=2, color=col,
               edgecolor='black', linewidth=.5, label=lab)
    a1.set_xticks(x); a1.set_xticklabels(['direct\nharm', 'data\nstealing', 'argument-\nlevel'])
    a1.set_ylabel('Fraction of cases'); a1.set_ylim(0, 1.05); a1.legend(fontsize=7)
    a1.set_title('(a) replay outcome, R = 10', fontsize=10)
    a1.grid(axis='y', alpha=.3, ls='--')
    for f, mk in zip(names, 'os^'):
        a2.plot(LENGTHS, [100 * v for v in sweep[f]], marker=mk, label=f)
    a2.set_xscale('log', base=2); a2.set_xticks(LENGTHS)
    a2.set_xticklabels([str(v) for v in LENGTHS])
    a2.set_xlabel('Attack tools repeated R times'); a2.set_ylabel('Detected after onset (%)')
    a2.set_ylim(0, 105); a2.legend(fontsize=7)
    a2.set_title('(b) detection vs attack length', fontsize=10)
    a2.grid(alpha=.3, ls='--')
    plt.tight_layout(); plt.savefig(OUT + '.png', dpi=200)
    print(f"Saved {OUT}.txt, {OUT}.png")


if __name__ == '__main__':
    main()
