"""AgentDojo replay with calibration and validation on disjoint user tasks.

    python exp_agentdojo_heldout_tasks.py data/agentdojo_runs_<model>.jsonl [...]
    python exp_agentdojo_heldout_tasks.py data/agentdojo_runs_gpt-4o-mini-2024-07-18.jsonl quick

exp_agentdojo_replay.py draws calibration, validation and attack-time benign
traffic from the same pool of recorded benign episodes (one per user task),
resampled with replacement. Here the benign user tasks of each suite are split
in two halves (fixed seed, per suite), and both directions are run:
  calibration half  edge parameters and fog thresholds (matched ARL0 = 1000),
                    exactly as in exp_agentdojo_replay.py but on that half only;
  held-out half     held-out null ARL and the benign traffic of every attack run.
The reference P0 is estimated at warm-up from the monitored traffic itself
(half B), as in deployment. Injected episodes are drawn from all recorded
attacked episodes, as in exp_agentdojo_replay.py. Seeds, fleet (N = 50, F = 5)
and settings are those of exp_agentdojo_replay.py.

Output: results/agentdojo_heldout_tasks.txt / .json
"""
import json
import sys
import time

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx
import exp_agentdojo_replay as ear

SPLIT_SEED = 0
CASES = [('success-only', 50, 0.25), ('success-only', 5, 0.25), ('success-only', 1, 1.0),
         ('observed', 1, 1.0)]


def split_tasks(E):
    rng = np.random.default_rng(SPLIT_SEED)
    A, B = set(), set()
    for su in sorted({e['suite'] for e in E}):
        tasks = sorted({e['user_task'] for e in E if e['suite'] == su and e['injection_task'] is None},
                       key=lambda t: int(t.split('_')[-1]))
        perm = rng.permutation(len(tasks))
        half = len(tasks) // 2
        A |= {(su, tasks[i]) for i in perm[:half]}
        B |= {(su, tasks[i]) for i in perm[half:]}
    keep = lambda e, S: e['injection_task'] is not None or (e['suite'], e['user_task']) in S
    return [e for e in E if keep(e, A)], [e for e in E if keep(e, B)], len(A), len(B)


def main():
    t0 = time.time()
    log = lambda m: print(f"[{(time.time() - t0) / 60:5.1f} min] {m}", flush=True)
    out, L = {}, []
    for model, E in ear.load(ear.FILES).items():
        suites, idx, M = ear.vocab(E)
        EA, EB, nA, nB = split_tasks(E)
        halves = {'A': ear.Replay(EA, suites, idx, M), 'B': ear.Replay(EB, suites, idx, M)}
        cfg0 = ear.make_cfg(len(suites), M)
        out[model] = {'tasks_A': nA, 'tasks_B': nB}
        for c_half, v_half in (('A', 'B'), ('B', 'A')):
            rpA, rpB = halves[c_half], halves[v_half]
            run_direction(model, rpA, rpB, cfg0, f'calibrate {c_half}, validate {v_half}', out, L, log)
    txt = ("AgentDojo replay, calibration on half of the benign user tasks of each suite, "
           "validation and attack-time benign traffic on the other half (both directions). Settings, "
           "seeds and fleet of exp_agentdojo_replay.py.\n" + "\n".join(L))
    print("\n" + txt)
    open('results/agentdojo_heldout_tasks.txt', 'w').write(txt + "\n")
    json.dump(out, open('results/agentdojo_heldout_tasks.json', 'w'), indent=1, default=float)


def run_direction(model, rpA, rpB, cfg0, tag, out, L, log):
    def make_stream(seed):
        rng = np.random.default_rng(seed)
        P0 = ear.warm_P0(rpA, rng, cfg0)
        return P0, (lambda: rpA.round(rng)[0])
    cfg_fd, ep = fx.calibrate_edge_params_gen(make_stream, ear.EDGE_SEEDS, cfg0)
    cal = fx.calibrate_endpoint(ear.null_sigs(rpA, cfg_fd, {}, ear.CAL_SEEDS), ear.TARGET, ear.KP)
    val = fx.alarm_profile([fc.endpoint_fog(s, cal['tau_a'], cal['tau_l'], ear.KP)[0]
                            for s in ear.null_sigs(rpB, cfg_fd, {}, ear.VAL_SEEDS)])
    res = {}
    for pool, q, p in CASES:
        R = [ear.attack_run(rpB, cfg_fd, {}, cal, s, q, p, pool == 'success-only')
             for s in ear.RUN_SEEDS]
        ds = [r[0] for r in R]
        res[f'{pool} q={q} p={p}'] = {'rate': float(np.mean([d is not None for d in ds])),
                                      'delay': fx.med(ds)}
    out[model][tag] = {'edge': ep, 'thresholds': cal, 'validation': val, 'delays': res}
    log(f"{model} ({tag}): held-out ARL {val['ARL']:.0f} [{val['ARL_lo']:.0f}, {val['ARL_hi']:.0f}]")
    L.append(f"{model}, {tag} (user tasks A {out[model]['tasks_A']}, B {out[model]['tasks_B']}): "
             f"tau_a={cal['tau_a']:.3f} tau_l={cal['tau_l']:.4f}; held-out ARL "
             f"{val['ARL']:.0f} [{val['ARL_lo']:.0f}, {val['ARL_hi']:.0f}] ({val['events']} events / "
             f"{val['rounds']} rounds)")
    L.append("    FogDrift delay, median rounds (detected): " + "; ".join(
        f"{k}: {fx.fmt(v['delay'])} ({v['rate']:.2f})" for k, v in res.items()))

if __name__ == '__main__':
    main()
