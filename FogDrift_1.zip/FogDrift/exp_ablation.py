"""Tier ablations, each run in the regime its tier is meant for (Table IX).

    python exp_ablation.py          # ~20 min
    python exp_ablation.py quick    # ~4 min (sanity only)

Needs edge_params.json and calibration.json (calibrate.py).

Variants (each calibrated to the SAME matched ARL0 = 1000 on the same
50,000 null rounds as calibrate.py, then frozen):
  V1 FogDrift          full design, endpoint = any fog with stable Eq.(4) alert
  V2 no-aggregate      fog aggregate branch removed (agent branch only)
  V3 cloud endpoint    operator acts only on the cloud alarm (untrimmed mean; the
                       row for the trimmed Eq. (6) is in exp_cloud_corroboration.py)
  V4 no-trigger        every agent reports every round (= Centralised-Histogram)
  V5 no-tracker        Page-Hinkley tracker (Eq. 5) removed
  V6 no-agent-branch   per-agent branch removed (fog aggregate only)
  V7 fixed-TV          hand-set edge parameters (Delta_TV=0.015, Delta_0=0.005)
  V8 mixture-weights   pi-weighted contexts instead of equal weights
Regimes: full-fleet drift, 10 % of agents compromised, 1 agent compromised,
slow ramp (30 rounds), small magnitude (m = 0.15), 50 % link dropout.
Outputs: results/ablation.txt, results/ablation_thresholds.json
"""
import json
import os
import sys
import time
from dataclasses import fields, replace
import numpy as np
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

CAL_SEEDS = list(range(100, 110))
CAL_ROUNDS = 5000
BURN = 30
SEEDS = list(range(300, 330))
T = 1000
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    CAL_SEEDS, CAL_ROUNDS, SEEDS = [100, 101, 102], 2000, list(range(500, 505))
    print("QUICK MODE: numbers are noisy")
KP = fc.DEFAULT.KP


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def make_extra(cal):
    return {
        'V4 no-trigger': lambda P0, cfg: fc.HCDD(P0, cfg, trigger=False, name='V4'),
        'V5 no-tracker': lambda P0, cfg: fc.HCDD(P0, cal, tracker=False, name='V5'),
        'V7 fixed-TV': lambda P0, cfg: fc.HCDD(P0, cfg, name='V7'),
        'V8 mixture-weights': lambda P0, cfg: fc.HCDD(P0, replace(cal, CTX_W='mixture'),
                                                       name='V8'),
    }


def trim(sig):
    return {k: v[BURN:] for k, v in sig.items() if isinstance(v, np.ndarray)}


def arl(alarms):
    ev = sum(fc.count_events(a) for a in alarms)
    n = sum(len(a) for a in alarms)
    return (n / ev if ev else np.inf)


def smallest(fun, lo, hi, target, it=60):
    if fun(hi) < target:
        return None
    for _ in range(it):
        mid = np.sqrt(lo * hi)
        if fun(mid) >= target:
            hi = mid
        else:
            lo = mid
    return hi


def calibrate(sigs, mode):
    """Thresholds (tau_a, tau_l) at matched ARL0 for one endpoint mode."""
    qa = float(np.quantile(np.concatenate([s['fog_amax'].ravel() for s in sigs]), .999))
    ql = float(np.quantile(np.concatenate([s['fog_score'].ravel() for s in sigs]), .999))
    INF = 1e9
    if mode == 'both':
        k = smallest(lambda k: arl([fc.endpoint_fog(s, k * qa, k * ql, KP)[0] for s in sigs]),
                     .8, 20, T)
        return k * qa, k * ql
    if mode == 'agent':
        k = smallest(lambda k: arl([fc.endpoint_fog(s, k * qa, INF, KP)[0] for s in sigs]),
                     .5, 20, T)
        return k * qa, INF
    if mode == 'aggregate':
        k = smallest(lambda k: arl([fc.endpoint_fog(s, INF, k * ql, KP)[0] for s in sigs]),
                     .5, 20, T)
        return INF, k * ql
    raise ValueError(mode)


def cloud_delay(sig, ta, tl, tg, onset):
    c, _, _ = fc.endpoint_cloud(sig, ta, tl, tg, fc.DEFAULT.P_CORR, KP)
    st, sr = fc.stable_alarm(c, 1)
    return fc.detection_delay(st, sr, onset, KP)


REGIMES = {
    'full fleet (m=0.5)': dict(scenario='policy', m=0.5),
    '10% agents (q=5)': dict(scenario='policy', m=0.5, q=5),
    '1 agent (q=1)': dict(scenario='policy', m=0.5, q=1),
    'slow ramp 30 rnd': dict(scenario='policy', m=0.5,
                             attack=lambda r, Pt, Pd: fc.policy_poison(Pt, 0.5 * min(1, (r + 1) / 30))),
    'small (m=0.15)': dict(scenario='policy', m=0.15),
    '50% dropout': dict(scenario='policy', m=0.5, drop=0.5),
}


def main():
    t0 = time.time()
    cal = load_cfg()
    th2 = json.load(open('calibration.json'))[str(T)]
    extra = make_extra(cal)

    # ---- calibration of the variants on null streams ----
    nulls = [fc.run_stream(s, fd_cfg=cal, base_dets=False, scalars=False,
                           keep_agent=False, extra=extra, pre=CAL_ROUNDS, post=0)
             for s in CAL_SEEDS]
    print(f"[{(time.time()-t0)/60:4.1f} min] null streams done", flush=True)
    fd = [trim(o['FogDrift']) for o in nulls]
    TH = {
        'V1 FogDrift': calibrate(fd, 'both'),
        'V2 no-aggregate': calibrate(fd, 'agent'),
        'V6 no-agent-branch': calibrate(fd, 'aggregate'),
    }
    for v in ['V4 no-trigger', 'V5 no-tracker', 'V7 fixed-TV', 'V8 mixture-weights']:
        TH[v] = calibrate([trim(o[v]) for o in nulls], 'both')
    tg = th2['FogDrift']['tau_g']
    json.dump({k: list(v) for k, v in TH.items()} | {'V3 cloud tau_g': tg,
              'calibrate_FogDrift': [th2['FogDrift']['tau_a'], th2['FogDrift']['tau_l']]},
              open('results/ablation_thresholds.json', 'w'), indent=1)
    print(f"[{(time.time()-t0)/60:4.1f} min] variants calibrated", flush=True)

    VARS = ['V1 FogDrift', 'V2 no-aggregate', 'V3 cloud endpoint', 'V4 no-trigger',
            'V5 no-tracker', 'V6 no-agent-branch', 'V7 fixed-TV', 'V8 mixture-weights']
    SIG = {'V1 FogDrift': 'FogDrift', 'V2 no-aggregate': 'FogDrift',
           'V3 cloud endpoint': 'FogDrift', 'V6 no-agent-branch': 'FogDrift'}
    res = {g: {v: [] for v in VARS} for g in REGIMES}
    # V2 re-calibrated lowers tau_a; the agent branch alone at V1's tau_a separates
    # the effect of the lower threshold from that of removing the aggregate.
    v2_v1ta = {g: [] for g in REGIMES}
    bw = {v: [] for v in VARS}
    for g, kw in REGIMES.items():
        for seed in SEEDS:
            out = fc.run_stream(seed, fd_cfg=cal, base_dets=False, scalars=False,
                                keep_agent=False, extra=extra, pre=60, post=100, **kw)
            on = out['onset']
            for v in VARS:
                sig = out[SIG.get(v, v)]
                if v == 'V3 cloud endpoint':
                    ta, tl = TH['V1 FogDrift']
                    d = cloud_delay(sig, ta, tl, tg, on)
                else:
                    ta, tl = TH[v]
                    _, st, sr = fc.endpoint_fog(sig, ta, tl, KP)
                    d = fc.detection_delay(st, sr, on, KP)
                res[g][v].append(d)
                if g == 'full fleet (m=0.5)':
                    s = np.diff(np.concatenate([[0.0], np.asarray(sig['sent'], float)])) / 1024
                    bw[v].append(s[:on].mean())
            _, st, sr = fc.endpoint_fog(out['FogDrift'], TH['V1 FogDrift'][0], 1e9, KP)
            v2_v1ta[g].append(fc.detection_delay(st, sr, on, KP))
        print(f"[{(time.time()-t0)/60:4.1f} min] regime {g} done", flush=True)

    def cell(v):
        x = np.array([np.inf if a is None else a for a in v], float)
        m = np.median(x)
        n = int(np.isfinite(x).sum())
        ms = 'cens' if not np.isfinite(m) else f"{m:.1f}"
        return f"{ms:>5s} ({n:2d}/{len(v)})"

    L = [f"Table IX: tier ablations at matched ARL0 = {T}, policy poisoning, "
         f"{len(SEEDS)} seeds per regime",
         "cell = median delay in rounds (detected/runs); censored = not detected in "
         "100 rounds; KB = bytes sent per round before onset",
         f"{'variant':20s} " + " ".join(f"{g:>17s}" for g in REGIMES) + f" {'KB':>6s}"]
    for v in VARS:
        L.append(f"{v:20s} " + " ".join(f"{cell(res[g][v]):>17s}" for g in REGIMES)
                 + f" {np.mean(bw[v]):6.2f}")
    L.append(f"{'agent branch only, V1 tau_a':20s} " + " ".join(f"{cell(v2_v1ta[g]):>17s}" for g in REGIMES)
             + "   (V2 without its re-calibration: tau_a of V1)")
    L.append("")
    L.append("thresholds (tau_a, tau_l): " + "; ".join(
        f"{k}: ({a:.3f}, {('off' if b > 1e8 else f'{b:.4f}')})" for k, (a, b) in TH.items()))
    txt = "\n".join(L)
    print("\n" + txt)
    open('results/ablation.txt', 'w').write(txt + "\n")
    print(f"\nSaved results/ablation.txt, ablation_thresholds.json [{(time.time()-t0)/60:.1f} min]")


if __name__ == '__main__':
    main()
