"""Per-fog uplink byte cap (Table VII(a), Fig. 6).

    python exp_bandwidth_cap.py          # ~20 min
    python exp_bandwidth_cap.py quick    # ~2 min, noisy

Needs edge_params.json and calibration.json (calibrate.py).

  * Each fog's edge->fog uplink carries at most CAP KB per round
    (token bucket, depth 2 rounds; round-robin over the fog's 10 agents).
  * Histogram detectors (FogDrift, Centralised-Histogram): a summary that does
    not fit is deferred, and the edge sends its LATEST histogram when it gets
    capacity. Summaries supersede each other, so the backlog is bounded.
  * Tuple detectors (CT(B=1), CT(B=5)): tuples join a FIFO queue per agent and
    drain oldest-first as capacity allows. If the offered load exceeds the cap,
    the queue grows without bound, and the attack's tuples wait behind it
    (buffer cap 5000 tuples/agent, oldest dropped and counted).

Thresholds are the uncapped matched-ARL0 thresholds (not re-tuned). Because a
cap can also change the NULL behaviour (stale summaries), the null false-alarm
rate under each cap is reported too.

Columns per detector and cap:
  up pre/post  measured edge->fog uplink KB per fog per round, before / after
         onset (no ACKs, no fog->cloud traffic)
  pay/cap  tuple payload per fog (N/F x K x 5 B = 0.39 KB/round) divided by
         the cap; > 1 means the tuple queue is unstable and grows for as long
         as the system runs (tuples only; headers are amortised under a cap)
  delay  median rounds from onset to the fog-endpoint alarm (cens = not within POST)
  det    fraction of runs detected within POST rounds
  qdelay tuple backlog at onset, in rounds of capacity (tuples only)
  FA/1k  null alarm events per 1000 rounds under the cap
  FA ev  null alarm events / rounds; null ARL with its exact 95% Poisson CI

Outputs: results/bandwidth_cap.txt, results/bandwidth_cap.json,
         results/bandwidth_cap.png
"""
import json
import os
import sys
import time
from dataclasses import fields
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)

SEEDS = list(range(1300, 1330))
NULL_SEEDS = list(range(1350, 1360))
NULL_ROUNDS = 5030                 # 10 x 5000 rounds after the burn-in
PRE, POST = 60, 100
CAPS = [None, 2.0, 1.0, 0.5, 0.25]
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS, NULL_SEEDS, NULL_ROUNDS = list(range(1300, 1306)), [1350], 800
    print("QUICK MODE: noisy")
KP = fc.DEFAULT.KP
BURN = 30
DETS = ['FogDrift', 'Cent-Hist', 'CT(B=1)', 'CT(B=5)']


def arl_ci(ev, n):
    """Null ARL = rounds / alarm events, with the exact (Garwood) 95% Poisson CI."""
    lo, hi = fx.poisson_ci(ev, n)
    arl = n / ev if ev else float('inf')
    return f"ARL {arl:.0f} [{lo:.0f}, {hi:.0f}]"


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def make(det, P0, cfg, uplink):
    if det == 'FogDrift':
        return fx.HCDDX(P0, cfg, name='FogDrift')
    if det == 'Cent-Hist':
        return fx.HCDDX(P0, cfg, trigger=False, name='Cent-Hist')
    B = int(det.split('=')[1].rstrip(')'))
    return fx.CappedCT(P0, cfg, B, uplink)


def step(d, cs, ts, uplink):
    uplink.new_round()
    if isinstance(d, fx.HCDDX):
        return d.step(cs, ts, admit=uplink.admit)
    return d.step(cs, ts)


def one_run(det, cfg, th, seed, cap, scenario='policy', m=0.5):
    rng = np.random.default_rng(seed)
    P_true = fc.build_P0(rng, cfg)
    pi = np.ones(cfg.L) / cfg.L
    P0 = fc.estimate_P0(rng, P_true, pi, cfg)
    fog_of = np.arange(cfg.N) % cfg.F
    up = fx.FogUplink(cfg, fog_of, cap)
    d = make(det, P0, cfg, up)
    Pd = fc.drifted(P_true, scenario, m, seed) if scenario else P_true
    sig = {k: [] for k in ['fog_score', 'fog_amax', 'fog_has']}
    sent_pre = up_pre = qdelay = None
    for r in range(PRE + POST):
        if r == PRE:
            sent_pre, up_pre = d.sent, d.uplink
            if isinstance(d, fx.CappedCT):
                b = d.backlog_tuples() * fc.TUPLE_B
                per_fog_cap = (cap or np.inf) * 1024
                qdelay = b / cfg.F / per_fog_cap if cap else 0.0
        cs, ts = fc.gen_round(rng, Pd if r >= PRE else P_true, pi, cfg)
        o = step(d, cs, ts, up)
        for k in sig:
            sig[k].append(o[k])
    sig = {k: np.array(v) for k, v in sig.items()}
    _, st, sr = fc.endpoint_fog(sig, th['tau_a'], th['tau_l'], KP)
    delay = fc.detection_delay(st, sr, PRE, KP)
    drop = d.dropped / max(d.generated, 1) if isinstance(d, fx.CappedCT) else 0.0
    upf = (up_pre / PRE / cfg.F / 1024, (d.uplink - up_pre) / POST / cfg.F / 1024)
    return delay, sent_pre / PRE / 1024, (d.sent - sent_pre) / POST / 1024, qdelay, drop, upf


def null_fa(det, cfg, th, cap):
    ev, n = 0, 0
    for s in NULL_SEEDS:
        rng = np.random.default_rng(s)
        P_true = fc.build_P0(rng, cfg)
        pi = np.ones(cfg.L) / cfg.L
        P0 = fc.estimate_P0(rng, P_true, pi, cfg)
        up = fx.FogUplink(cfg, np.arange(cfg.N) % cfg.F, cap)
        d = make(det, P0, cfg, up)
        sig = {k: [] for k in ['fog_score', 'fog_amax', 'fog_has']}
        for _ in range(NULL_ROUNDS):
            o = step(d, *fc.gen_round(rng, P_true, pi, cfg), up)
            for k in sig:
                sig[k].append(o[k])
        sig = fx.trim({k: np.array(v) for k, v in sig.items()}, BURN)
        a, _, _ = fc.endpoint_fog(sig, th['tau_a'], th['tau_l'], KP)
        ev += fc.count_events(a)
        n += len(a)
    return 1000.0 * ev / n, ev, n


def main():
    t0 = time.time()
    cfg = load_cfg()
    cal = json.load(open('calibration.json'))['1000']
    res = {}
    payload = cfg.N / cfg.F * cfg.K * fc.TUPLE_B / 1024          # tuple payload KB/fog/round
    for cap in CAPS:
        for det in DETS:
            runs = [one_run(det, cfg, cal[det], s, cap) for s in SEEDS]
            delays = [r[0] for r in runs]
            det_rate = np.mean([d is not None for d in delays])
            qd = [r[3] for r in runs if r[3] is not None]
            res[(cap, det)] = {
                'delay': fx.med(delays), 'det': float(det_rate),
                'KB_pre': float(np.mean([r[1] for r in runs])),
                'KB_post': float(np.mean([r[2] for r in runs])),
                'qdelay': float(np.mean(qd)) if qd else None,
                'drop': float(np.mean([r[4] for r in runs])),
                **dict(zip(('FA_per_1k', 'FA_events', 'FA_rounds'), null_fa(det, cfg, cal[det], cap))),
                'up_pre': float(np.mean([r[5][0] for r in runs])),
                'up_post': float(np.mean([r[5][1] for r in runs])),
                'pay_cap': (payload / cap) if (cap is not None and det.startswith('CT')) else None,
            }
            print(f"[{(time.time()-t0)/60:4.1f} min] cap={cap} {det}: "
                  f"delay={fx.fmt(res[(cap, det)]['delay'])} det={det_rate:.2f}", flush=True)

    L = []
    P = L.append
    P(f"Table VII(a), Fig. 6: Per-fog edge->fog uplink BYTE cap, policy poisoning m=0.5, uncapped matched "
      f"ARL0=1000 thresholds, {len(SEEDS)} seeds, onset after {PRE} monitored rounds.")
    P(f"Tuple payload per fog = {payload:.2f} KB/round; KB columns are total bytes sent per round "
      f"(all links, incl. ACKs and fog->cloud), 'up' columns are edge->fog uplink KB per fog.")
    P("")
    P(f"{'cap':>6s} {'detector':10s} {'pay/cap':>7s} {'delay':>6s} {'det':>5s} "
      f"{'qdelay':>7s} {'drop':>6s} {'FA/1k':>6s} {'up pre':>7s} {'up post':>8s} {'KB pre':>7s} {'KB post':>8s}  {'FA ev':>10s} {'null ARL [95% CI]':>22s}")
    for cap in CAPS:
        for det in DETS:
            x = res[(cap, det)]
            pc = '-' if x['pay_cap'] is None else f"{x['pay_cap']:.2f}"
            qd = '-' if x['qdelay'] is None else f"{x['qdelay']:.1f}"
            P(f"{'none' if cap is None else cap:>6} {det:10s} {pc:>7s} {fx.fmt(x['delay']):>6s} "
              f"{x['det']:5.2f} {qd:>7s} {x['drop']:6.3f} {x['FA_per_1k']:6.2f} "
              f"{x['up_pre']:7.2f} {x['up_post']:8.2f} {x['KB_pre']:7.2f} {x['KB_post']:8.2f}  "
              f"{x['FA_events']:4d}/{x['FA_rounds']:<5d} {arl_ci(x['FA_events'], x['FA_rounds'])}")
        P("")
    P("qdelay = tuple backlog at onset divided by the per-fog cap (rounds the attack's first "
      "tuples wait). pay/cap > 1 = tuple payload above the cap: the queue, and therefore the "
      "detection delay, grows with the time the system has been running before the attack.")
    txt = "\n".join(L)
    print("\n" + txt)
    open('results/bandwidth_cap.txt', 'w').write(txt + "\n")
    json.dump({f"{k[0]}|{k[1]}": v for k, v in res.items()}, open('results/bandwidth_cap.json', 'w'),
              indent=2, default=float)

    plot(res)
    print(f"\nSaved results/bandwidth_cap.txt/.json, bandwidth_cap.png [{(time.time()-t0)/60:.1f} min]")


def plot(res):
    from matplotlib.ticker import FixedLocator, NullLocator
    plt.rcParams.update({'font.size': 12, 'font.family': 'serif'})
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    xs = list(range(len(CAPS)))
    styles = {'FogDrift': ('o', '-'), 'Cent-Hist': ('^', '-'),
              'CT(B=1)': ('s', '--'), 'CT(B=5)': ('D', ':')}
    for det in DETS:
        y = [res[(c, det)]['delay'] for c in CAPS]
        y = [v if np.isfinite(v) else POST for v in y]
        ax.plot(xs, y, marker=styles[det][0], ls=styles[det][1], lw=2, ms=7, label=det)
    ax.set_xticks(xs)
    ax.set_xticklabels(['none' if c is None else f'{c:g}' for c in CAPS])
    ax.set_xlabel('Per-fog edge-to-fog uplink cap (KB/round)')
    ax.set_ylabel('Median detection delay (rounds)')
    ax.set_yscale('log')
    ax.yaxis.set_major_locator(FixedLocator([2, 4, 6, 10, 20, 50]))
    ax.yaxis.set_minor_locator(NullLocator())
    ax.set_yticklabels(['2', '4', '6', '10', '20', '50'])
    ax.axvspan(3.5, 4.5, color='grey', alpha=.12, lw=0)
    ax.text(4.0, 11, 'cap below tuple\npayload (0.39 KB)', ha='center', fontsize=9)
    ax.grid(alpha=.3, ls='--')
    ax.legend(loc='upper left')
    plt.tight_layout()
    plt.savefig('results/bandwidth_cap.png', dpi=300)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'plot':
        raw = json.load(open('results/bandwidth_cap.json'))
        res = {}
        for k, v in raw.items():
            c, det = k.split('|')
            res[(None if c == 'None' else float(c), det)] = v
        plot(res)
    else:
        main()
