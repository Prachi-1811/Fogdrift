"""Quick installation check (~10 s).

    python check_setup.py

It does NOT produce paper numbers (thresholds here are rough, not matched-ARL;
that is calibrate.py). It only verifies that the core behaves as described:
  1. with hand-set edge parameters (Delta_TV=0.015) the trigger fires in every round;
  2. with null-calibrated edge parameters FogDrift sends only heartbeats when
     nothing changes, and more when drift starts;
  3. the minimum detection delay is K_p = 2 and batched tuples pay the
     batching delay.
"""
import time
import numpy as np
import fogdrift_core as fc

t0 = time.time()
cal, diag = fc.calibrate_edge_params(range(3))
print("Null-calibrated edge parameters:")
for k, v in diag.items():
    print(f"  {k:12s} {v:.4f}")

extra = {'FogDrift-cal': lambda P0, cfg: fc.HCDD(P0, cal, name='FogDrift-cal')}
null = fc.run_stream(4, pre=400, post=0, extra=extra)

print("\nNull stream (400 rounds): transmission rate and bandwidth")
print(f"{'detector':14s} {'tx/agent/round':>15s} {'sent KB/rnd':>12s} {'deliv KB/rnd':>13s} {'null fog score':>15s}")
for k in ['FogDrift', 'FogDrift-cal', 'Cent-Hist', 'Cent-KL', 'CT(B=1)', 'CT(B=5)', 'CT(B=10)']:
    s = null[k]
    print(f"{k:14s} {s['tx_frac']:15.2f} {s['sent_KB']:12.2f} {s['delivered_KB']:13.2f} "
          f"{s['fog_score'][30:].mean():15.4f}")

print("\nPolicy poisoning m=0.5, rough thresholds (null 99.9% quantile x1.05)")
for seed in [5, 6, 7]:
    dr = fc.run_stream(seed, scenario='policy', m=0.5, pre=60, post=60, extra=extra)
    on = dr['onset']
    row = []
    for k in ['FogDrift-cal', 'Cent-Hist', 'CT(B=1)', 'CT(B=5)', 'CT(B=10)']:
        tl = np.quantile(null[k]['fog_score'][30:], .999) * 1.05
        ta = np.quantile(null[k]['fog_amax'][30:], .999) * 1.05
        _, st, sr = fc.endpoint_fog(dr[k], ta, tl)
        row.append(f"{k}={fc.detection_delay(st, sr, on)}")
    print(f"  seed {seed}: " + "  ".join(row))
print(f"\nDone in {time.time() - t0:.0f} s")
