"""Draw Figs. 2-7 of the paper from the result files in results/.

    python figures/plot_paper_figures.py

Run the experiment scripts first (or use the result files shipped in
results/). Each figure is written to figures/ as PDF and PNG.

Figure            source
Fig. 2            results/matched_arl.json        (exp_matched_arl.py)
                  results/batch_random_phase.json (exp_batch_random_phase.py)
Fig. 3            results/matched_arl.json        (exp_matched_arl.py)
                  results/batch_random_phase.json (exp_batch_random_phase.py)
Fig. 4            alert-timing schematic (no data)
Fig. 5            results/workload_invariance.txt (exp_workload_invariance.py)
Fig. 6            results/bandwidth_cap.json      (exp_bandwidth_cap.py)
                  results/tuple_buffering.json    (exp_tuple_buffering.py)
Fig. 7            results/injecagent_replay.txt   (exp_injecagent_replay.py)

Fig. 1 (system architecture) is a drawing and is not produced here.
"""
import json
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import FixedLocator, NullLocator, FuncFormatter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "results")
OUT = os.path.join(ROOT, "figures")

# Wide figures are drawn 6 in wide and scaled to the column width in LaTeX;
# narrow figures are drawn at the column width (3.5 in) directly.
WIDE = {
    "font.family": "serif", "font.size": 14, "axes.labelsize": 14,
    "axes.titlesize": 14, "xtick.labelsize": 13, "ytick.labelsize": 13,
    "legend.fontsize": 12, "lines.linewidth": 2.0, "lines.markersize": 7,
    "axes.grid": True, "grid.alpha": 0.3, "grid.linestyle": "--",
    "savefig.bbox": "tight", "savefig.dpi": 600,
}
NARROW = dict(WIDE, **{
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8,
    "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "lines.linewidth": 1.3, "lines.markersize": 4.5,
})
num_fmt = FuncFormatter(lambda v, _: f"{v:g}")


def load(name):
    with open(os.path.join(RES, name)) as f:
        return json.load(f)


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"))
    plt.close(fig)
    print("wrote figures/%s.pdf/.png" % name)


# ----------------------------------------------------------------------
# Fig. 2: median detection delay vs target ARL0, all scenarios pooled.
# Markers of coinciding curves are shifted sideways (SHIFT decades).
# ----------------------------------------------------------------------
def fig2():
    curve = load("matched_arl.json")["curve"]
    rp = load("batch_random_phase.json")["t4"]
    arl = [100, 500, 1000, 5000]
    rand = {n: [rp[n][str(a)]["all"]["median"] for a in arl] for n in ("CT(B=5)", "CT(B=10)")}
    # name, delays, colour, marker, line style, filled marker, sideways shift
    series = [
        ("FogDrift", curve["FogDrift"], "#1f77b4", "o", "-", True, 0.5),
        ("Cent-Hist", curve["Cent-Hist"], "#ff7f0e", "s", "-", True, -1),
        ("CT(B=5)", curve["CT(B=5)"], "#2ca02c", "D", "-", True, 0),
        ("CT(B=10)", curve["CT(B=10)"], "#d62728", "^", "-", True, 0),
        ("MMD-cond", curve["MMD-cond"], "#9467bd", "v", "-", True, 0),
        ("CUSUM", curve["CUSUM"], "#8c564b", "P", "-", True, 1),
        ("ADWIN", curve["ADWIN"], "#e377c2", "*", "-", True, -0.5),
        ("Page-Hinkley", curve["Page-Hinkley"], "#7f7f7f", "X", "-", True, -1.5),
        ("CT(B=5), random offset", rand["CT(B=5)"], "#2ca02c", "D", "--", False, 1.5),
        ("CT(B=10), random offset", rand["CT(B=10)"], "#d62728", "^", "--", False, 0),
    ]
    shift = 0.045
    with plt.rc_context(WIDE):
        fig, ax = plt.subplots(figsize=(6.0, 4.4))
        for name, y, c, m, ls, filled, k in series:
            x = np.array(arl) * 10 ** (k * shift)
            ax.plot(x, y, ls, color=c, lw=2.6 if name == "FogDrift" else 1.6, marker=m,
                    ms=9 if m == "*" else 7, mfc=c if filled else "white", mec=c, mew=1.6,
                    label=name, zorder=5 if name == "FogDrift" else 3)
        ax.set_xscale("log")
        ax.xaxis.set_major_locator(FixedLocator(arl))
        ax.xaxis.set_minor_locator(NullLocator())
        ax.set_xticklabels([r"$10^2$", r"$5{\times}10^2$", r"$10^3$",
                            r"$5{\times}10^3$"])
        ax.set_xlim(70, 7500)
        ax.set_ylim(0, 12.5)
        ax.set_xlabel(r"Target ARL$_0$ (log scale)")
        ax.set_ylabel("Median detection delay (rounds)")
        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=3,
                  frameon=False, columnspacing=0.8, handletextpad=0.4, handlelength=2.6)
        save(fig, "fig2_delay_vs_arl")


# ----------------------------------------------------------------------
# Fig. 3: delay vs bytes sent per round before onset (ARL0 = 1000)
# ----------------------------------------------------------------------
def fig3():
    s = load("matched_arl.json")["summary"]
    # (detectors drawn at this point, label, label offset in points, align)
    groups = [
        (["CT(B=10)"], "CT(B=10)", (10, -5), "left"),
        (["CT(B=5)"], "CT(B=5)", (10, -5), "left"),
        (["CT(B=1)"], "CT(B=1)", (0, 12), "center"),
        (["Cent-Hist"], "Cent-Hist", (0, -26), "center"),
        (["DDM"], "DDM", (10, -5), "left"),
        (["ADWIN", "Page-Hinkley"], "ADWIN,\nPage-Hinkley", (10, -14), "left"),
        (["Cent-KL", "MMD-cond", "CUSUM"], "Cent-KL, MMD,\nCUSUM",
         (10, -14), "left"),
    ]
    fd = s["FogDrift"]
    with plt.rc_context(WIDE):
        fig, ax = plt.subplots(figsize=(6.0, 4.2))
        for names, lab, off, ha in groups:
            for n in names:
                ax.scatter(s[n]["bw0"], s[n]["median"], s=80, color="0.5",
                           edgecolor="black", zorder=3)
            x0, y0 = s[names[0]]["bw0"], s[names[0]]["median"]
            ax.annotate(lab, (x0, y0), textcoords="offset points",
                        xytext=off, ha=ha, fontsize=12)
        rp = load("batch_random_phase.json")["t4"]
        for n, off in (("CT(B=5)", (8, 6)), ("CT(B=10)", (10, -5))):
            y = rp[n]["1000"]["all"]["median"]
            ax.scatter(s[n]["bw0"], y, s=80, facecolor="white", edgecolor="black", zorder=5)
            ax.plot([s[n]["bw0"]] * 2, [y, s[n]["median"]], ":", color="0.4", zorder=2)
            ax.annotate("random offset", (s[n]["bw0"], y), textcoords="offset points",
                        xytext=off, ha="left", fontsize=10, color="0.3")
        ax.scatter(fd["bw0"], fd["median"], s=260, marker="*",
                   color="#1f77b4", edgecolor="black", zorder=6)
        ax.annotate("FogDrift", (fd["bw0"], fd["median"]),
                    textcoords="offset points", xytext=(0, -24), ha="center",
                    fontsize=12, color="#1f77b4")
        ax.annotate("", xy=(fd["bw1"], fd["median"]),
                    xytext=(fd["bw0"] * 1.05, fd["median"]),
                    arrowprops=dict(arrowstyle="->", color="#1f77b4",
                                    lw=1.8, ls="--"), zorder=4)
        ax.text(fd["bw1"] * 1.07, fd["median"] - 0.2,
                "during attack\n(%.2f KB)" % fd["bw1"], ha="left",
                va="top", fontsize=12, color="#1f77b4")
        ax.set_xscale("log")
        ax.xaxis.set_major_locator(FixedLocator([2, 5, 10, 20, 50]))
        ax.xaxis.set_minor_locator(NullLocator())
        ax.xaxis.set_major_formatter(num_fmt)
        ax.set_xlim(1.6, 90)
        ax.set_ylim(0, 13)
        ax.set_xlabel("KB sent per round before onset (log scale)")
        ax.set_ylabel("Median delay (rounds)")
        save(fig, "fig3_delay_vs_bandwidth")


# ----------------------------------------------------------------------
# Fig. 4: when an alert can be raised after onset
# ----------------------------------------------------------------------
def fig4():
    steps = [("Attack\nonset", r"round $r_0$"),
             ("Data\narrives", r"$r_0{+}\Delta_{\mathrm{tx}}{-}1$"),
             ("Detector\nupdate", "same round"),
             ("Persistence\ncheck", r"$K_p$ rounds"),
             ("Operator\nalert", r"$r_0{+}\Delta_{\mathrm{tx}}{+}K_p{-}2$")]
    fills = ["#fde7d4", "#fccfa6", "#fbb377", "#f99645", "#f57c14"]
    bw, bh, gap = 1.75, 1.15, 0.38          # box width, height, gap (in)
    W = 5 * bw + 4 * gap
    with plt.rc_context({"font.family": "serif", "font.size": 14,
                         "savefig.bbox": "tight", "savefig.dpi": 600}):
        fig, ax = plt.subplots(figsize=(W, bh + 0.1))
        for k, ((title, detail), fc) in enumerate(zip(steps, fills)):
            x = k * (bw + gap)
            ax.add_patch(FancyBboxPatch(
                (x, 0), bw, bh, boxstyle="round,pad=0.02,rounding_size=0.08",
                fc=fc, ec="black", lw=1.2))
            ax.text(x + bw / 2, bh * 0.64, title, ha="center", va="center",
                    fontsize=14, fontweight="bold", linespacing=1.0)
            ax.text(x + bw / 2, bh * 0.18, detail, ha="center", va="center",
                    fontsize=13)
            if k < len(steps) - 1:
                ax.annotate("", xy=(x + bw + gap, bh / 2),
                            xytext=(x + bw, bh / 2),
                            arrowprops=dict(arrowstyle="->", lw=1.6,
                                            color="black"))
        ax.set_xlim(-0.05, W + 0.05)
        ax.set_ylim(-0.05, bh + 0.05)
        ax.set_aspect("equal")
        ax.axis("off")
        save(fig, "fig4_alert_timeline")


# ----------------------------------------------------------------------
# Fig. 5: workload-only shift with P(t|c) unchanged
#   (a) score ratio shifted/uniform   (b) null ARL with 95% Poisson CI
# Values: results/workload_invariance.txt
# ----------------------------------------------------------------------
def fig5():
    labels = ["conditional\n(equal w.)", "conditional\n($\\pi$-weighted)",
              "unconditional"]
    ratio = [0.99, 1.00, 34.71]
    groups = ["stationary", "workload drift"]
    eq, eq_lo, eq_hi = [842, 920], [653, 705], [1107, 1225]
    pw, pw_lo, pw_hi = [857, 161], [663, 144], [1128, 180]

    with plt.rc_context(WIDE):
        fig, (axa, axb) = plt.subplots(2, 1, figsize=(6.0, 7.6))
        bars = axa.bar(labels, ratio, color=["#1f77b4", "0.5", "#d62728"],
                       edgecolor="black", width=0.6)
        for b, v in zip(bars, ratio):
            axa.text(b.get_x() + b.get_width() / 2, v + 0.8,
                     f"{v:.2f}$\\times$", ha="center", va="bottom",
                     fontsize=13)
        axa.axhline(1.0, color="black", ls=":", lw=1.2)
        axa.set_ylim(0, 40)
        axa.set_ylabel("Score ratio\n(shifted / uniform)")
        axa.set_title("(a) Score under a pure workload shift")

        x, w = np.arange(2), 0.36
        axb.bar(x - w / 2, eq, w, color="#1f77b4", edgecolor="black",
                label="equal weights",
                yerr=[np.subtract(eq, eq_lo), np.subtract(eq_hi, eq)],
                capsize=5)
        axb.bar(x + w / 2, pw, w, color="0.5", edgecolor="black",
                label=r"$\pi$-weighted",
                yerr=[np.subtract(pw, pw_lo), np.subtract(pw_hi, pw)],
                capsize=5)
        axb.axhline(1000, color="black", ls="--", lw=1.2,
                    label=r"target ARL$_0$")
        axb.set_xticks(x, groups)
        axb.set_ylim(0, 1450)
        axb.set_ylabel("Null ARL (rounds)")
        axb.set_title("(b) Measured false-alarm rate")
        axb.legend(loc="upper right", ncol=3, fontsize=11,
                   columnspacing=0.8, handletextpad=0.4)
        fig.tight_layout(h_pad=1.5)
        save(fig, "fig5_workload_invariance")


# ----------------------------------------------------------------------
# Fig. 6: median delay vs per-fog edge-to-fog uplink cap. FIFO tuple queues
# (bandwidth_cap.json); drop-oldest ring and ring drained newest first
# (tuple_buffering.json). Equal values are shifted sideways.
# ----------------------------------------------------------------------
COL = {"FogDrift": ("#1f77b4", "o", "-"), "Cent-Hist": ("#ff7f0e", "^", "-"),
       "CT(B=1)": ("#2ca02c", "s", "--"), "CT(B=5)": ("#d62728", "D", ":")}


def fig6():
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    b = load("bandwidth_cap.json")
    ring = load("tuple_buffering.json")["a"]
    caps = ["None", "2.0", "1.0", "0.5", "0.25"]
    tick = ["uncapped" if c == "None" else f"{float(c):g}" for c in caps]
    payload = 0.39                       # tuple payload, KB per fog per round
    x = np.arange(len(caps), dtype=float)
    x_payload = 3 + np.log(0.5 / payload) / np.log(0.5 / 0.25)
    shift = {"FogDrift": [0] * 5, "Cent-Hist": [0.09] * 5,
             "CT(B=1)": [-0.09] * 5, "CT(B=5)": [0, 0, 0, 0, 0.09]}
    with plt.rc_context(NARROW):
        fig, ax = plt.subplots(figsize=(3.5, 2.3))
        ax.axvspan(x_payload, x[-1] + 0.95, color="0.88", zorder=0)
        for name, (c, m, ls) in COL.items():
            y = [b[f"{cap}|{name}"]["delay"] for cap in caps]
            ax.plot(x + np.array(shift[name]), y, ls, color=c, marker=m, zorder=3)
        newest = {}
        for name in ("CT(B=1)", "CT(B=5)"):
            c, m, _ = COL[name]
            xr = x[-1] + shift[name][-1]
            # the ring equals the FIFO queue while the cap exceeds the payload
            y05 = ring[f"0.5|{name}|ring"]["delay"]
            y025 = ring[f"0.25|{name}|ring"]["delay"]
            ax.plot([x[-2] + shift[name][-2], xr], [y05, y025], "-.", color=c, lw=1.2,
                    zorder=4)
            ax.plot(xr, y025, marker=m, color=c, mfc="white", mew=1.2, ms=5.5, ls="none",
                    zorder=5)
            newest[name] = ring[f"0.25|{name}|ring, newest first"]["delay"]
            ax.plot(x[-1] + 0.30, newest[name], marker=m, color=c, mfc="white", mew=1.0,
                    ls="none", ms=4, zorder=5)
        # direct labels for the two ring variants at the 0.25 cap
        ax.annotate("ring: %g" % ring["0.25|CT(B=5)|ring"]["delay"],
                    (x[-1] + shift["CT(B=5)"][-1], ring["0.25|CT(B=5)|ring"]["delay"]),
                    textcoords="offset points", xytext=(6, 0), fontsize=6.5,
                    color="0.15", ha="left", va="center")
        ax.annotate("newest first", (x[-1] + 0.30, min(newest.values())),
                    textcoords="offset points", xytext=(0, -5), fontsize=6.5,
                    color="0.15", ha="center", va="top")
        for name, off, ha in (("CT(B=1)", (-11, -2), "right"), ("CT(B=5)", (6, -5), "left")):
            v = b[f"0.25|{name}"]["delay"]
            ax.annotate(f"{v:g}", (x[-1] + shift[name][-1], v), textcoords="offset points",
                        xytext=off, fontsize=7, color=COL[name][0], ha=ha, va="center")
        handles = [
            Line2D([], [], color=COL["FogDrift"][0], marker="o", ls="-", label="FogDrift"),
            Line2D([], [], color=COL["Cent-Hist"][0], marker="^", ls="-", label="Cent-Hist"),
            Line2D([], [], color=COL["CT(B=1)"][0], marker="s", ls="--", label="CT(B=1), FIFO"),
            Line2D([], [], color=COL["CT(B=5)"][0], marker="D", ls=":", label="CT(B=5), FIFO"),
            Line2D([], [], color=COL["CT(B=1)"][0], marker="s", mfc="white", ms=5.5,
                   mew=1.2, ls="-.", lw=1.2, label="CT(B=1), ring"),
            Line2D([], [], color=COL["CT(B=5)"][0], marker="D", mfc="white", ms=5.5,
                   mew=1.2, ls="-.", lw=1.2, label="CT(B=5), ring"),
            Line2D([], [], color="0.3", marker="s", mfc="white", ms=4, ls="none",
                   label="ring, newest first"),
            Patch(color="0.88", label="cap < tuple payload"),
        ]
        ax.legend(handles=handles, loc="upper left", ncol=2, frameon=True, framealpha=0.95,
                  fontsize=6.3, columnspacing=0.8, handlelength=2.4, handletextpad=0.4,
                  borderpad=0.4, labelspacing=0.35)
        ax.set_yscale("log")
        ax.yaxis.set_major_locator(FixedLocator([2, 4, 6, 10, 20, 50]))
        ax.yaxis.set_minor_locator(NullLocator())
        ax.yaxis.set_major_formatter(num_fmt)
        ax.set_ylim(1.7, 330)
        ax.set_xticks(x, tick)
        ax.set_xlim(-0.3, x[-1] + 0.95)
        ax.set_xlabel("Per-fog edge-to-fog uplink cap (KB/round)")
        ax.set_ylabel("Median detection delay (rounds)")
        save(fig, "fig6_uplink_cap")


# ----------------------------------------------------------------------
# Fig. 7: InjecAgent ground-truth replay (no LLM), context pinned to the user task
#   (a) outcome with R = 10   (b) detection vs attack length R
# Values: results/injecagent_replay.txt
# ----------------------------------------------------------------------
def fig7():
    fams = ["direct\nharm", "data\nstealing", "argument-\nlevel"]
    tp = np.array([0.81, 0.82, 0.00])
    fp = np.array([0.01, 0.02, 0.01])
    fn = np.array([0.18, 0.16, 0.98])   # as printed in results/injecagent_replay.txt
    # Panel (b): the R = 10 point is the main run of panel (a); R = 20, 40
    # and 80 come from the attack-length sweep. Data stealing is drawn with
    # large open squares so that direct harm stays visible where they are equal.
    R = [10, 20, 40, 80]
    det = {"direct harm":    ([81, 99, 99, 99], "#1f77b4", "o", "-", True, 7),
           "data stealing":  ([82, 99, 99, 99], "#ff7f0e", "s", "--", False, 11),
           "argument-level": ([0, 2, 18, 49], "#2ca02c", "^", "-", True, 8)}

    with plt.rc_context(WIDE):
        fig, (axa, axb) = plt.subplots(2, 1, figsize=(6.0, 7.8))
        x, w = np.arange(3), 0.26
        axa.bar(x - w, tp, w, color="#1f77b4", edgecolor="black",
                label="alarm after onset")
        axa.bar(x, fp, w, color="#ff7f0e", edgecolor="black",
                label="alarm in benign segment")
        axa.bar(x + w, fn, w, color="0.5", edgecolor="black",
                label="no alarm")
        for xi, v in list(zip(x - w, tp)) + list(zip(x + w, fn)):
            axa.text(xi, v + 0.02, f"{v:.2f}", ha="center", va="bottom", fontsize=11)
        axa.set_xticks(x, fams)
        axa.set_ylim(0, 1.48)
        axa.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
        axa.set_ylabel("Fraction of cases")
        axa.set_title(r"(a) Outcome with $R{=}10$")
        axa.legend(loc="upper center", ncol=2, fontsize=12,
                   columnspacing=0.8, handletextpad=0.4)

        for name, (y, c, m, ls, filled, ms) in det.items():
            axb.plot(R, y, ls, color=c, marker=m, ms=ms, mfc=c if filled else "none",
                     mec=c, mew=1.8, lw=2.0, label=name, zorder=4 if filled else 3)
        axb.annotate("81", (10, 81), textcoords="offset points", xytext=(0, -20),
                     ha="center", fontsize=11, color="#1f77b4")
        axb.annotate("82", (10, 82), textcoords="offset points", xytext=(0, 10),
                     ha="center", fontsize=11, color="#ff7f0e")
        axb.annotate("99 (both)", (40, 99), textcoords="offset points", xytext=(0, -22),
                     ha="center", fontsize=11, color="0.25")
        for r, v in zip(R, det["argument-level"][0]):
            axb.annotate(f"{v}", (r, v), textcoords="offset points", xytext=(0, 9),
                         ha="center", fontsize=11, color="#2ca02c")
        axb.set_xscale("log", base=2)
        axb.xaxis.set_major_locator(FixedLocator(R))
        axb.xaxis.set_minor_locator(NullLocator())
        axb.xaxis.set_major_formatter(num_fmt)
        axb.set_xlim(8.5, 94)
        axb.set_ylim(-5, 112)
        axb.set_xlabel(r"Attacker tools repeated $R$ times")
        axb.set_ylabel("Detected after onset (%)")
        axb.set_title("(b) Detection versus attack length")
        axb.legend(loc="center left", bbox_to_anchor=(0.0, 0.45))
        fig.tight_layout(h_pad=1.5)
        save(fig, "fig7_injecagent_replay")


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for f in (fig2, fig3, fig4, fig5, fig6, fig7):
        f()
