"""FogDrift on recorded AgentDojo traces (Table XI(a); published runs, Table XI(b)). No API calls here.

    python exp_agentdojo_replay.py data/agentdojo_gptoss20b_banking.jsonl
    python exp_agentdojo_replay.py traces_dryrun.jsonl quick     # pipeline test

Input: the JSONL written by agentdojo_collect.py. Output per model:
results/agentdojo_<model>.txt / .json and results/agentdojo_<model>.png.

1. Agent-level results:
     benign utility, utility under attack, attack success rate (ASR) over
     completed episodes and over all episodes (errors = failed), and the
     harmful tool calls executed in successful attacks.

2. Fleet replay of the recorded traces through FogDrift:
     * contexts = AgentDojo suites present in the file, tool identity = the
       function called, indexed within its suite;
     * N=50 agents on F=5 fogs; in every round each agent handles one task:
       suite drawn uniformly, then a recorded BENIGN episode of that suite
       (the agent's real tool-call sequence, so real autocorrelation, real
       call counts and real task mix are kept);
     * reference P0, edge parameters and thresholds are all estimated on the
       recorded benign traces (matched ARL0=1000 at the fog endpoint, procedure
       of calibrate.py), then validated on held-out benign replays;
     * from onset, q compromised agents receive an injected task with
       probability p_inj each round, drawn from the recorded INJECTED episodes
       of that suite: either as observed (successful and failed attacks in
       the measured proportion) or successful attacks only.
   Per setting: detection rate within POST rounds, median delay (rounds = tasks
   per agent), and the successful attacks and harmful calls completed before
   the operator-visible alarm (alarm round included, since that round's tasks
   have already run). FogDrift and Centralised-Histogram (trigger off).

Harmful calls = calls to a function in the injection task's ground truth that
the user task's ground truth does not use (strict count).

settle=S (optional argument): burn-in of the null streams and rounds before
onset, both S (default 30 and 60). Short episodes (one or two calls) fill the
per-context windows slowly, and an alarm still active from the start-up phase
at onset is not counted as a detection, so such traces need a longer settle
(InjecAgent: settle=300).
"""
import json
import os
import re
import sys
import time
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)

QUICK = 'quick' in sys.argv
SETTLE = next((int(a.split('=')[1]) for a in sys.argv[1:] if a.startswith('settle=')), None)
FILES = [a for a in sys.argv[1:] if a != 'quick' and not a.startswith('settle=')]
N, F = 50, 5
TARGET = 1000
KP = 2
BURN = 30
CAL_SEEDS = list(range(1500, 1510))
VAL_SEEDS = list(range(1520, 1525))
RUN_SEEDS = list(range(1540, 1570))
EDGE_SEEDS = list(range(1600, 1610))
ROUNDS = 3000
PRE, POST = 60, 100
if SETTLE is not None:
    BURN = PRE = SETTLE
QS = [N, 5, 1]
PINJ = [1.0, 0.5, 0.25]
if QUICK:
    CAL_SEEDS, VAL_SEEDS, RUN_SEEDS, EDGE_SEEDS = [1500, 1501], [1520], list(range(1540, 1546)), [1600, 1601]
    ROUNDS, QS, PINJ = 1000, [N, 1], [1.0, 0.25]
    print("QUICK MODE: noisy, pipeline test only")


def load(files):
    eps = []
    for fn in files:
        for line in open(fn):
            line = line.strip()
            if line:
                eps.append(json.loads(line))
    best = {}
    for e in eps:
        key = (e['model'], e['suite'], e['user_task'], e['injection_task'], e.get('rep', 0))
        if key not in best or best[key]['error'] is not None:
            best[key] = e
    by_model = defaultdict(list)
    for e in best.values():
        by_model[e['model']].append(e)
    return by_model


def harmful(e):
    bad = set(e.get('harm_tools') or []) - set(e.get('user_gt_tools') or [])
    return sum(c in bad for c in e['calls'])


def agent_summary(E):
    ben = [e for e in E if e['injection_task'] is None]
    att = [e for e in E if e['injection_task'] is not None]
    ok_b = [e for e in ben if e['error'] is None]
    ok_a = [e for e in att if e['error'] is None]
    succ = [e for e in ok_a if e['security']]
    s = {
        'benign_episodes': len(ben), 'benign_errors': len(ben) - len(ok_b),
        'benign_utility': float(np.mean([bool(e['utility']) for e in ok_b])) if ok_b else np.nan,
        'attacked_episodes': len(att), 'attacked_errors': len(att) - len(ok_a),
        'utility_under_attack': float(np.mean([bool(e['utility']) for e in ok_a])) if ok_a else np.nan,
        'ASR_completed': len(succ) / len(ok_a) if ok_a else np.nan,
        'ASR_all': len(succ) / len(att) if att else np.nan,
        'calls_benign': float(np.mean([e['n_calls'] for e in ok_b])) if ok_b else np.nan,
        'calls_attacked': float(np.mean([e['n_calls'] for e in ok_a])) if ok_a else np.nan,
        'harmful_calls_per_success': float(np.mean([harmful(e) for e in succ])) if succ else np.nan,
        'per_suite': {},
    }
    for su in sorted({e['suite'] for e in E}):
        a = [e for e in ok_a if e['suite'] == su]
        b = [e for e in ok_b if e['suite'] == su]
        s['per_suite'][su] = {
            'benign_utility': float(np.mean([bool(e['utility']) for e in b])) if b else np.nan,
            'ASR': float(np.mean([bool(e['security']) for e in a])) if a else np.nan,
            'n_attacked': len(a)}
    return s


def vocab(E):
    """Tool index within each suite: AgentDojo's tool list if available,
    otherwise every function seen; one extra out-of-vocabulary slot."""
    suites = sorted({e['suite'] for e in E})
    tools = {}
    try:
        from agentdojo.task_suite.load_suites import get_suites
        ver = E[0].get('benchmark_version', 'v1.2.2')
        S = get_suites(ver)
        for su in suites:
            tools[su] = sorted(f.name for f in S[su].tools)
    except Exception:
        for su in suites:
            names = set()
            for e in E:
                if e['suite'] == su:
                    names |= set(e['calls']) | set(e.get('harm_tools') or [])
            tools[su] = sorted(names)
    M = max(len(v) for v in tools.values()) + 1
    idx = {su: {t: i for i, t in enumerate(v)} for su, v in tools.items()}
    return suites, idx, M


class Replay:
    """Fleet event source built from recorded episodes."""
    def __init__(self, E, suites, idx, M):
        self.suites, self.M = suites, M
        self.cidx = {s: i for i, s in enumerate(suites)}
        enc = lambda e: np.array([idx[e['suite']].get(c, M - 1) for c in e['calls']], int)
        self.ben = {s: [] for s in suites}
        self.att = {s: [] for s in suites}
        for e in E:
            if e['error'] is not None:
                continue
            rec = (enc(e), bool(e['security']) if e['injection_task'] else False, harmful(e))
            (self.ben if e['injection_task'] is None else self.att)[e['suite']].append(rec)
        self.pi = np.ones(len(suites)) / len(suites)

    def has_attacks(self, success_only):
        return any(any(r[1] for r in v) if success_only else len(v) > 0 for v in self.att.values())

    def round(self, rng, comp_mask=None, p_inj=0.0, success_only=False):
        """One round: list of (c_array, t_array) per agent, plus counts of
        successful attacks and harmful calls executed this round."""
        out, n_succ, n_harm = [], 0, 0
        cs = rng.choice(len(self.suites), size=N, p=self.pi)
        for i in range(N):
            su = self.suites[cs[i]]
            pool = self.ben[su]
            if comp_mask is not None and comp_mask[i] and rng.random() < p_inj:
                ap = [r for r in self.att[su] if r[1]] if success_only else self.att[su]
                if ap:
                    pool = ap
            if not pool:
                out.append((np.array([], int), np.array([], int)))
                continue
            t, sec, h = pool[rng.integers(len(pool))]
            if pool is not self.ben[su]:
                n_succ += int(sec)
                n_harm += h
            out.append((np.full(len(t), cs[i], int), t))
        return out, n_succ, n_harm


def make_cfg(L, M):
    return fc.Config(N=N, F=F, L=L, M=M, K=1)


def warm_P0(rp, rng, cfg):
    return fx.estimate_P0_from([rp.round(rng)[0] for _ in range(cfg.W0)], cfg)


def null_sigs(rp, cfg, det_kw, seeds):
    out = []
    for s in seeds:
        rng = np.random.default_rng(s)
        P0 = warm_P0(rp, rng, cfg)
        det = fx.HCDDX(P0, cfg, **det_kw)
        out.append(fx.trim(fx.run_detector(det, [rp.round(rng)[0] for _ in range(ROUNDS)]), BURN))
    return out


def attack_run(rp, cfg, det_kw, th, seed, q, p_inj, success_only):
    rng = np.random.default_rng(seed)
    P0 = warm_P0(rp, rng, cfg)
    det = fx.HCDDX(P0, cfg, **det_kw)
    comp = np.zeros(N, bool)
    comp[np.random.default_rng(seed + 7).choice(N, q, replace=False)] = True
    batches, succ, harm = [], [], []
    for r in range(PRE + POST):
        b, s, h = rp.round(rng, comp if r >= PRE else None, p_inj, success_only)
        batches.append(b); succ.append(s); harm.append(h)
    sig = fx.run_detector(det, batches)
    _, st, sr = fc.endpoint_fog(sig, th['tau_a'], th['tau_l'], KP)
    d = fc.detection_delay(st, sr, PRE, KP)
    end = PRE + (d if d is not None else POST)          # alarm round included
    return d, int(np.sum(succ[PRE:end])), int(np.sum(harm[PRE:end]))


def main():
    t0 = time.time()
    log = lambda m: print(f"[{(time.time()-t0)/60:5.1f} min] {m}", flush=True)
    for model, E in load(FILES).items():
        tag = re.sub(r'[^A-Za-z0-9._-]+', '_', model)
        summ = agent_summary(E)
        if summ['benign_episodes'] == summ['benign_errors']:
            errs = sorted({str(e['error'])[:200] for e in E if e['error']})[:3]
            print(f"{model}: every episode failed, nothing to analyse. First errors:")
            for x in errs:
                print('   ', x)
            continue
        suites, idx, M = vocab(E)
        rp = Replay(E, suites, idx, M)
        cfg0 = make_cfg(len(suites), M)
        log(f"{model}: {len(E)} episodes, L={len(suites)}, M={M}, ASR={summ['ASR_completed']:.3f}")

        def make_stream(seed):
            rng = np.random.default_rng(seed)
            P0 = warm_P0(rp, rng, cfg0)
            return P0, (lambda: rp.round(rng)[0])
        cfg_fd, ep = fx.calibrate_edge_params_gen(make_stream, EDGE_SEEDS, cfg0)
        dets = {'FogDrift': (cfg_fd, {}), 'Cent-Hist': (cfg0, {'trigger': False})}
        cal, val = {}, {}
        for name, (cfg, kw) in dets.items():
            cal[name] = fx.calibrate_endpoint(null_sigs(rp, cfg, kw, CAL_SEEDS), TARGET, KP)
            v = null_sigs(rp, cfg, kw, VAL_SEEDS)
            val[name] = fx.alarm_profile([fc.endpoint_fog(s, cal[name]['tau_a'], cal[name]['tau_l'], KP)[0]
                                          for s in v])
            log(f"  {name}: tau_a={cal[name]['tau_a']:.3f} tau_l={cal[name]['tau_l']:.4f} "
                f"held-out ARL={val[name]['ARL']:.0f}")

        rows = []
        for success_only in [False, True]:
            if not rp.has_attacks(success_only):
                rows.append({'pool': 'success-only' if success_only else 'observed',
                             'skipped': 'no successful attacks recorded'})
                continue
            for q in QS:
                for p in PINJ:
                    row = {'pool': 'success-only' if success_only else 'observed', 'q': q, 'p_inj': p}
                    for name, (cfg, kw) in dets.items():
                        R = [attack_run(rp, cfg, kw, cal[name], s, q, p, success_only) for s in RUN_SEEDS]
                        ds = [r[0] for r in R]
                        row[name] = {'rate': float(np.mean([d is not None for d in ds])),
                                     'delay': fx.med(ds),
                                     'succ_before': float(np.mean([r[1] for r in R])),
                                     'harm_before': float(np.mean([r[2] for r in R]))}
                    rows.append(row)
                    log(f"  {row['pool']} q={q} p={p}: " + "; ".join(
                        f"{n} {fx.fmt(row[n]['delay'])} ({row[n]['rate']:.2f})" for n in dets))

        L = []
        P = L.append
        P(f"AgentDojo live traces, model = {model}  (benchmark {E[0].get('benchmark_version')}, "
          f"attack = {next((e['attack'] for e in E if e['attack']), '-')}, "
          f"defense = {E[0].get('defense')}, temperature = {E[0].get('temperature')})")
        P(f"(a) Agent-level: benign utility {summ['benign_utility']:.3f} "
          f"({summ['benign_episodes']} episodes, {summ['benign_errors']} errors); "
          f"utility under attack {summ['utility_under_attack']:.3f}; ASR {summ['ASR_completed']:.3f} "
          f"over completed, {summ['ASR_all']:.3f} over all {summ['attacked_episodes']} attacked "
          f"({summ['attacked_errors']} errors); calls/episode {summ['calls_benign']:.1f} benign, "
          f"{summ['calls_attacked']:.1f} attacked; harmful calls per successful attack "
          f"{summ['harmful_calls_per_success']:.2f}.")
        P("    per suite: " + "; ".join(f"{s} util {v['benign_utility']:.2f} ASR {v['ASR']:.2f} (n={v['n_attacked']})"
                                         for s, v in summ['per_suite'].items()))
        P(f"(b) Calibration on real benign traces: edge DTV={ep['DTV']:.3f} D0={ep['D0']:.3f} "
          f"DCUM={ep['DCUM']:.3f}; " + "; ".join(
              f"{n} tau_a={cal[n]['tau_a']:.3f} tau_l={cal[n]['tau_l']:.4f}, held-out ARL "
              f"{val[n]['ARL']:.0f} [{val[n]['ARL_lo']:.0f},{val[n]['ARL_hi']:.0f}] "
              f"({val[n]['events']} events / {val[n]['rounds']} rounds)" for n in dets))
        P(f"(c) Fleet replay, N={N}, F={F}, {len(RUN_SEEDS)} seeds, onset after {PRE} rounds, "
          f"window {POST} rounds. delay = median rounds (cens = not detected); rate = detected; "
          f"succ/harm = successful attacks / harmful calls completed up to the alarm.")
        P(f"{'pool':13s} {'q':>3s} {'p_inj':>5s} | " + " | ".join(
            f"{n:^30s}" for n in dets))
        P(f"{'':13s} {'':>3s} {'':>5s} | " + " | ".join(
            f"{'delay':>6s} {'rate':>5s} {'succ':>7s} {'harm':>7s}" for _ in dets))
        for r in rows:
            if 'skipped' in r:
                P(f"{r['pool']:13s} skipped: {r['skipped']}")
                continue
            P(f"{r['pool']:13s} {r['q']:3d} {r['p_inj']:5.2f} | " + " | ".join(
                f"{fx.fmt(r[n]['delay']):>6s} {r[n]['rate']:5.2f} {r[n]['succ_before']:7.1f} "
                f"{r[n]['harm_before']:7.1f}" for n in dets))
        txt = "\n".join(L)
        print("\n" + txt)
        open(f'results/agentdojo_{tag}.txt', 'w').write(txt + "\n")
        json.dump({'model': model, 'agent': summ, 'edge': ep, 'thresholds': cal,
                   'validation': val, 'rows': rows}, open(f'results/agentdojo_{tag}.json', 'w'),
                  indent=2, default=float)

        ok = [r for r in rows if 'skipped' not in r and r['pool'] == ('success-only' if rp.has_attacks(True) else 'observed')]
        if ok:
            plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})
            fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 3.8))
            for q, mk in zip(QS, 'os^'):
                rr = [r for r in ok if r['q'] == q]
                for n, ls in [('FogDrift', '-'), ('Cent-Hist', '--')]:
                    a1.plot([r['p_inj'] for r in rr], [r[n]['delay'] if np.isfinite(r[n]['delay']) else POST for r in rr],
                            mk + ls, label=f'{n}, q={q}')
                    a2.plot([r['p_inj'] for r in rr], [r[n]['succ_before'] for r in rr], mk + ls, label=f'{n}, q={q}')
            a1.set_xlabel('Injected-task probability $p_{inj}$'); a1.set_ylabel('Median delay (rounds)')
            a2.set_xlabel('Injected-task probability $p_{inj}$'); a2.set_ylabel('Successful attacks before alarm')
            for a in (a1, a2):
                a.grid(alpha=.3, ls='--'); a.legend(fontsize=8)
            fig.suptitle(f'{model}: {ok[0]["pool"]} injected episodes', fontsize=11)
            plt.tight_layout(); plt.savefig(f'results/agentdojo_{tag}.png', dpi=300)
        log(f"saved results/agentdojo_{tag}.txt/.json")


if __name__ == '__main__':
    main()
