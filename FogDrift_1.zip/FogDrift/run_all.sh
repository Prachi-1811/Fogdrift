#!/usr/bin/env bash
# Run every experiment of the paper, then draw the figures.
#   bash run_all.sh          full settings (results as in the paper)
#   bash run_all.sh quick    short pipeline test, noisy numbers
set -e
cd "$(dirname "$0")"
export MPLBACKEND=Agg
MODE="${1:-}"

python check_setup.py

if [ "$MODE" = "quick" ]; then
    # quick mode must not overwrite the calibrated files used by the paper
    echo "quick mode: calibrate.py is skipped, the shipped calibration is used"
else
    python calibrate.py
fi

for s in exp_matched_arl exp_batch_phase exp_workload_invariance exp_localisation \
         exp_dropout exp_bandwidth_cap exp_deployment_stress exp_adaptive \
         exp_ablation exp_scaling exp_warmup exp_autocorrelation \
         exp_autocorr_mitigation exp_cloud_corroboration exp_window_fill \
         exp_tracker_reset exp_persistence_cache exp_partial_coverage \
         exp_baselines_small exp_episode_workload exp_scalar_parity \
         exp_batch_random_phase exp_tuple_buffering exp_small_shift; do
    echo "== $s"
    python "$s.py" $MODE
done

if [ -d InjecAgent/data ]; then
    echo "== exp_injecagent_replay"
    python exp_injecagent_replay.py InjecAgent/data data/injecagent_toolkit_map.json
    python exp_injecagent_identity.py InjecAgent/data data/injecagent_toolkit_map.json $MODE
    python injecagent_traces.py InjecAgent/data data/injecagent_toolkit_map.json
    python exp_agentdojo_replay.py data/injecagent_gt_dh.jsonl data/injecagent_gt_ds.jsonl settle=300 $MODE
else
    echo "InjecAgent/ not found, skipping exp_injecagent_replay"
    echo "  (git clone https://github.com/uiuc-kang-lab/InjecAgent)"
fi

shopt -s nullglob
traces=(data/agentdojo_*.jsonl)
if [ ${#traces[@]} -gt 0 ]; then
    echo "== exp_agentdojo_replay"
    python exp_agentdojo_replay.py "${traces[@]}" $MODE
    runs=(data/agentdojo_runs_*.jsonl)
    [ -e "${runs[0]}" ] && python exp_agentdojo_heldout_tasks.py "${runs[@]}" $MODE
    [ -e "${runs[0]}" ] && python exp_agentdojo_quarantine.py "${runs[@]}" $MODE
else
    echo "no AgentDojo traces in data/, skipping exp_agentdojo_replay"
fi

python figures/plot_paper_figures.py
