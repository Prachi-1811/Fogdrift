"""Collect live agent tool-call traces on AgentDojo (input to
exp_agentdojo_replay.py, Table XI).

Runs an LLM agent on AgentDojo suites, once on clean user tasks (benign
utility) and once with prompt injections (attack success), and stores every
episode's tool-call sequence.

Install (separate from the simulator requirements):
    pip install "agentdojo==0.1.35" openai

Any OpenAI-compatible endpoint works (Groq, Together, OpenRouter, vLLM, OpenAI).
Configuration used in the paper (GPT-OSS-20B via Groq, banking suite,
benchmark v1.2.2, 40 attacked pairs, important_instructions attack):
    export GROQ_API_KEY=...
    python agentdojo_collect.py --model openai/gpt-oss-20b \
        --base-url https://api.groq.com/openai/v1 --api-key-env GROQ_API_KEY \
        --suites banking --pairs-per-suite 40 --out data/agentdojo_gptoss20b_banking.jsonl

    # pipeline test without any API key (ground-truth "agent"; not model data)
    python agentdojo_collect.py --dry-run --out traces_dryrun.jsonl

The default attack is AgentDojo's important_instructions attack with a generic
model name, so it works for any model (see register_fd_attack).

Budget: benign = every user task x --benign-reps; attacked = --pairs-per-suite
(user task, injection task) pairs per suite, sampled with a fixed seed
(--all-pairs runs the full 629-pair benchmark). The script is resumable: rerun
the same command and finished episodes are skipped. Rate-limit errors are
retried with exponential backoff.

One JSON line per episode:
  model, suite, user_task, injection_task (null = benign), attack, rep,
  utility, security (True = the injection's goal was achieved),
  calls (function names, in order), args (stringified), n_calls,
  harm_tools (functions in the injection task's ground truth),
  user_gt_tools (functions in the user task's ground truth), error,
  benchmark_version, timestamp.
"""
import argparse
import json
import os
import random
import time
import warnings

warnings.filterwarnings("ignore")


def build_pipeline(args):
    import openai
    from agentdojo.agent_pipeline import AgentPipeline, PipelineConfig
    from agentdojo.agent_pipeline.llms.openai_llm import OpenAILLM
    client = openai.OpenAI(base_url=args.base_url, api_key=os.environ[args.api_key_env],
                           max_retries=0, timeout=120)
    llm = OpenAILLM(client, args.model, temperature=args.temperature)
    cfg = PipelineConfig(llm=llm, model_id=None, defense=args.defense,
                         system_message_name=None, system_message=None)
    pipe = AgentPipeline.from_config(cfg)
    pipe.name = args.model
    return pipe


class Recorder:
    """Wraps a pipeline and keeps the messages of the last query."""
    def __new__(cls, inner):
        from agentdojo.agent_pipeline.base_pipeline_element import BasePipelineElement
        from agentdojo.agent_pipeline.errors import AbortAgentError

        class _Rec(BasePipelineElement):
            def __init__(self, inner):
                self.inner, self.name, self.messages = inner, inner.name, []

            def query(self, query, runtime, env=None, messages=[], extra_args={}):
                try:
                    out = self.inner.query(query, runtime, env, messages, extra_args)
                    self.messages = list(out[3])
                    return out
                except AbortAgentError as e:
                    self.messages = list(e.messages)
                    raise
        return _Rec(inner)


def dry_pipeline(user_task, injection_task, obey):
    """Ground-truth agent: solves the user task, and also executes the
    injection task's ground truth when `obey` (a simulated successful attack)."""
    from agentdojo.agent_pipeline import AgentPipeline
    from agentdojo.agent_pipeline.ground_truth_pipeline import GroundTruthPipeline
    parts = [GroundTruthPipeline(user_task)]
    if injection_task is not None and obey:
        parts.append(GroundTruthPipeline(injection_task))
    p = AgentPipeline(parts)
    p.name = 'dry-run-ground-truth'
    return p


def register_fd_attack():
    """AgentDojo's `important_instructions` template with a generic model name.
    (Its built-in `..._no_model_name` variant still looks the model up in a
    fixed list and fails for open models such as Llama/Qwen/GPT-OSS on Groq.)
    The injected text is identical to `important_instructions_no_model_name`."""
    from agentdojo.attacks import register_attack
    from agentdojo.attacks.attack_registry import ATTACKS
    from agentdojo.attacks.base_attacks import DEFAULT_MODEL_NAME, FixedJailbreakAttack
    from agentdojo.attacks.important_instructions_attacks import ImportantInstructionsAttack
    if 'fd_important_instructions' in ATTACKS:
        return

    class FDImportantInstructions(FixedJailbreakAttack):
        name = 'fd_important_instructions'

        def __init__(self, task_suite, target_pipeline):
            FixedJailbreakAttack.__init__(self, ImportantInstructionsAttack._JB_STRING,
                                          task_suite, target_pipeline)
            self.user_name = 'Emma Johnson'
            self.model_name = DEFAULT_MODEL_NAME
    register_attack(FDImportantInstructions)


def tool_names(calls):
    return sorted({c.function for c in calls})


def gt_tools(task, suite):
    try:
        env = suite.load_and_inject_default_environment({})
        if hasattr(task, 'init_environment'):
            env = task.init_environment(env)
        return tool_names(task.ground_truth(env))
    except Exception:
        return []


def run_episode(suite, rec, user_task, injection_task, injections, retries):
    from agentdojo.task_suite.task_suite import functions_stack_trace_from_messages
    delay = 5.0
    for attempt in range(retries + 1):
        try:
            utility, security = suite.run_task_with_pipeline(
                rec, user_task, injection_task, injections)
            calls = functions_stack_trace_from_messages(rec.messages)
            return utility, security, calls, None
        except Exception as e:                       # rate limits, API errors, tool errors
            msg = f"{type(e).__name__}: {e}"[:300]
            transient = any(s in msg for s in ('RateLimit', '429', 'Timeout', 'APIConnection',
                                                 'InternalServer', '503', '502'))
            if transient and attempt < retries:
                time.sleep(delay)
                delay = min(delay * 2, 300)
                continue
            calls = []
            try:
                calls = functions_stack_trace_from_messages(rec.messages)
            except Exception:
                pass
            return None, None, calls, msg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', default='openai/gpt-oss-20b')
    ap.add_argument('--base-url', default='https://api.groq.com/openai/v1')
    ap.add_argument('--api-key-env', default='GROQ_API_KEY')
    ap.add_argument('--temperature', type=float, default=0.0)
    ap.add_argument('--defense', default=None, help='AgentDojo defense name, default none')
    ap.add_argument('--attack', default='fd_important_instructions',
                    help='fd_important_instructions (default) or any AgentDojo attack name')
    ap.add_argument('--suites', default='banking')
    ap.add_argument('--benchmark-version', default='v1.2.2')
    ap.add_argument('--benign-reps', type=int, default=1)
    ap.add_argument('--pairs-per-suite', type=int, default=40)
    ap.add_argument('--all-pairs', action='store_true')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--retries', type=int, default=6)
    ap.add_argument('--sleep', type=float, default=0.0, help='pause between episodes (s)')
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--out', required=True)
    args = ap.parse_args()

    from agentdojo.attacks import load_attack
    from agentdojo.task_suite.load_suites import get_suites
    if args.dry_run:
        args.model = 'dry-run-ground-truth'
    register_fd_attack()

    done = set()
    if os.path.exists(args.out):
        for line in open(args.out):
            try:
                r = json.loads(line)
                if r.get('error') is None:
                    done.add((r['suite'], r['user_task'], r['injection_task'], r['rep']))
            except Exception:
                pass
    fh = open(args.out, 'a')
    suites = get_suites(args.benchmark_version)
    base = None if args.dry_run else build_pipeline(args)
    rng = random.Random(args.seed)
    t0 = time.time()
    n_new = 0

    for sname in args.suites.split(','):
        suite = suites[sname]
        users = list(suite.user_tasks.values())
        injs = list(suite.injection_tasks.values())
        pairs = [(u, i) for u in users for i in injs]
        if not args.all_pairs:
            pairs = rng.sample(pairs, min(args.pairs_per_suite, len(pairs)))
        jobs = [(u, None, rep) for u in users for rep in range(args.benign_reps)]
        jobs += [(u, i, 0) for (u, i) in pairs]
        gt_cache = {}
        attack = None
        for k, (u, inj, rep) in enumerate(jobs):
            key = (sname, u.ID, None if inj is None else inj.ID, rep)
            if key in done:
                continue
            if args.dry_run:
                pipe = dry_pipeline(u, inj, obey=(k % 2 == 0))
            else:
                pipe = base
            rec = Recorder(pipe)
            injections = {}
            if inj is not None:
                if attack is None:
                    attack = load_attack(args.attack, suite, rec)
                injections = attack.attack(u, inj)
            ut, sec, calls, err = run_episode(suite, rec, u, inj, injections, args.retries)
            if u.ID not in gt_cache:
                gt_cache[u.ID] = gt_tools(u, suite)
            harm = [] if inj is None else gt_cache.setdefault(inj.ID, gt_tools(inj, suite))
            rec_out = {
                'model': args.model, 'suite': sname, 'user_task': u.ID,
                'injection_task': None if inj is None else inj.ID,
                'attack': None if inj is None else args.attack, 'rep': rep,
                'utility': ut, 'security': sec if inj is not None else None,
                'calls': [c.function for c in calls],
                'args': [json.dumps(dict(c.args), default=str)[:500] for c in calls],
                'n_calls': len(calls), 'harm_tools': harm,
                'user_gt_tools': gt_cache[u.ID], 'error': err,
                'benchmark_version': args.benchmark_version,
                'defense': args.defense, 'temperature': args.temperature,
                'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
            }
            fh.write(json.dumps(rec_out) + "\n")
            fh.flush()
            n_new += 1
            if n_new % 10 == 0:
                print(f"[{(time.time()-t0)/60:5.1f} min] {sname} {k+1}/{len(jobs)} episodes", flush=True)
            if args.sleep:
                time.sleep(args.sleep)
    print(f"done: {n_new} new episodes -> {args.out}")


if __name__ == '__main__':
    main()
