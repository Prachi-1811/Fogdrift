"""Autocorrelated benign traffic and recalibration (Table XIII).

    python exp_autocorrelation.py          # ~20 min
    python exp_autocorrelation.py quick    # ~3 min, noisy

Needs edge_params.json and calibration.json (calibrate.py) for the i.i.d.
baseline.

Sticky-tool model: an agent repeats its previous tool in a context with
probability rho, otherwise draws from P0 (rho = 0 is i.i.d.); the marginal
P(t|c) is unchanged. For each rho:

  1. edge parameters (Delta_TV, Delta_0, Delta_cum) are re-estimated on
     autocorrelated null streams;
  2. tau_a, tau_l are re-calibrated end to end (procedure of calibrate.py) on
     autocorrelated null streams, with P0 from an autocorrelated warm-up;
  3. the recalibrated thresholds are validated on HELD-OUT autocorrelated null
     streams: endpoint ARL with exact Poisson CI, duty cycle and mean
     alarm-episode length (duty = mean episode length / ARL);
  4. detection delay and rate under policy poisoning (m=0.5 and m=0.15) are
     measured at the recalibrated thresholds;
  5. for comparison, the same held-out streams are scored with the i.i.d.
     (rho=0) thresholds and edge parameters.

FogDrift and the trigger-off detector (Centralised-Histogram) are both run.
Outputs: results/autocorrelation.txt, results/autocorrelation.json,
         results/autocorrelation.png
"""
import json
import os
import sys
import time
from dataclasses import fields
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)

RHOS = [0.0, 0.3, 0.5, 0.7]
EDGE_SEEDS = list(range(10))
CAL_SEEDS = list(range(1400, 1410))
VAL_SEEDS = list(range(1420, 1430))
RUN_SEEDS = list(range(1440, 1470))
ROUNDS = 5000
MAGS = [0.5, 0.15]
PRE, POST = 60, 100
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    RHOS = [0.0, 0.3]
    EDGE_SEEDS, CAL_SEEDS, VAL_SEEDS = list(range(3)), list(range(1400, 1403)), list(range(1420, 1423))
    RUN_SEEDS, ROUNDS = list(range(1440, 1446)), 1500
    print("QUICK MODE: noisy")
TARGET = 1000
KP = fc.DEFAULT.KP
BURN = 30
DETS = {'FogDrift': dict(), 'Cent-Hist': dict(trigger=False)}


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


def stream(seed, cfg, rho, rounds, P_attack=None, onset=None, seed_offset=0):
    """Autocorrelated stream: P0 from an autocorrelated warm-up of W0 rounds,
    then `rounds` monitored rounds (attack from `onset` if given)."""
    rng = np.random.default_rng(seed + seed_offset)
    P_true = fc.build_P0(rng, cfg)
    pi = np.ones(cfg.L) / cfg.L
    gen = fx.StickyGen(cfg, rho)
    warm = [gen(rng, P_true, pi) for _ in range(cfg.W0)]
    P0 = fx.estimate_P0_from(warm, cfg)
    Pd = None if P_attack is None else P_attack(P_true, seed)
    batches = [gen(rng, Pd if (onset is not None and r >= onset) else P_true, pi)
               for r in range(rounds)]
    return P0, batches


def edge_params(cfg, rho):
    def make_stream(seed):
        rng = np.random.default_rng(20_000 + seed)
        P = fc.build_P0(rng, cfg)
        pi = np.ones(cfg.L) / cfg.L
        gen = fx.StickyGen(cfg, rho)
        P0 = fx.estimate_P0_from([gen(rng, P, pi) for _ in range(cfg.W0)], cfg)
        return P0, (lambda: gen(rng, P, pi))
    return fx.calibrate_edge_params_gen(make_stream, EDGE_SEEDS, cfg)


def null_sigs(cfg_d, det_kw, seeds, rho):
    out = []
    for s in seeds:
        P0, b = stream(s, cfg_d, rho, ROUNDS)
        out.append(fx.trim(fx.run_detector(fx.HCDDX(P0, cfg_d, **det_kw), b), BURN))
    return out


def delays(cfg_d, det_kw, th, rho, m):
    att = lambda P, seed: fc.drifted(P, 'policy', m, seed)
    ds = []
    for s in RUN_SEEDS:
        P0, b = stream(s, cfg_d, rho, PRE + POST, P_attack=att, onset=PRE)
        sig = fx.run_detector(fx.HCDDX(P0, cfg_d, **det_kw), b)
        _, st, sr = fc.endpoint_fog(sig, th['tau_a'], th['tau_l'], KP)
        ds.append(fc.detection_delay(st, sr, PRE, KP))
    return ds


def main():
    t0 = time.time()
    log = lambda msg: print(f"[{(time.time()-t0)/60:5.1f} min] {msg}", flush=True)
    cfg_iid = load_cfg()
    cal_iid = json.load(open('calibration.json'))[str(TARGET)]
    res = {}
    for rho in RHOS:
        cfg_r, ep = edge_params(cfg_iid, rho)
        log(f"rho={rho}: edge params DTV={ep['DTV']:.3f} D0={ep['D0']:.3f} DCUM={ep['DCUM']:.3f}")
        for det, kw in DETS.items():
            cfg_d = cfg_r if det == 'FogDrift' else cfg_iid
            th = fx.calibrate_endpoint(null_sigs(cfg_d, kw, CAL_SEEDS, rho), TARGET, KP)
            val = null_sigs(cfg_d, kw, VAL_SEEDS, rho)
            prof = fx.alarm_profile([fc.endpoint_fog(s, th['tau_a'], th['tau_l'], KP)[0]
                                     for s in val])
            # same held-out streams under the i.i.d. (calibrate.py) parameters + thresholds
            cfg_old = cfg_iid
            val_old = val if det != 'FogDrift' else null_sigs(cfg_old, kw, VAL_SEEDS, rho)
            th_old = cal_iid[det]
            prof_old = fx.alarm_profile([fc.endpoint_fog(s, th_old['tau_a'], th_old['tau_l'], KP)[0]
                                         for s in val_old])
            det_res = {}
            for m in MAGS:
                ds = delays(cfg_d, kw, th, rho, m)
                det_res[m] = {'median': fx.med(ds), 'rate': float(np.mean([d is not None for d in ds]))}
            res[(rho, det)] = {'edge': ep if det == 'FogDrift' else None, 'th': th,
                               'recal': prof, 'iid': prof_old, 'detect': det_res,
                               'tx_note': None}
            log(f"rho={rho} {det}: recal ARL={prof['ARL']:.0f} "
                f"[{prof['ARL_lo']:.0f},{prof['ARL_hi']:.0f}] duty={prof['duty']:.4f}; "
                f"iid-threshold duty={prof_old['duty']:.4f}; "
                + "; ".join(f"m={m}: {fx.fmt(v['median'])} ({v['rate']:.2f})" for m, v in det_res.items()))

    L = []
    P = L.append
    P(f"Autocorrelated benign traffic (sticky-tool rho), recalibration on the deployment's own "
      f"traffic. Target ARL0={TARGET}. Calibration {len(CAL_SEEDS)}x{ROUNDS} null rounds, "
      f"held-out validation {len(VAL_SEEDS)}x{ROUNDS} (first {BURN} of each stream dropped), "
      f"detection over {len(RUN_SEEDS)} seeds (policy poisoning, onset after {PRE} rounds).")
    P("")
    P(f"{'rho':>4s} {'detector':10s} | {'i.i.d. thresholds':^27s} | {'recalibrated at rho':^44s} | "
      + " ".join(f"{'m=' + str(m):>12s}" for m in MAGS))
    P(f"{'':>4s} {'':10s} | {'ARL':>8s} {'duty':>8s} {'ep.len':>7s} | "
      f"{'tau_a':>6s} {'tau_l':>7s} {'ARL [95% CI]':>19s} {'duty':>7s} | "
      + " ".join(f"{'delay (rate)':>12s}" for _ in MAGS))
    for rho in RHOS:
        for det in DETS:
            x = res[(rho, det)]
            o, r, th = x['iid'], x['recal'], x['th']
            ci = f"{r['ARL']:.0f} [{r['ARL_lo']:.0f},{r['ARL_hi']:.0f}]"
            P(f"{rho:4.1f} {det:10s} | {o['ARL']:8.0f} {o['duty']:8.4f} {o['mean_alarm_len']:7.1f} | "
              f"{th['tau_a']:6.3f} {th['tau_l']:7.4f} {ci:>19s} {r['duty']:7.4f} | "
              + " ".join(f"{fx.fmt(x['detect'][m]['median']):>5s} ({x['detect'][m]['rate']:.2f})"
                         for m in MAGS))
    P("")
    P("Edge parameters re-estimated at each rho (FogDrift): " + "; ".join(
        f"rho={rho}: DTV={res[(rho, 'FogDrift')]['edge']['DTV']:.3f}, "
        f"D0={res[(rho, 'FogDrift')]['edge']['D0']:.3f}, "
        f"DCUM={res[(rho, 'FogDrift')]['edge']['DCUM']:.3f}" for rho in RHOS))
    P("duty = mean alarm-episode length / ARL; ep.len = mean length (rounds) of a null alarm "
      "episode.")
    txt = "\n".join(L)
    print("\n" + txt)
    open('results/autocorrelation.txt', 'w').write(txt + "\n")
    json.dump({f"{k[0]}|{k[1]}": v for k, v in res.items()}, open('results/autocorrelation.json', 'w'),
              indent=2, default=float)

    plot(res)
    log("saved results/autocorrelation.txt, autocorrelation.json, autocorrelation.png")


def plot(res):
    """(a) null false-alarm duty cycle (fraction of rounds in alarm) with the
    i.i.d. thresholds vs thresholds recalibrated at rho; (b) median delay at
    the recalibrated thresholds. Duty cycle, not ARL, is plotted in (a): with
    i.i.d. thresholds at rho >= 0.5 the alarm never switches off, so the
    'ARL' would just be the stream length."""
    rhos = sorted({k[0] for k in res})
    col = {'FogDrift': 'tab:blue', 'Cent-Hist': 'tab:orange'}
    mk = {'FogDrift': 'o', 'Cent-Hist': '^'}
    plt.rcParams.update({'font.size': 12, 'font.family': 'serif'})
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10.5, 4))
    for det in ['FogDrift', 'Cent-Hist']:
        a1.plot(rhos, [max(res[(r, det)]['iid']['duty'], 1e-4) for r in rhos], mk[det] + '--',
                color=col[det], label=f'{det}, i.i.d. thresholds')
        a1.plot(rhos, [max(res[(r, det)]['recal']['duty'], 1e-4) for r in rhos], mk[det] + '-',
                color=col[det], label=f'{det}, recalibrated at $\\rho$')
        for m, ls in zip(MAGS, ['-', ':']):
            a2.plot(rhos, [res[(r, det)]['detect'][m]['median'] for r in rhos], mk[det] + ls,
                    color=col[det], label=f'{det}, m={m}')
    a1.set_yscale('log')
    a1.set_xlabel(r'Autocorrelation $\rho$'); a1.set_ylabel('Null false-alarm duty cycle')
    a1.set_title('(a) false alarms', fontsize=12)
    a1.legend(fontsize=9, loc='center right'); a1.grid(alpha=.3, ls='--', which='both')
    a2.set_xlabel(r'Autocorrelation $\rho$'); a2.set_ylabel('Median delay (rounds)')
    a2.set_title('(b) delay, recalibrated thresholds', fontsize=12)
    a2.legend(fontsize=9); a2.grid(alpha=.3, ls='--')
    plt.tight_layout(); plt.savefig('results/autocorrelation.png', dpi=300)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'plot':
        raw = json.load(open('results/autocorrelation.json'))
        res = {}
        for k, v in raw.items():
            r, det = k.split('|')
            v['detect'] = {float(m): x for m, x in v['detect'].items()}
            res[(float(r), det)] = v
        MAGS[:] = sorted(next(iter(res.values()))['detect'], reverse=True)
        plot(res)
    else:
        main()
