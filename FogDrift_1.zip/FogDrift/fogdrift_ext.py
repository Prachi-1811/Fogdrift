"""fogdrift_ext.py -- network, trace and calibration helpers built on
fogdrift_core (used by exp_bandwidth_cap.py, exp_autocorrelation.py and
exp_agentdojo_replay.py).

  * HCDDX        FogDrift (Alg. 1) with two extra hooks:
                   - `admit`: an uplink admission callback, so a byte-capped
                     uplink can DEFER a summary (it is not sent, and the edge
                     retries next round with its latest histogram);
                   - `step_events`: variable-length per-agent event lists
                     (recorded agent traces).
                 Bytes are counted only for messages actually put on the link.
  * FogUplink    per-fog edge->fog byte budget (token bucket).
  * CappedCT     Centralised-Tuples with a FIFO tuple queue per agent that
                 drains through FogUplink (tuples wait, they are not lost,
                 except when the per-agent buffer overflows).
  * StickyGen    vectorised sticky-tool autocorrelated event generator.
  * calibrate_edge_params_gen / calibrate_endpoint / arl / Poisson CI
                 the calibration procedure of calibrate.py for any generator.
"""
from collections import deque
from dataclasses import replace
import numpy as np
import fogdrift_core as fc

try:
    from scipy.stats import chi2
except ImportError:                                     # pragma: no cover
    chi2 = None


# --------------------------------------------------------------------------
# ARL, Poisson CI, bisection (same definitions as calibrate.py)
# --------------------------------------------------------------------------
def poisson_ci(events, rounds):
    if chi2 is None:
        return (np.nan, np.nan)
    lo_rate = chi2.ppf(0.025, 2 * events) / 2 / rounds if events > 0 else 0.0
    hi_rate = chi2.ppf(0.975, 2 * (events + 1)) / 2 / rounds
    return (1 / hi_rate, (1 / lo_rate) if lo_rate > 0 else np.inf)


def arl_of(alarms):
    ev = sum(fc.count_events(a) for a in alarms)
    n = sum(len(a) for a in alarms)
    return (n / ev if ev else np.inf), ev, n


def alarm_profile(alarms):
    """ARL, events, rounds, duty cycle and mean alarm-episode length.
    duty = mean_episode_length / ARL (exactly, up to edge effects)."""
    arl, ev, n = arl_of(alarms)
    on = sum(int(np.sum(a)) for a in alarms)
    duty = on / n if n else np.nan
    mean_len = on / ev if ev else np.nan
    lo, hi = poisson_ci(ev, n)
    return {'ARL': arl, 'events': ev, 'rounds': n, 'ARL_lo': lo, 'ARL_hi': hi,
            'duty': duty, 'mean_alarm_len': mean_len}


def smallest_param(fun, lo, hi, target, iters=60, log=True):
    if fun(hi)[0] < target:
        return None
    for _ in range(iters):
        mid = np.sqrt(lo * hi) if log else (lo + hi) / 2
        if fun(mid)[0] >= target:
            hi = mid
        else:
            lo = mid
    return hi


def calibrate_endpoint(sigs, target=1000, kp=2, q=0.999):
    """Calibration procedure of calibrate.py: tau_a, tau_l tied through one factor kappa applied to
    their q null quantiles; kappa bisected so the fog-endpoint ARL >= target."""
    qa = float(np.quantile(np.concatenate([s['fog_amax'].ravel() for s in sigs]), q))
    ql = float(np.quantile(np.concatenate([s['fog_score'].ravel() for s in sigs]), q))

    def f(kappa):
        return arl_of([fc.endpoint_fog(s, kappa * qa, kappa * ql, kp)[0] for s in sigs])
    kappa = smallest_param(f, 0.5, 50.0, target)
    if kappa is None:
        return None
    arl, ev, n = f(kappa)
    return {'tau_a': kappa * qa, 'tau_l': kappa * ql, 'kappa': kappa,
            'cal_ARL': arl, 'cal_events': ev, 'cal_rounds': n}


def trim(sig, burn):
    return {k: v[burn:] for k, v in sig.items()}


# --------------------------------------------------------------------------
# Feeding events: fixed (N,K) arrays or variable-length per-agent lists
# --------------------------------------------------------------------------
def is_list_batch(batch):
    return isinstance(batch, list)


def add_to_windows(win, batch):
    if is_list_batch(batch):
        win.add_events(batch)
    else:
        win.add_round(*batch)


# --------------------------------------------------------------------------
# Uplink with a per-fog byte budget
# --------------------------------------------------------------------------
class FogUplink:
    """Edge->fog uplink of each fog with a budget of `cap_KB` KB per round
    (token bucket, depth = `depth_rounds` x budget, at least one summary).
    cap_KB=None means uncapped. Admission is round-robin over the fog's
    agents, so no agent starves."""
    def __init__(self, cfg, fog_of, cap_KB=None, depth_rounds=2.0):
        self.cfg, self.fog_of = cfg, fog_of
        self.cap = None if cap_KB is None else cap_KB * 1024.0
        if self.cap is not None:
            self.depth = max(depth_rounds * self.cap, fc.edge_msg_bytes(cfg) + 1.0)
            self.tokens = np.full(cfg.F, self.cap)
        self.ptr = np.zeros(cfg.F, dtype=int)
        self.members = [np.where(fog_of == f)[0] for f in range(cfg.F)]

    def new_round(self):
        if self.cap is not None:
            self.tokens = np.minimum(self.tokens + self.cap, self.depth)

    def admit(self, want, nbytes):
        """Whole messages (histogram summaries). want (N,) bool, nbytes (N,)."""
        if self.cap is None:
            return want.copy()
        ok = np.zeros_like(want)
        for f, mem in enumerate(self.members):
            order = np.roll(mem, -self.ptr[f])
            served = 0
            for a in order:
                if not want[a]:
                    continue
                if self.tokens[f] >= nbytes[a]:
                    ok[a] = True
                    self.tokens[f] -= nbytes[a]
                    served += 1
                else:
                    break                      # FIFO fairness: no overtaking
            self.ptr[f] = (self.ptr[f] + max(served, 1)) % len(mem)
        return ok

    def grant_tuples(self, f, backlog):
        """Streamed tuples. backlog: dict agent -> releasable tuple count.
        Returns dict agent -> number of tuples sent this round (each send
        costs one HEADER_B plus TUPLE_B per tuple)."""
        sent = {}
        mem = self.members[f]
        order = np.roll(mem, -self.ptr[f])
        for a in order:
            k = backlog.get(int(a), 0)
            if k <= 0:
                continue
            if self.cap is None:
                sent[int(a)] = k
                continue
            room = int((self.tokens[f] - fc.HEADER_B) // fc.TUPLE_B)
            if room < 1:
                break
            n = min(k, room)
            self.tokens[f] -= fc.HEADER_B + fc.TUPLE_B * n
            sent[int(a)] = n
        if sent:
            self.ptr[f] = (self.ptr[f] + 1) % len(mem)
        return sent


# --------------------------------------------------------------------------
# FogDrift with admission control and variable-length events
# --------------------------------------------------------------------------
class HCDDX(fc.HCDD):
    """fc.HCDD with an uplink-admission hook and variable-length events.
    Identical to fc.HCDD when admit=None and events are (N,K) arrays.
    A summary that is not admitted is NOT counted as sent; the edge keeps it
    pending and sends its latest histogram when admitted (latest-wins)."""
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.deferred = 0
        self.uplink = 0          # edge->fog bytes put on the link (no ACKs, no fog->cloud)

    def step(self, cs, ts, link_up=None, admit=None):
        return self._step((cs, ts), link_up, admit)

    def step_events(self, agent_events, link_up=None, admit=None):
        return self._step(agent_events, link_up, admit)

    def _step(self, batch, link_up, admit):
        cfg = self.cfg
        N = cfg.N
        if link_up is None:
            link_up = np.ones(N, dtype=bool)
        self.r += 1
        add_to_windows(self.win, batch)
        H = fc.smooth(self.win.cnt, cfg)
        n = self.win.cnt.sum(-1)
        self.since += 1
        if self.tracker:
            tv_ref = fc.weighted_tv(H, self.P0[None], n)
            self.S = np.maximum(0.0, self.S + tv_ref - cfg.D0)
        if self.trigger:
            want = fc.weighted_tv(H, self.H_last, n) > cfg.DTV
            if self.tracker:
                want |= self.S > cfg.DCUM
            if self.heartbeat:
                want |= self.since >= cfg.THB
        else:
            want = np.ones(N, dtype=bool)
        attempt = want | self.retry
        msg = fc.edge_msg_bytes(cfg)
        go = attempt if admit is None else admit(attempt, np.full(N, msg))
        ok = go & link_up
        self.sent += go.sum() * msg
        self.uplink += go.sum() * msg
        self.delivered += ok.sum() * msg
        self.tx_agent_rounds += go.sum()
        self.deferred += int((attempt & ~go).sum())
        if self.ack:
            self.sent += ok.sum() * fc.ACK_B
            self.delivered += ok.sum() * fc.ACK_B
            updated = ok
            self.retry = attempt & ~ok
        else:
            updated = go
            self.retry = attempt & ~go
        self.H_last[updated] = H[updated]
        self.S[updated] = 0.0
        self.since[updated] = 0
        self.fH[ok] = H[ok]
        self.fn[ok] = n[ok]
        self.fpi[ok] = self.win.ctx_sum[ok]
        self.fts[ok] = self.r
        has = (self.r - self.fts) <= cfg.TFRESH
        agent, fs, fa, fh = fc.fog_signals(self.fH, self.fn, self.fpi, has,
                                           self.fog_of, self.P0, cfg)
        f2c = fc.fog_msg_bytes(cfg, cfg.TOPK) * fh.sum()
        self.sent += f2c
        self.delivered += f2c
        return {'fog_score': fs, 'fog_amax': fa, 'fog_has': fh, 'agent': agent,
                'n_tx': int(go.sum()), 'sent': self.sent, 'deliv': self.delivered,
                'age': float(np.mean(self.r - self.fts))}


class CappedCT:
    """Centralised-Tuples through a byte-capped uplink. Every agent appends
    its (c,t) tuples to a FIFO queue; tuples become releasable at each batch
    boundary (every B rounds) and then drain, oldest first, as fast as the
    fog's uplink budget allows. Nothing is lost unless an agent's queue
    exceeds `buffer_cap` tuples (oldest dropped and counted). The cloud
    rebuilds windows only from tuples that arrived.
    buffer='ring': each agent keeps only the W most recent unsent tuples of
    each context (older ones dropped and counted), at most L*W tuples.
    drain='newest' sends the most recent releasable tuples first."""
    def __init__(self, P0, cfg, B, uplink, buffer_cap=5000, name=None, phase=0,
                 buffer='fifo', drain='oldest'):
        self.P0, self.cfg, self.B, self.up, self.cap = P0, cfg, B, uplink, buffer_cap
        self.ring, self.newest = buffer == 'ring', drain == 'newest'
        self.name = name or f"CT(B={B})"
        self.win = fc.Windows(cfg)
        self.fog_of = np.arange(cfg.N) % cfg.F
        self.q = [deque() for _ in range(cfg.N)]
        self.rel = np.zeros(cfg.N, dtype=int)
        self.r = phase                       # shifts the batch boundaries
        self.sent = 0
        self.uplink = 0
        self.dropped = 0
        self.generated = 0

    def backlog_tuples(self):
        return int(sum(len(x) for x in self.q))

    def step(self, cs, ts, link_up=None):
        cfg = self.cfg
        self.r += 1
        for i in range(cfg.N):
            self.q[i].extend(zip(cs[i].tolist(), ts[i].tolist()))
            self.generated += cs.shape[1]
            over = len(self.q[i]) - self.cap
            if over > 0:
                for _ in range(over):
                    self.q[i].popleft()
                self.dropped += over
                self.rel[i] = max(0, self.rel[i] - over)
            if self.ring:
                items = list(self.q[i])
                seen, keep = {}, []
                for j in range(len(items) - 1, -1, -1):
                    c = items[j][0]
                    if seen.get(c, 0) < cfg.W:
                        seen[c] = seen.get(c, 0) + 1
                        keep.append(j)
                if len(keep) < len(items):
                    keep.reverse()
                    self.dropped += len(items) - len(keep)
                    self.rel[i] = sum(j < self.rel[i] for j in keep)
                    self.q[i] = deque(items[j] for j in keep)
        if self.r % self.B == 0:
            self.rel[:] = [len(x) for x in self.q]
        arrived = [(np.array([], int), np.array([], int)) for _ in range(cfg.N)]
        for f in range(cfg.F):
            backlog = {int(a): int(self.rel[a]) for a in self.up.members[f] if self.rel[a] > 0}
            grant = self.up.grant_tuples(f, backlog)
            for a, k in grant.items():
                if self.newest:                  # the k most recent releasable tuples
                    q = list(self.q[a])
                    r0 = self.rel[a]
                    items = q[r0 - k:r0]
                    self.q[a] = deque(q[:r0 - k] + q[r0:])
                else:
                    items = [self.q[a].popleft() for _ in range(k)]
                self.rel[a] -= k
                self.sent += fc.HEADER_B + fc.TUPLE_B * k + fc.ACK_B
                self.uplink += fc.HEADER_B + fc.TUPLE_B * k
                arrived[a] = (np.array([c for c, _ in items], int),
                              np.array([t for _, t in items], int))
        self.win.add_events(arrived)
        H = fc.smooth(self.win.cnt, cfg)
        n = self.win.cnt.sum(-1)
        has = n.sum(-1) > 0
        agent, fs, fa, fh = fc.fog_signals(H, n, self.win.ctx_sum, has,
                                           self.fog_of, self.P0, cfg)
        return {'fog_score': fs, 'fog_amax': fa, 'fog_has': fh, 'agent': agent,
                'n_tx': 0, 'sent': self.sent, 'deliv': self.sent, 'age': 0.0}


# --------------------------------------------------------------------------
# Autocorrelated (sticky-tool) generator
# --------------------------------------------------------------------------
class StickyGen:
    """With probability rho an agent repeats its previous tool in that context,
    otherwise it draws afresh from P. The marginal P(t|c) is unchanged for any
    rho (rho=0 is the i.i.d. model). Vectorised over agents; one object per
    stream (it keeps each agent's last tool per context)."""
    def __init__(self, cfg, rho):
        self.cfg, self.rho = cfg, rho
        self.last = np.full((cfg.N, cfg.L), -1)

    def __call__(self, rng, P, pi):
        cfg = self.cfg
        N, K = cfg.N, cfg.K
        cs = rng.choice(cfg.L, size=(N, K), p=pi)
        Pa = np.broadcast_to(P, (N, cfg.L, cfg.M)) if P.ndim == 2 else P
        ts = np.empty((N, K), dtype=int)
        idx = np.arange(N)
        for k in range(K):
            c = cs[:, k]
            cdf = np.cumsum(Pa[idx, c], -1)
            fresh = np.minimum((rng.random(N)[:, None] > cdf).sum(-1), cfg.M - 1)
            prev = self.last[idx, c]
            stick = (prev >= 0) & (rng.random(N) < self.rho)
            t = np.where(stick, prev, fresh)
            ts[:, k] = t
            self.last[idx, c] = t
        return cs, ts


def estimate_P0_from(batches, cfg):
    """Laplace-smoothed fleet reference from a list of warm-up batches."""
    cnt = np.zeros((cfg.L, cfg.M))
    for b in batches:
        if is_list_batch(b):
            for c, t in b:
                if len(c):
                    np.add.at(cnt, (np.asarray(c), np.asarray(t)), 1)
        else:
            cs, ts = b
            np.add.at(cnt, (cs.ravel(), ts.ravel()), 1)
    return (cnt + cfg.alpha) / (cnt.sum(1, keepdims=True) + cfg.M * cfg.alpha)


def calibrate_edge_params_gen(make_stream, seeds, cfg, rounds=400, burn=30,
                              q_tv=0.99, k_sd=1.0, q_cum=0.99):
    """fc.calibrate_edge_params for any event source.
    make_stream(seed) -> (P0, next_batch) where next_batch() returns one round
    of events ((N,K) arrays or a per-agent list)."""
    tv_lag, tv_ref = [], []
    for seed in seeds:
        P0, nxt = make_stream(seed)
        w = fc.Windows(cfg)
        H_last, lag = None, 0
        for r in range(rounds):
            add_to_windows(w, nxt())
            H = fc.smooth(w.cnt, cfg)
            n = w.cnt.sum(-1)
            if r < burn:
                H_last = H.copy()
                continue
            lag += 1
            if lag == cfg.THB - 1:
                tv_lag.append(fc.weighted_tv(H, H_last, n))
            if lag >= cfg.THB:
                H_last, lag = H.copy(), 0
            tv_ref.append(fc.weighted_tv(H, P0[None], n))
    tv_lag = np.concatenate(tv_lag)
    tv_ref = np.concatenate(tv_ref)
    dtv = float(np.quantile(tv_lag, q_tv))
    d0 = float(tv_ref.mean() + k_sd * tv_ref.std())
    S = np.zeros(cfg.N)
    path = []
    for x in tv_ref.reshape(-1, cfg.N):
        S = np.maximum(0.0, S + x - d0)
        path.append(S.copy())
    dcum = float(max(np.quantile(np.concatenate(path), q_cum), 1e-3))
    return replace(cfg, DTV=dtv, D0=d0, DCUM=dcum), {'DTV': dtv, 'D0': d0, 'DCUM': dcum}


def run_detector(det, batches, link_up=None):
    """Feed a list of batches to an HCDDX (or CappedCT); return signal arrays."""
    sig = {k: [] for k in ['fog_score', 'fog_amax', 'fog_has', 'agent', 'age']}
    for b in batches:
        if isinstance(det, HCDDX):
            o = det.step_events(b) if is_list_batch(b) else det.step(*b)
        else:
            o = det.step(*b)
        for k in sig:
            sig[k].append(o[k])
    return {k: np.array(v) for k, v in sig.items()}


def med(v):
    x = np.array([np.inf if a is None else a for a in v], float)
    return float(np.median(x)) if len(x) else np.nan


def fmt(x, nd=1):
    return 'cens' if x is None or not np.isfinite(x) else f"{x:.{nd}f}"
