"""Autocorrelated traffic without oracle knowledge of rho (Table XIV, Sec. V-N).

    python exp_autocorr_mitigation.py               # all parts, ~60 min
    python exp_autocorr_mitigation.py fixed         # part 1 only
    python exp_autocorr_mitigation.py burst         # part 2 only (needs part 1)
    python exp_autocorr_mitigation.py seeds         # part 3 only
    python exp_autocorr_mitigation.py report        # rebuild the table from saved parts
    add `quick` to any of these for a short, noisy pipeline test

Needs edge_params.json, calibration.json and results/autocorrelation.json
(exp_autocorrelation.py) for the i.i.d. and recalibrated reference points.
Traffic follows the sticky-tool model of exp_autocorrelation.py: an agent
repeats its previous tool in a context with probability rho, otherwise it
draws from P0, so P(t|c) is unchanged.

Part 1 (fixed rho in {0, 0.3, 0.5, 0.7}). Five ways to run FogDrift, none of
which is told rho:
  dedup      edge drops a call that repeats the agent's previous tool in the
             same context; thresholds calibrated once on i.i.d. traffic.
             For the sticky model the retained sequence has the same law at
             every rho (only its rate changes), and the W = 20 windows are
             count-based, so the null score distribution does not depend on rho.
             The warm-up is count-based too: it ends when every context holds
             N_REF retained calls (about W0 = 50 rounds at rho = 0), so the
             reference P0_hat has the same precision at every rho.
  sub1       edge keeps one randomly chosen call per agent per round (one call
             per episode); thresholds calibrated once on i.i.d. traffic.
  ESS        i.i.d. thresholds scaled by the variance-inflation factor
             (1 + rho_hat) / (1 - rho_hat), i.e. n_eff = n (1 - rho_hat) /
             (1 + rho_hat); KL thresholds scale by the factor, the TV-based edge
             parameters by its square root. rho_hat is estimated per deployment
             from its own W0 = 50 warm-up rounds:
             rho_hat = (r - s) / (1 - s), r = observed repeat rate within
             (agent, context), s = sum_t P0_hat(t|c)^2.
  MB-50,     Markov bootstrap: from W0 = 50 or 200 live warm-up rounds of each
  MB-200     calibration deployment, estimate a first-order transition matrix
             per context (pooled over agents, shrunk towards P0_hat). Generate
             synthetic deployments from it (synthetic warm-up -> synthetic
             reference -> 5000 synthetic monitored rounds) and run the full
             calibration (edge parameters and tau_a, tau_l) on them.
For each: held-out ARL on real autocorrelated streams (same held-out seeds as
exp_autocorrelation.py), duty cycle, bytes per round, and the median delay
under policy poisoning (m = 0.5, 0.15).

Part 2 (non-stationary rho). Deployments run at rho = 0.3 and enter benign
bursts of rho = 0.7 (50 rounds, every 500 rounds; P(t|c) unchanged), on one
fog (10 agents) or on the whole fleet. Warm-up and calibration see no burst.
Reported: false-alarm events per burst, ARL outside bursts and overall.

Part 3 (calibration variance). The recalibration of exp_autocorrelation.py
is repeated on 5 disjoint blocks of calibration and held-out seeds at
rho = 0 and 0.7, for FogDrift and Centralised-Histogram. Reported: held-out
ARL of each block, and the dispersion of alarm events across held-out
streams (variance / mean; 1 for Poisson events).

Outputs: results/autocorr_mitigation.txt, results/autocorr_mitigation.json
"""
import json
import os
import sys
import time
from dataclasses import fields, replace

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)

ARGS = sys.argv[1:]
QUICK = 'quick' in ARGS
PART = next((a for a in ARGS if a in ('fixed', 'burst', 'seeds', 'report')), 'all')

TARGET = 1000
KP = fc.DEFAULT.KP
BURN = 30
RHOS = [0.0, 0.3, 0.5, 0.7]
EDGE_SEEDS = list(range(10))
CAL_SEEDS = list(range(1400, 1410))      # as exp_autocorrelation.py
VAL_SEEDS = list(range(1420, 1430))      # as exp_autocorrelation.py
RUN_SEEDS = list(range(1440, 1470))      # as exp_autocorrelation.py
ROUNDS = 5000
PRE, POST = 60, 100
MAGS = [0.5, 0.15]
W0_BOOT = [50, 200]
RHO_BASE, RHO_BURST = 0.3, 0.7
BURST_LEN, BURST_EVERY, BURST_FIRST = 50, 500, 250
BURST_TAIL = 20                          # alarms starting up to 20 rounds after a burst count for it
BLOCKS = 5
N_REF = 4000                             # retained warm-up calls per context (dedup)
SEED_RHOS = [0.0, 0.7]
if QUICK:
    RHOS = [0.0, 0.7]
    EDGE_SEEDS, CAL_SEEDS, VAL_SEEDS = list(range(3)), CAL_SEEDS[:3], VAL_SEEDS[:3]
    RUN_SEEDS, ROUNDS, BLOCKS = RUN_SEEDS[:6], 1500, 2
    W0_BOOT = [50]
    print("QUICK MODE: noisy")
OUT = 'results/autocorr_mitigation'
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


# --------------------------------------------------------------------------
# Traffic
# --------------------------------------------------------------------------
class Sticky:
    """Sticky-tool generator with a per-agent, per-round rho (rho_of(g) -> (N,)
    for global round g). With a constant rho it draws exactly the same events
    as fx.StickyGen for the same rng."""
    def __init__(self, cfg, rho_of):
        self.cfg, self.rho_of = cfg, rho_of
        self.last = np.full((cfg.N, cfg.L), -1)
        self.g = 0

    def __call__(self, rng, P, pi):
        cfg = self.cfg
        N, K = cfg.N, cfg.K
        rho = self.rho_of(self.g)
        self.g += 1
        cs = rng.choice(cfg.L, size=(N, K), p=pi)
        Pa = np.broadcast_to(P, (N, cfg.L, cfg.M)) if P.ndim == 2 else P
        ts = np.empty((N, K), dtype=int)
        idx = np.arange(N)
        for k in range(K):
            c = cs[:, k]
            cdf = np.cumsum(Pa[idx, c], -1)
            fresh = np.minimum((rng.random(N)[:, None] > cdf).sum(-1), cfg.M - 1)
            prev = self.last[idx, c]
            stick = (prev >= 0) & (rng.random(N) < rho)
            t = np.where(stick, prev, fresh)
            ts[:, k] = t
            self.last[idx, c] = t
        return cs, ts


def const_rho(cfg, rho):
    v = np.full(cfg.N, float(rho))
    return lambda g: v


def burst_rho(cfg, agents):
    """rho = RHO_BASE, and RHO_BURST for `agents` during the bursts. Bursts are
    placed in monitored rounds only (global round g >= W0)."""
    base = np.full(cfg.N, RHO_BASE)
    hot = base.copy()
    hot[agents] = RHO_BURST

    def f(g):
        m = g - cfg.W0
        return hot if (m >= 0 and BURST_FIRST <= m % BURST_EVERY < BURST_FIRST + BURST_LEN) else base
    return f


def in_burst(m):
    return BURST_FIRST <= m % BURST_EVERY < BURST_FIRST + BURST_LEN


class MarkovGen:
    """First-order Markov tool sequence per (agent, context): the first call in
    a context is drawn from P0[c], later calls from T[c, previous tool]."""
    def __init__(self, cfg, T, P0):
        self.cfg, self.T, self.P0 = cfg, T, P0
        self.last = np.full((cfg.N, cfg.L), -1)

    def __call__(self, rng, P_unused, pi):
        cfg = self.cfg
        N, K = cfg.N, cfg.K
        cs = rng.choice(cfg.L, size=(N, K), p=pi)
        ts = np.empty((N, K), dtype=int)
        idx = np.arange(N)
        for k in range(K):
            c = cs[:, k]
            prev = self.last[idx, c]
            rows = np.where((prev >= 0)[:, None], self.T[c, np.maximum(prev, 0)], self.P0[c])
            cdf = np.cumsum(rows, -1)
            t = np.minimum((rng.random(N)[:, None] > cdf).sum(-1), cfg.M - 1)
            ts[:, k] = t
            self.last[idx, c] = t
        return cs, ts


class EdgeFilter:
    """Edge-side preprocessing of an agent's own calls before its window.
    'none'  : unchanged (N,K) arrays
    'dedup' : drop a call that repeats the agent's previous tool in that context
    'sub1'  : keep one randomly chosen call per agent per round"""
    def __init__(self, kind, cfg, seed):
        self.kind, self.cfg = kind, cfg
        self.last = np.full((cfg.N, cfg.L), -1)
        self.rng = np.random.default_rng(777_000 + seed)

    def __call__(self, batch):
        if self.kind == 'none':
            return batch
        cs, ts = batch
        N, K = cs.shape
        if self.kind == 'sub1':
            j = self.rng.integers(0, K, N)
            return [(cs[i, j[i]:j[i] + 1], ts[i, j[i]:j[i] + 1]) for i in range(N)]
        keep = np.ones((N, K), dtype=bool)
        idx = np.arange(N)
        for k in range(K):
            c, t = cs[:, k], ts[:, k]
            keep[:, k] = self.last[idx, c] != t
            self.last[idx, c] = t
        return [(cs[i, keep[i]], ts[i, keep[i]]) for i in range(N)]


def deployment(seed, cfg, rho_of, rounds, filt='none', P_attack=None, onset=None, w0_extra=0):
    """One deployment: true P0, W0 warm-up rounds (reference estimate), then
    `rounds` monitored rounds. Returns (P0_hat, monitored batches, raw warm-up
    batches). With w0_extra > 0 the raw warm-up is extended by that many
    rounds (used only to fit the bootstrap model; monitoring starts after)."""
    rng = np.random.default_rng(seed)
    P_true = fc.build_P0(rng, cfg)
    pi = np.ones(cfg.L) / cfg.L
    gen = Sticky(cfg, rho_of)
    ef = EdgeFilter(filt, cfg, seed)
    raw = [gen(rng, P_true, pi) for _ in range(cfg.W0)]
    kept = [ef(b) for b in raw]
    if filt == 'dedup':                                  # count-based warm-up
        while ctx_counts(kept, cfg).min() < N_REF:
            raw.append(gen(rng, P_true, pi))
            kept.append(ef(raw[-1]))
    P0 = fx.estimate_P0_from(kept, cfg)
    raw += [gen(rng, P_true, pi) for _ in range(w0_extra)]
    if rounds == 0:
        return P0, [], raw
    Pd = None if P_attack is None else P_attack(P_true, seed)
    batches = [ef(gen(rng, Pd if (onset is not None and r >= onset) else P_true, pi))
               for r in range(rounds)]
    return P0, batches, raw


def ctx_counts(batches, cfg):
    n = np.zeros(cfg.L)
    for b in batches:
        if fx.is_list_batch(b):
            for c, _ in b:
                n += np.bincount(c, minlength=cfg.L)
        else:
            n += np.bincount(b[0].ravel(), minlength=cfg.L)
    return n


# --------------------------------------------------------------------------
# Estimation from a warm-up
# --------------------------------------------------------------------------
def transition_counts(raw, cfg):
    C = np.zeros((cfg.L, cfg.M, cfg.M))
    last = np.full((cfg.N, cfg.L), -1)
    idx = np.arange(cfg.N)
    for cs, ts in raw:
        for k in range(cs.shape[1]):
            c, t = cs[:, k], ts[:, k]
            prev = last[idx, c]
            ok = prev >= 0
            np.add.at(C, (c[ok], prev[ok], t[ok]), 1)
            last[idx, c] = t
    return C


def rho_hat(raw, cfg):
    """Repeat-rate estimator: r = rho + (1 - rho) s with s = sum_t p_t^2."""
    C = transition_counts(raw, cfg)
    P = fx.estimate_P0_from(raw, cfg)
    n = C.sum((1, 2))
    r = np.trace(C, axis1=1, axis2=2) / np.maximum(n, 1)
    s = (P ** 2).sum(1)
    rc = np.clip((r - s) / (1 - s), 0.0, 0.95)
    return float((rc * n).sum() / n.sum())


def fit_markov(raw, cfg, beta=1.0):
    """Per-context transition matrix, shrunk towards the i.i.d. row P0_hat[c]
    with a pseudo-count of beta per row."""
    C = transition_counts(raw, cfg)
    P = fx.estimate_P0_from(raw, cfg)
    T = (C + beta * P[:, None, :]) / (C.sum(-1, keepdims=True) + beta)
    return T, P


def synthetic(T, P, cfg, seed, rounds):
    """Synthetic deployment from a fitted Markov model, with its own
    synthetic warm-up and reference estimate."""
    rng = np.random.default_rng(90_000 + seed)
    pi = np.ones(cfg.L) / cfg.L
    gen = MarkovGen(cfg, T, P)
    P0 = fx.estimate_P0_from([gen(rng, None, pi) for _ in range(cfg.W0)], cfg)
    return P0, [gen(rng, None, pi) for _ in range(rounds)], gen, rng, pi


# --------------------------------------------------------------------------
# Running the detector
# --------------------------------------------------------------------------
def run(cfg_d, P0, batches, det_kw):
    det = fx.HCDDX(P0, cfg_d, **det_kw)
    sig = fx.run_detector(det, batches)
    return sig, det.sent


def edge_params_from(make_stream, seeds, cfg):
    return fx.calibrate_edge_params_gen(make_stream, seeds, cfg)


def edge_params_real(cfg, rho, filt, seeds):
    def make_stream(seed):
        rng = np.random.default_rng(20_000 + seed)
        P = fc.build_P0(rng, cfg)
        pi = np.ones(cfg.L) / cfg.L
        gen = Sticky(cfg, const_rho(cfg, rho))
        ef = EdgeFilter(filt, cfg, 20_000 + seed)
        kept = [ef(gen(rng, P, pi)) for _ in range(cfg.W0)]
        while filt == 'dedup' and ctx_counts(kept, cfg).min() < N_REF:
            kept.append(ef(gen(rng, P, pi)))
        P0 = fx.estimate_P0_from(kept, cfg)
        return P0, (lambda: ef(gen(rng, P, pi)))
    return edge_params_from(make_stream, seeds, cfg)


def null_real(cfg_d, seeds, rho_of, filt='none', det_kw=None, th_of=None):
    """Held-out null streams. th_of(raw warm-up) -> (cfg, tau_a, tau_l) lets
    a deployment set its own parameters from its warm-up (ESS)."""
    out = []
    for s in seeds:
        P0, b, raw = deployment(s, cfg_d, rho_of, ROUNDS, filt)
        c = cfg_d if th_of is None else th_of(raw)[0]
        sig, sent = run(c, P0, b, det_kw or {})
        out.append((fx.trim(sig, BURN), sent / ROUNDS / 1024, raw))
    return out


def warmup_rounds(sigs):
    return float(np.mean([len(s[2]) for s in sigs]))


def alarms(sigs, th, th_of=None):
    res = []
    for sig, _, raw in sigs:
        ta, tl = (th['tau_a'], th['tau_l']) if th_of is None else th_of(raw)[1:]
        res.append(fc.endpoint_fog(sig, ta, tl, KP)[0])
    return res


def calibrate(sigs):
    return fx.calibrate_endpoint([s[0] for s in sigs], TARGET, KP)


def delays(cfg_d, rho, filt, th, det_kw=None, th_of=None):
    out = {}
    for m in MAGS:
        att = (lambda mm: (lambda P, seed: fc.drifted(P, 'policy', mm, seed)))(m)
        ds = []
        for s in RUN_SEEDS:
            P0, b, raw = deployment(s, cfg_d, const_rho(cfg_d, rho), PRE + POST, filt,
                                    P_attack=att, onset=PRE)
            c, ta, tl = (cfg_d, th['tau_a'], th['tau_l']) if th_of is None else th_of(raw)
            sig, _ = run(c, P0, b, det_kw or {})
            _, st, sr = fc.endpoint_fog(sig, ta, tl, KP)
            ds.append(fc.detection_delay(st, sr, PRE, KP))
        out[m] = {'median': fx.med(ds), 'rate': float(np.mean([d is not None for d in ds]))}
    return out


def summary(sigs, th, th_of=None):
    p = fx.alarm_profile(alarms(sigs, th, th_of))
    p['KB'] = float(np.mean([s[1] for s in sigs]))
    p['warmup'] = warmup_rounds(sigs)
    return p


def ess_rule(cfg_iid, th_iid):
    def th_of(raw):
        r = rho_hat(raw, cfg_iid)
        vif = (1 + r) / (1 - r)
        sq = np.sqrt(vif)
        c = replace(cfg_iid, DTV=cfg_iid.DTV * sq, D0=cfg_iid.D0 * sq, DCUM=cfg_iid.DCUM * sq)
        return c, th_iid['tau_a'] * vif, th_iid['tau_l'] * vif
    return th_of


def calibrate_bootstrap(cfg_iid, rho, w0):
    """Edge parameters and thresholds from synthetic deployments fitted to
    the first w0 live rounds of each calibration deployment."""
    models = {}
    for s in CAL_SEEDS:
        _, _, raw = deployment(s, cfg_iid, const_rho(cfg_iid, rho), 0, w0_extra=w0 - cfg_iid.W0)
        models[s] = fit_markov(raw, cfg_iid)
    rho_fit = []
    for s, (T, P) in models.items():
        d = np.einsum('lmm->lm', T)
        rho_fit.append(float(np.mean((d - P) / (1 - P))))

    def make_stream(i):
        s = CAL_SEEDS[i % len(CAL_SEEDS)]
        T, P = models[s]
        P0, _, gen, rng, pi = synthetic(T, P, cfg_iid, 5_000 + s, 0)
        return P0, (lambda: gen(rng, None, pi))
    cfg_b, ep = edge_params_from(make_stream, list(range(len(EDGE_SEEDS))), cfg_iid)
    sigs = []
    for s in CAL_SEEDS:
        T, P = models[s]
        P0, b, *_ = synthetic(T, P, cfg_b, s, ROUNDS)
        sig, sent = run(cfg_b, P0, b, {})
        sigs.append((fx.trim(sig, BURN), sent / ROUNDS / 1024, None))
    th = calibrate(sigs)
    return cfg_b, ep, th, {'live_rounds': w0 * len(CAL_SEEDS),
                           'rho_fit_mean': float(np.mean(rho_fit))}


# --------------------------------------------------------------------------
# Part 1: fixed rho
# --------------------------------------------------------------------------
def part_fixed():
    cfg_iid = load_cfg()
    th_iid = json.load(open('calibration.json'))[str(TARGET)]['FogDrift']
    res = {}
    # once, on i.i.d. traffic: edge filters calibrated without knowing rho
    once = {}
    for filt in ('dedup', 'sub1'):
        cfg_f, ep = edge_params_real(cfg_iid, 0.0, filt, EDGE_SEEDS)
        th = calibrate(null_real(cfg_f, CAL_SEEDS, const_rho(cfg_f, 0.0), filt))
        once[filt] = (cfg_f, ep, th)
        log(f"{filt}: calibrated on i.i.d. traffic, tau_a={th['tau_a']:.3f} tau_l={th['tau_l']:.4f}")
    ess = ess_rule(cfg_iid, th_iid)
    for rho in RHOS:
        ro = const_rho(cfg_iid, rho)
        for filt in ('dedup', 'sub1'):
            cfg_f, ep, th = once[filt]
            sigs = null_real(cfg_f, VAL_SEEDS, ro, filt)
            res[f"{rho}|{filt}"] = {'th': th, 'edge': ep, 'live_rounds': 0,
                                    'val': summary(sigs, th),
                                    'detect': delays(cfg_f, rho, filt, th)}
            log(f"rho={rho} {filt}: {line(res[f'{rho}|{filt}'])}")
        sigs = null_real(cfg_iid, VAL_SEEDS, ro, th_of=ess)
        rh = [rho_hat(s[2], cfg_iid) for s in sigs]
        res[f"{rho}|ESS"] = {'th': th_iid, 'live_rounds': 0,
                             'rho_hat': [float(np.mean(rh)), float(np.min(rh)), float(np.max(rh))],
                             'val': summary(sigs, th_iid, ess),
                             'detect': delays(cfg_iid, rho, 'none', th_iid, th_of=ess)}
        log(f"rho={rho} ESS (rho_hat {np.mean(rh):.3f}): {line(res[f'{rho}|ESS'])}")
        for w0 in W0_BOOT:
            cfg_b, ep, th, info = calibrate_bootstrap(cfg_iid, rho, w0)
            sigs = null_real(cfg_b, VAL_SEEDS, ro)
            res[f"{rho}|MB-{w0}"] = dict(info, th=th, edge=ep, val=summary(sigs, th),
                                         detect=delays(cfg_b, rho, 'none', th))
            log(f"rho={rho} MB-{w0} (fitted rho {info['rho_fit_mean']:.3f}): "
                f"{line(res[f'{rho}|MB-{w0}'])}")
    save('fixed', res)


def line(x):
    v = x['val']
    return (f"ARL {v['ARL']:.0f} [{v['ARL_lo']:.0f},{v['ARL_hi']:.0f}] duty {v['duty']:.4f} "
            f"KB {v['KB']:.2f}; " + "; ".join(f"m={m}: {fx.fmt(d['median'])} ({d['rate']:.2f})"
                                              for m, d in x['detect'].items()))


# --------------------------------------------------------------------------
# Part 2: benign bursts of rho
# --------------------------------------------------------------------------
def burst_stats(alarm_list):
    """Events per burst (an event counts for a burst if it starts inside the
    burst or up to BURST_TAIL rounds after it) and ARL outside bursts."""
    hit, n_burst, ev_out, rounds_out, ev_all, rounds_all = 0, 0, 0, 0, 0, 0
    for a in alarm_list:
        a = np.asarray(a, bool)
        m = np.arange(len(a)) + BURN                     # monitored round index
        starts = np.where(a & ~np.r_[False, a[:-1]])[0]
        near = np.array([any(in_burst(x - d) for d in range(BURST_TAIL + 1)) for x in m])
        ev_all += len(starts)
        rounds_all += len(a)
        ev_out += int(np.sum(~near[starts])) if len(starts) else 0
        rounds_out += int(np.sum(~near))
        k0 = (m - BURST_FIRST) // BURST_EVERY
        bursts = sorted({int(k) for k, x in zip(k0, m) if in_burst(x)})
        n_burst += len(bursts)
        for k in bursts:
            lo = BURST_FIRST + k * BURST_EVERY
            hi = lo + BURST_LEN + BURST_TAIL
            hit += int(np.any((m[starts] >= lo) & (m[starts] < hi))) if len(starts) else 0
    lo, hi = fx.poisson_ci(ev_out, rounds_out)
    return {'bursts': n_burst, 'bursts_alarmed': hit, 'frac_alarmed': hit / max(n_burst, 1),
            'ARL_out': rounds_out / ev_out if ev_out else np.inf, 'ARL_out_lo': lo,
            'ARL_out_hi': hi, 'ARL_all': rounds_all / ev_all if ev_all else np.inf}


def part_burst():
    cfg_iid = load_cfg()
    th_iid = json.load(open('calibration.json'))[str(TARGET)]['FogDrift']
    fixed = load('fixed')
    rc = json.load(open('results/autocorrelation.json'))[f"{RHO_BASE}|FogDrift"]
    methods = {
        'recalibrated': (replace(cfg_iid, DTV=rc['edge']['DTV'], D0=rc['edge']['D0'],
                                 DCUM=rc['edge']['DCUM']), 'none', rc['th'], None),
        'ESS': (cfg_iid, 'none', th_iid, ess_rule(cfg_iid, th_iid)),
        'dedup': None,
    }
    fd = fixed[f"0.0|dedup"]
    methods['dedup'] = (replace(cfg_iid, DTV=fd['edge']['DTV'], D0=fd['edge']['D0'],
                                DCUM=fd['edge']['DCUM']), 'dedup', fd['th'], None)
    mb = fixed.get(f"{RHO_BASE}|MB-200")
    if mb is not None:
        methods['MB-200'] = (replace(cfg_iid, DTV=mb['edge']['DTV'], D0=mb['edge']['D0'],
                                     DCUM=mb['edge']['DCUM']), 'none', mb['th'], None)
    scopes = {'one fog (10 agents)': np.arange(0, cfg_iid.N, cfg_iid.F),
              'whole fleet (50 agents)': np.arange(cfg_iid.N)}
    res = {}
    for scope, agents in scopes.items():
        for name, (cfg_d, filt, th, th_of) in methods.items():
            sigs = null_real(cfg_d, VAL_SEEDS, burst_rho(cfg_d, agents), filt, th_of=th_of)
            st = burst_stats(alarms(sigs, th, th_of))
            res[f"{scope}|{name}"] = st
            log(f"burst {scope} {name}: {st['bursts_alarmed']}/{st['bursts']} bursts alarmed, "
                f"ARL outside bursts {st['ARL_out']:.0f}")
    save('burst', res)


# --------------------------------------------------------------------------
# Part 3: calibration variance across seed blocks
# --------------------------------------------------------------------------
def part_seeds():
    cfg_iid = load_cfg()
    res = {}
    for rho in SEED_RHOS:
        for det, kw in (('FogDrift', {}), ('Cent-Hist', {'trigger': False})):
            blocks = []
            for b in range(BLOCKS):
                cal = [3000 + 100 * b + i for i in range(len(CAL_SEEDS))]
                val = [3050 + 100 * b + i for i in range(len(VAL_SEEDS))]
                edge = [1000 + 100 * b + i for i in range(len(EDGE_SEEDS))]
                cfg_d = edge_params_real(cfg_iid, rho, 'none', edge)[0] if det == 'FogDrift' else cfg_iid
                ro = const_rho(cfg_d, rho)
                th = calibrate(null_real(cfg_d, cal, ro, det_kw=kw))
                a = alarms(null_real(cfg_d, val, ro, det_kw=kw), th)
                p = fx.alarm_profile(a)
                ev = [fc.count_events(x) for x in a]
                p['events_per_stream'] = ev
                p['dispersion'] = float(np.var(ev, ddof=1) / max(np.mean(ev), 1e-9))
                p['th'] = th
                blocks.append(p)
                log(f"seeds rho={rho} {det} block {b}: held-out ARL {p['ARL']:.0f} "
                    f"[{p['ARL_lo']:.0f},{p['ARL_hi']:.0f}] events/stream {ev}")
            res[f"{rho}|{det}"] = blocks
    save('seeds', res)


# --------------------------------------------------------------------------
# Saving and report
# --------------------------------------------------------------------------
def save(part, res):
    json.dump(res, open(f"{OUT}_{part}.json", 'w'), indent=1, default=float)


def load(part):
    p = f"{OUT}_{part}.json"
    return json.load(open(p)) if os.path.exists(p) else None


def report():
    fixed, burst, seeds = load('fixed'), load('burst'), load('seeds')
    ac = json.load(open('results/autocorrelation.json'))
    L = []
    P = L.append
    if fixed:
        P(f"Table XIV: autocorrelated benign traffic without oracle rho: FogDrift, target ARL0 = {TARGET}, "
          f"held-out validation {len(VAL_SEEDS)}x{ROUNDS} real rounds at each rho, detection over "
          f"{len(RUN_SEEDS)} seeds (policy poisoning, onset after {PRE} rounds, "
          f"window {POST} rounds).")
        P("live = live null rounds used for calibration beyond each deployment's warm-up "
          "(i.i.d. and recalibrated: 10 x 5000); warm-up = mean warm-up rounds of a held-out "
          "deployment (dedup: until 4000 retained calls per context).")
        P("")
        P(f"{'rho':>4s} {'method':13s} {'live':>6s} {'warm-up':>7s} {'held-out ARL [95% CI]':>23s} "
          f"{'duty':>7s} {'KB/rnd':>7s} " + " ".join(f"{'m=' + str(m):>12s}" for m in MAGS))
        rhos = sorted({float(k.split('|')[0]) for k in fixed})
        for rho in rhos:
            a = ac.get(f"{rho}|FogDrift")
            if a:
                for nm, prof, det, live in (('i.i.d. thr.', a['iid'], None, 0),
                                            ('recalibrated', a['recal'], a['detect'], 50000)):
                    ci = f"{prof['ARL']:.0f} [{prof['ARL_lo']:.0f},{prof['ARL_hi']:.0f}]"
                    dd = " ".join(f"{'':>12s}" for _ in MAGS) if det is None else " ".join(
                        f"{fx.fmt(det[str(m)]['median']):>5s} ({det[str(m)]['rate']:.2f})" for m in MAGS)
                    P(f"{rho:4.1f} {nm:13s} {live:6d} {50:7d} {ci:>23s} {prof['duty']:7.4f} "
                      f"{'':>7s} {dd}")
            for meth in ['dedup', 'sub1', 'ESS'] + [f"MB-{w}" for w in (50, 200)]:
                x = fixed.get(f"{rho}|{meth}")
                if not x:
                    continue
                v = x['val']
                ci = f"{v['ARL']:.0f} [{v['ARL_lo']:.0f},{v['ARL_hi']:.0f}]"
                dd = " ".join(f"{fx.fmt(x['detect'][str(m)]['median']):>5s} "
                              f"({x['detect'][str(m)]['rate']:.2f})" for m in MAGS)
                tag = meth
                if meth == 'ESS':
                    tag += f" r={x['rho_hat'][0]:.2f}"
                P(f"{rho:4.1f} {tag:13s} {x['live_rounds']:6d} {v['warmup']:7.0f} {ci:>23s} "
                  f"{v['duty']:7.4f} {v['KB']:7.2f} {dd}")
            P("")
        P("dedup / sub1: calibrated once on i.i.d. traffic, same thresholds at every rho. "
          "ESS: i.i.d. thresholds x (1+r)/(1-r), r = rho_hat from the deployment's own warm-up "
          "(mean over held-out deployments shown). MB-w: Markov bootstrap from w live warm-up "
          "rounds of each of the 10 calibration deployments.")
        P("")
    if burst:
        P(f"Benign bursts of rho: base rho = {RHO_BASE}, bursts of rho = {RHO_BURST} for "
          f"{BURST_LEN} rounds every {BURST_EVERY} rounds; P(t|c) unchanged; calibration "
          f"without bursts. alarmed = bursts with a false-alarm event starting in the burst or "
          f"up to {BURST_TAIL} rounds after it.")
        P(f"{'burst scope':25s} {'method':13s} {'alarmed':>12s} {'ARL outside [95% CI]':>24s} "
          f"{'ARL all':>8s}")
        for k, v in burst.items():
            scope, meth = k.split('|')
            ci = f"{v['ARL_out']:.0f} [{v['ARL_out_lo']:.0f},{v['ARL_out_hi']:.0f}]"
            P(f"{scope:25s} {meth:13s} {v['bursts_alarmed']:4d}/{v['bursts']:<3d} "
              f"({v['frac_alarmed']:.2f}) {ci:>20s} {v['ARL_all']:8.0f}")
        P("")
    if seeds:
        P(f"Calibration variance: the recalibration of exp_autocorrelation.py repeated on "
          f"{BLOCKS} disjoint seed blocks ({len(CAL_SEEDS)} calibration + {len(VAL_SEEDS)} held-out streams of {ROUNDS} "
          f"rounds each). dispersion = var/mean of alarm events per held-out stream "
          f"(1 = Poisson).")
        P(f"{'rho':>4s} {'detector':10s} {'held-out ARL per block':52s} {'range':>12s} "
          f"{'dispersion':>11s}")
        for k, blocks in seeds.items():
            rho, det = k.split('|')
            arls = [b['ARL'] for b in blocks]
            txt = ", ".join(f"{b['ARL']:.0f}" for b in blocks)
            disp = np.mean([b['dispersion'] for b in blocks])
            P(f"{float(rho):4.1f} {det:10s} {txt:52s} {min(arls):5.0f}-{max(arls):<5.0f} "
              f"{disp:11.2f}")
    txt = "\n".join(L)
    print("\n" + txt)
    open(f"{OUT}.txt", 'w').write(txt + "\n")
    json.dump({'fixed': fixed, 'burst': burst, 'seeds': seeds}, open(f"{OUT}.json", 'w'),
              indent=1, default=float)


if __name__ == '__main__':
    if PART in ('fixed', 'all'):
        part_fixed()
    if PART in ('burst', 'all'):
        part_burst()
    if PART in ('seeds', 'all'):
        part_seeds()
    report()
