"""Matched-ARL calibration and held-out false-alarm validation (Table XII).

    python calibrate.py            # full run, ~35 min
    python calibrate.py quick      # 3+3 seeds x 2000 rounds, ~4 min (sanity only)

Outputs (repository root; every experiment reads the first two):
  edge_params.json   null-calibrated Delta_TV, Delta_0, Delta_cum
  calibration.json   thresholds per detector for target ARL0 in {100, 500, 1000, 5000}
  validation.csv     achieved ARL (95% CI) on held-out streams, per tier and detector

Definitions (Sec. IV and V-M):
  * Alarm event: a persistent threshold crossing (K_p = 2 consecutive rounds);
    each event is counted once (rising edge of the stable alarm).
  * ARL0 = null rounds / alarm events, pooled over seeds; 95% CI from the exact
    Poisson interval on the event count.
  * Actionable endpoint = any fog with a stable alert under Eq. (4)
    (aggregate score > tau_l OR some agent > tau_a). This is what is calibrated.
  * tau_a and tau_l are tied through one scale factor kappa applied to their
    99.9% null quantiles, and kappa is bisected so that the ENDPOINT ARL0 hits
    the target (end-to-end calibration, not per component).
  * tau_g is then bisected so that the cloud alarm hits the target, with the
    untrimmed mean over fogs (the trimmed Eq. (6) and its calibration with one
    faulty fog are in exp_cloud_corroboration.py);
    both cloud branches carry the same K_p persistence.
  * Scalar baselines: one threshold, same persistence, same event definition.
  * Calibration seeds and validation seeds never overlap.
"""
import json
import sys
import time
from dataclasses import asdict
import numpy as np
import fogdrift_core as fc

try:
    from scipy.stats import chi2
except ImportError:          # pragma: no cover
    chi2 = None

TARGETS = [100, 500, 1000, 5000]
T_MAIN = 1000
CAL_SEEDS = list(range(100, 110))      # 10 x 5000 = 50,000 null rounds
VAL_SEEDS = list(range(200, 210))      # held-out, never used for thresholds
ROUNDS = 5000
BURN = 30                              # windows filling up after start
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    CAL_SEEDS, VAL_SEEDS, ROUNDS = [100, 101, 102], [200, 201, 202], 2000
    print("QUICK MODE: numbers are noisy, use the full run for reported results")
FOG_DETS = ['FogDrift', 'FogDrift-fixedTV', 'FogDrift-mixw', 'Cent-Hist', 'Cent-KL',
            'CT(B=1)', 'CT(B=5)', 'CT(B=10)']
SCALAR_DETS = ['MMD-joint', 'MMD-cond', 'CUSUM', 'ADWIN', 'Page-Hinkley', 'DDM']
KP = fc.DEFAULT.KP


def trim(sig):
    return {k: (v[BURN:] if isinstance(v, np.ndarray) and v.ndim >= 1
                and v.shape[0] == ROUNDS else v) for k, v in sig.items()}


def poisson_ci(events, rounds):
    """95% CI for ARL = rounds/events from the exact Poisson interval."""
    if chi2 is None:
        return (np.nan, np.nan)
    lo_rate = chi2.ppf(0.025, 2 * events) / 2 / rounds if events > 0 else 0.0
    hi_rate = chi2.ppf(0.975, 2 * (events + 1)) / 2 / rounds
    return (1 / hi_rate, (1 / lo_rate) if lo_rate > 0 else np.inf)


def arl_of(alarms):
    ev = sum(fc.count_events(a) for a in alarms)
    n = sum(len(a) for a in alarms)
    return (n / ev if ev else np.inf), ev, n


def smallest_param(fun, lo, hi, target, iters=60, log=True):
    """Smallest parameter x in [lo,hi] with ARL(x) >= target (ARL increasing)."""
    if fun(hi)[0] < target:
        return None
    for _ in range(iters):
        mid = np.sqrt(lo * hi) if log else (lo + hi) / 2
        if fun(mid)[0] >= target:
            hi = mid
        else:
            lo = mid
    return hi


def fog_alarm_fn(sigs, qa, ql):
    def f(kappa):
        return arl_of([fc.endpoint_fog(s, kappa * qa, kappa * ql, KP)[0] for s in sigs])
    return f


def main():
    t0 = time.time()
    log = lambda m: print(f"[{(time.time() - t0) / 60:5.1f} min] {m}", flush=True)

    # 1. edge parameters, on their own seeds
    cal_cfg, diag = fc.calibrate_edge_params(range(10))
    json.dump({'config': asdict(cal_cfg), 'diagnostics': diag,
               'seeds': 'calibrate_edge_params(range(10)) -> rng seeds 10000..10009'},
              open('edge_params.json', 'w'), indent=2)
    log(f"edge params: DTV={cal_cfg.DTV:.4f} D0={cal_cfg.D0:.4f} DCUM={cal_cfg.DCUM:.4f}")

    # 2. calibration null streams
    cal = []
    for s in CAL_SEEDS:
        cal.append(fc.run_stream(s, pre=ROUNDS, post=0, fd_cfg=cal_cfg, keep_agent=False))
        log(f"calibration stream seed {s} done")

    thresholds = {str(T): {} for T in TARGETS}
    for k in FOG_DETS:
        sigs = [trim(o[k]) for o in cal]
        qa = float(np.quantile(np.concatenate([s['fog_amax'].ravel() for s in sigs]), 0.999))
        ql = float(np.quantile(np.concatenate([s['fog_score'].ravel() for s in sigs]), 0.999))
        f = fog_alarm_fn(sigs, qa, ql)
        for T in TARGETS:
            kappa = smallest_param(f, 0.8, 20.0, T)
            if kappa is None:
                thresholds[str(T)][k] = None
                continue
            ta, tl = kappa * qa, kappa * ql
            # cloud: smallest tau_g with Eq.(6) ARL >= T
            def g(tg):
                return arl_of([fc.endpoint_cloud(s, ta, tl, tg, fc.DEFAULT.P_CORR, KP)[0]
                               for s in sigs])
            tg = smallest_param(g, 1e-4, 10.0, T)
            arl, ev, n = f(kappa)
            thresholds[str(T)][k] = {'tau_a': ta, 'tau_l': tl, 'tau_g': tg,
                                     'kappa': kappa, 'cal_ARL': arl,
                                     'cal_events': ev, 'cal_rounds': n}
        log(f"calibrated {k}")
    for k in SCALAR_DETS:
        scores = [o[k]['score'][BURN:] for o in cal]
        # search only where the raw alarm duty cycle is <= 10%: below that,
        # alarms merge into a few long events and events/rounds stops being
        # monotone in the threshold
        lo = max(float(np.quantile(np.concatenate(scores), 0.90)), 1e-9)
        hi = max(float(x.max()) for x in scores) * 3 + 1e-6
        for T in TARGETS:
            f = lambda thr: arl_of([fc.endpoint_scalar(x, thr, KP)[0] for x in scores])
            thr = smallest_param(f, lo, hi, T, log=lo > 0)
            arl, ev, n = f(thr) if thr is not None else (np.nan, 0, 0)
            thresholds[str(T)][k] = None if thr is None else {
                'thr': thr, 'cal_ARL': arl, 'cal_events': ev, 'cal_rounds': n}
        log(f"calibrated {k}")
    json.dump(thresholds, open('calibration.json', 'w'), indent=2, default=float)

    # 3. held-out validation at the main operating point
    rows = []
    for cond in ['stationary', 'workload-drift']:
        val = []
        for s in VAL_SEEDS:
            sched = None
            if cond == 'workload-drift':
                wr = np.random.default_rng(s + 300_000)
                pis = [wr.dirichlet(np.full(fc.DEFAULT.L, 2.0)) for _ in range(ROUNDS // 100 + 1)]
                sched = lambda r, pis=pis: pis[r // 100]
            val.append(fc.run_stream(s, pre=ROUNDS, post=0, fd_cfg=cal_cfg,
                                     pi_schedule=sched, keep_agent=True))
            log(f"validation ({cond}) seed {s} done")
        th = thresholds[str(T_MAIN)]
        for k in FOG_DETS:
            if th[k] is None:
                continue
            ta, tl, tg = th[k]['tau_a'], th[k]['tau_l'], th[k]['tau_g']
            sigs = [trim(o[k]) for o in val]
            tiers = {
                'agent (any agent > tau_a)': [fc.stable_alarm(s['agent'] > ta, KP)[0].any(1) for s in sigs],
                'fog aggregate (> tau_l)': [fc.stable_alarm((s['fog_score'] > tl) & s['fog_has'], KP)[0].any(1) for s in sigs],
                'ENDPOINT Eq.(4), any fog': [fc.endpoint_fog(s, ta, tl, KP)[0] for s in sigs],
            }
            if tg is not None:
                cl = [fc.endpoint_cloud(s, ta, tl, tg, fc.DEFAULT.P_CORR, KP) for s in sigs]
                tiers['cloud Eq.(6)'] = [c[0] for c in cl]
                tiers['  cloud: corroboration branch'] = [c[1] for c in cl]
                tiers['  cloud: average-score branch'] = [c[2] for c in cl]
            for tier, al in tiers.items():
                arl, ev, n = arl_of(al)
                lo, hi = poisson_ci(ev, n)
                rows.append([cond, k, tier, n, ev, arl, lo, hi])
        for k in SCALAR_DETS:
            if th[k] is None:
                continue
            al = [fc.endpoint_scalar(o[k]['score'][BURN:], th[k]['thr'], KP)[0] for o in val]
            arl, ev, n = arl_of(al)
            lo, hi = poisson_ci(ev, n)
            rows.append([cond, k, 'ENDPOINT (scalar)', n, ev, arl, lo, hi])

    import csv
    with open('validation.csv', 'w', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['condition', 'detector', 'tier', 'null_rounds', 'events', 'ARL',
                    'CI_low', 'CI_high'])
        for r in rows:
            w.writerow([f"{x:.1f}" if isinstance(x, float) else x for x in r])
    print("\nHeld-out validation, target ARL0 = 1000")
    print(f"{'condition':15s} {'detector':17s} {'tier':32s} {'events':>6s} {'ARL':>8s}  95% CI")
    for r in rows:
        print(f"{r[0]:15s} {r[1]:17s} {r[2]:32s} {r[4]:6d} {r[5]:8.0f}  [{r[6]:.0f}, {r[7]:.0f}]")
    log("done")


if __name__ == '__main__':
    main()
