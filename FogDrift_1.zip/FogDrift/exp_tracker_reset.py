"""Tracker reset rule (Alg. 1, line 10; Sec. III-F).

    python exp_tracker_reset.py          # ~15 min
    python exp_tracker_reset.py quick    # ~3 min, noisy

The Page-Hinkley tracker S (Eq. 5) is reset to zero whenever the edge's
summary is delivered, including heartbeats. With T_hb = 10 it therefore
accumulates over at most T_hb - 1 = 9 rounds, so it can force an early
transmission only when the excess TV(H_n, P0) - Delta_0 averages more than
Delta_cum / (T_hb - 1) ~ 0.044 per round. A slower drift still reaches the fog
through the heartbeats, which deliver the current histogram at least every
T_hb rounds; the fog scores it against P0 like any other summary.

Variants, all with the calibrated edge parameters and the matched-ARL
thresholds of FogDrift at ARL0 = 1000 (edge_params.json, calibration.json):
  paper        reset after every delivered summary
  event reset  reset only after summaries sent because TV > Delta_TV or
               S > Delta_cum; S keeps accumulating across heartbeats
  no tracker   event trigger and heartbeat only
  Cent-Hist    every agent reports every round (trigger off): the
               fastest the fog can see any drift

(a) Null, 10 x 5000 rounds after a 30-round burn-in: held-out ARL
    (Poisson 95% CI), bytes per round and the share of agent-rounds that
    transmit, split by the first matching cause (TV trigger, tracker,
    heartbeat).
(b) Detection delay, 30 seeds, onset at round 60, policy poisoning: a step,
    linear ramps of different length and size, small shifts, one agent.
    Median delay over detected runs (rounds) and detected / runs within
    the ramp length + 100 rounds.

Outputs: results/tracker_reset.txt, results/tracker_reset.json
"""
import json
import os
import sys
import time
from dataclasses import fields

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
BURN = 30
ROUNDS = 5000
NULL_SEEDS = list(range(5800, 5810))
RUN_SEEDS = list(range(5900, 5930))
PRE = 60
if QUICK:
    NULL_SEEDS, ROUNDS, RUN_SEEDS = NULL_SEEDS[:3], 1500, RUN_SEEDS[:8]
    print("QUICK MODE: noisy")
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


CFG = load_cfg()
TH = json.load(open('calibration.json'))[str(T)]['FogDrift']
TA, TL = TH['tau_a'], TH['tau_l']
SLOPE = CFG.DCUM / (CFG.THB - 1)
# run_stream passes its generator config to `extra` factories, so every
# variant is built with the calibrated CFG explicitly.
VARIANTS = {
    'paper': lambda P0, c: fc.HCDD(P0, CFG, name='paper'),
    'event reset': lambda P0, c: fc.HCDD(P0, CFG, reset='event', name='event reset'),
    'no tracker': lambda P0, c: fc.HCDD(P0, CFG, tracker=False, name='no tracker'),
    'Cent-Hist': lambda P0, c: fc.HCDD(P0, CFG, trigger=False, name='Cent-Hist'),
}


def tiny(Pt):
    Pd = Pt.copy()
    Pd[:, 6] += 0.024
    return Pd / Pd.sum(1, keepdims=True)


def ramp(m, length):
    return lambda r, Pt, Pd: fc.policy_poison(Pt, m * min(1.0, (r + 1) / length))


def on_compromised(fn):
    """Apply fn(Pt) only to the agents whose drifted row differs from Pt."""
    def attack(r, Pt, Pd):
        full = np.broadcast_to(Pt, Pd.shape)
        comp = ~np.isclose(Pd, full).all(axis=(1, 2))
        out = full.copy()
        out[comp] = fn(r, Pt)
        return out
    return attack


ATTACKS = [
    ('step m=0.5', dict(m=0.5), 100),
    ('ramp to 0.5 over 30', dict(m=0.5, attack=ramp(0.5, 30)), 130),
    ('ramp to 0.5 over 100', dict(m=0.5, attack=ramp(0.5, 100)), 200),
    ('ramp to 0.5 over 300', dict(m=0.5, attack=ramp(0.5, 300)), 400),
    ('ramp to 0.15 over 100', dict(m=0.15, attack=ramp(0.15, 100)), 200),
    ('step m=0.05', dict(m=0.05), 100),
    ('tiny shift (+0.024)', dict(m=0.5, attack=lambda r, Pt, Pd: tiny(Pt)), 100),
    ('one agent, ramp to 0.5 over 100',
     dict(m=0.5, q=1, attack=on_compromised(lambda r, Pt: ramp(0.5, 100)(r, Pt, None))), 200),
]


def null_part():
    out = {}
    for name, make in VARIANTS.items():
        al, sent, causes, ar = [], 0, {'tv': 0, 'cum': 0, 'hb': 0}, 0
        for s in NULL_SEEDS:
            rng = np.random.default_rng(s)
            Pt = fc.build_P0(rng, CFG)
            P0 = fc.estimate_P0(rng, Pt, np.full(CFG.L, 1 / CFG.L), CFG)
            d = make(P0, CFG)
            sig = {'fog_score': [], 'fog_amax': [], 'fog_has': []}
            for r in range(ROUNDS):
                if r == BURN:
                    s0, c0 = d.sent, dict(d.tx_cause)
                o = d.step(*fc.gen_round(rng, Pt, np.full(CFG.L, 1 / CFG.L), CFG))
                for k in sig:
                    sig[k].append(o[k])
            sig = fx.trim({k: np.array(v) for k, v in sig.items()}, BURN)
            al.append(fc.endpoint_fog(sig, TA, TL, KP)[0])
            sent += d.sent - s0
            for k in causes:
                causes[k] += d.tx_cause[k] - c0[k]
            ar += (ROUNDS - BURN) * CFG.N
        arl, ev, n = fx.arl_of(al)
        lo, hi = fx.poisson_ci(ev, n)
        out[name] = {'ARL': arl, 'events': ev, 'rounds': n, 'lo': lo, 'hi': hi,
                     'bytes_per_round': sent / n,
                     'tx_share': {k: v / ar for k, v in causes.items()}}
        log(f"null {name}: {out[name]}")
    return out


def delay_part():
    out = []
    built = []
    extra = {k: (lambda f: lambda P0, c: built.append(f(P0, c)) or built[-1])(v)
             for k, v in VARIANTS.items()}
    for name, kw, post in ATTACKS:
        d = {k: [] for k in VARIANTS}
        cum = {k: 0 for k in VARIANTS}
        for s in RUN_SEEDS:
            built.clear()
            o = fc.run_stream(s, fd_cfg=CFG, base_dets=False, scalars=False, keep_agent=False,
                              extra=extra, scenario='policy', pre=PRE, post=post, **kw)
            for det in built:
                cum[det.name] += det.tx_cause['cum']
            for k in VARIANTS:
                _, st, sr = fc.endpoint_fog(o[k], TA, TL, KP)
                d[k].append(fc.detection_delay(st, sr, o['onset'], KP))
        row = {'attack': name, 'post': post}
        ar = len(RUN_SEEDS) * (PRE + post) * CFG.N
        for k in VARIANTS:
            row[k] = {'median': fx.med(d[k]), 'detected': sum(x is not None for x in d[k]),
                      'n': len(d[k]), 'tracker_share': cum[k] / ar}
        out.append(row)
        log(f"delay {row}")
    return out


def report(res):
    L = [f"Tracker reset rule. Calibrated FogDrift (edge_params.json): Delta_TV = {CFG.DTV:.3f}, "
         f"Delta_0 = {CFG.D0:.3f}, Delta_cum = {CFG.DCUM:.3f}, T_hb = {CFG.THB}; thresholds at "
         f"ARL0 = {T} (tau_a = {TA:.3f}, tau_l = {TL:.4f}), the same for every variant.",
         f"With a reset at every heartbeat the tracker can force a transmission only if the "
         f"excess TV averages more than Delta_cum / (T_hb - 1) = {SLOPE:.3f} per round.", "",
         f"(a) Null, {len(NULL_SEEDS)} x {ROUNDS} rounds after a {BURN}-round burn-in. Share of "
         "agent-rounds that transmit, by first matching cause.",
         f"{'variant':12s} {'ARL [95% CI] (events)':>28s} {'B/round':>8s} {'TV':>7s} "
         f"{'tracker':>8s} {'heartbeat':>9s}"]
    for k, a in res['null'].items():
        ci = f"{a['ARL']:.0f} [{a['lo']:.0f}, {a['hi']:.0f}] ({a['events']})"
        t = a['tx_share']
        L.append(f"{k:12s} {ci:>28s} {a['bytes_per_round']:8.0f} {t['tv']:7.4f} "
                 f"{t['cum']:8.4f} {t['hb']:9.4f}")
    L += ["", f"(b) Detection delay, policy poisoning, onset at round {PRE}, {len(RUN_SEEDS)} seeds: "
          "median rounds over detected runs (detected / runs within the window)"]
    L.append(f"{'attack':34s} " + " ".join(f"{k:>14s}" for k in VARIANTS) +
             "   tracker-caused share of agent-rounds: paper / event reset")
    for r in res['delay']:
        L.append(f"{r['attack']:34s} " + " ".join(
            f"{fx.fmt(r[k]['median'], 1) + ' (' + str(r[k]['detected']) + '/' + str(r[k]['n']) + ')':>14s}"
            for k in VARIANTS) +
            f"   {r['paper']['tracker_share']:.4f} / {r['event reset']['tracker_share']:.4f}")
    return "\n".join(L)


if __name__ == '__main__':
    res = {'null': null_part(), 'delay': delay_part()}
    txt = report(res)
    print(txt)
    open('results/tracker_reset.txt', 'w').write(txt + "\n")
    json.dump(res, open('results/tracker_reset.json', 'w'), indent=2, default=float)
