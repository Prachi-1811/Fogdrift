"""Matched-ARL0 detection comparison (Table IV, Fig. 2, Fig. 3).

    python exp_matched_arl.py          # 30 seeds x 3 scenarios, ~5 min
    python exp_matched_arl.py quick    # 5 seeds, ~1 min (sanity only)

Needs edge_params.json and calibration.json (calibrate.py).

Protocol (one definition for every detector):
  * Each seed: warm-up (P0 estimate) + 60 null rounds + 100 drift rounds.
    All detectors see the SAME event stream.
  * Thresholds = matched-ARL0 thresholds from calibration.json.
  * Delay = r_alert - r_onset + 1 with K_p = 2 (minimum possible = 2);
    an alarm whose run started before onset is not a detection;
    not detected within 100 rounds = censored.
  * Median delay over seeds treats censored runs as +infinity; it is reported
    only if more than half of the runs detect. 95% CI by bootstrap (2000
    resamples over seeds).
  * Bandwidth = bytes SENT per round, before onset (steady) and after onset
    (under attack). Batched tuples: onset at a batch boundary (o = 0); other
    offsets in exp_batch_phase.py.
Outputs: results/matched_arl.txt, results/matched_arl.json,
         results/delay_vs_arl.png, results/delay_vs_bandwidth.png
"""
import json
import os
import sys
import time
from dataclasses import fields
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

SEEDS = list(range(300, 330))
SCENARIOS = ['policy', 'prompt', 'deprec']
M_DRIFT = 0.5
PRE, POST = 60, 100
TARGETS = ['100', '500', '1000', '5000']
MAIN = '1000'
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS = list(range(300, 305))
    print("QUICK MODE: 5 seeds, numbers are noisy")

FOG = ['FogDrift', 'FogDrift-fixedTV', 'FogDrift-mixw', 'Cent-Hist', 'Cent-KL',
       'CT(B=1)', 'CT(B=5)', 'CT(B=10)']
SCALAR = ['MMD-joint', 'MMD-cond', 'CUSUM', 'ADWIN', 'Page-Hinkley', 'DDM']
KP = fc.DEFAULT.KP


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def delay_of(out, det, th):
    on = out['onset']
    if th is None:
        return None
    if det in FOG:
        _, st, sr = fc.endpoint_fog(out[det], th['tau_a'], th['tau_l'], KP)
    else:
        _, st, sr = fc.endpoint_scalar(out[det]['score'], th['thr'], KP)
    return fc.detection_delay(st, sr, on, KP)


def median_inf(d):
    x = np.array([np.inf if v is None else v for v in d], float)
    return float(np.median(x))


def boot_ci(d, B=2000, seed=0):
    x = np.array([np.inf if v is None else v for v in d], float)
    rng = np.random.default_rng(seed)
    meds = np.median(x[rng.integers(0, len(x), (B, len(x)))], axis=1)
    return float(np.quantile(meds, 0.025)), float(np.quantile(meds, 0.975))


def fmt(v):
    return 'cens' if not np.isfinite(v) else f"{v:.1f}"


def bandwidth(out, det):
    """bytes sent per round (KB) before and after onset."""
    on, R = out['onset'], out['R']
    if det in FOG:
        cum = np.asarray(out[det]['sent'], float)
        per = np.diff(np.concatenate([[0.0], cum]))
        return per[:on].mean() / 1024, per[on:].mean() / 1024
    kb = out[det]['sent_KB']                       # raw traces, constant
    return kb, kb


def main():
    t0 = time.time()
    cfg = load_cfg()
    th = json.load(open('calibration.json'))
    dets = FOG + SCALAR
    delays = {T: {d: {s: [] for s in SCENARIOS} for d in dets} for T in TARGETS}
    bw = {d: [[], []] for d in dets}
    for sc in SCENARIOS:
        for seed in SEEDS:
            out = fc.run_stream(seed, scenario=sc, m=M_DRIFT, pre=PRE, post=POST,
                                fd_cfg=cfg, keep_agent=False)
            for d in dets:
                for T in TARGETS:
                    delays[T][d][sc].append(delay_of(out, d, th[T].get(d)))
                b0, b1 = bandwidth(out, d)
                bw[d][0].append(b0)
                bw[d][1].append(b1)
        print(f"[{(time.time() - t0) / 60:4.1f} min] scenario {sc} done", flush=True)

    lines = []
    P = lines.append
    P(f"Table IV: matched ARL0 = {MAIN}, m = {M_DRIFT}, {len(SEEDS)} seeds per scenario")
    P("Delay = rounds from onset to operator-visible alarm (K_p = 2, minimum 2); "
      "median over seeds, censored = not detected in 100 rounds")
    P(f"{'detector':17s} {'policy':>14s} {'prompt':>14s} {'deprec':>14s} "
      f"{'all [95% CI]':>20s} {'det.rate':>8s} {'KB/rnd steady':>14s} {'KB/rnd attack':>14s}")
    summary = {}
    for d in dets:
        row = f"{d:17s}"
        for sc in SCENARIOS:
            v = delays[MAIN][d][sc]
            row += f" {fmt(median_inf(v)):>6s} ({sum(x is not None for x in v):2d}/{len(v)})"
        allv = sum((delays[MAIN][d][sc] for sc in SCENARIOS), [])
        med = median_inf(allv)
        lo, hi = boot_ci(allv)
        rate = np.mean([x is not None for x in allv])
        b0, b1 = np.mean(bw[d][0]), np.mean(bw[d][1])
        summary[d] = {'median': med, 'ci': (lo, hi), 'rate': rate, 'bw0': b0, 'bw1': b1}
        row += f" {fmt(med):>6s} [{fmt(lo)}, {fmt(hi)}] {rate:8.2f} {b0:14.2f} {b1:14.2f}"
        P(row)
    P("")
    P("Median delay (all scenarios) vs target ARL0 (Fig. 2)")
    P(f"{'detector':17s} " + " ".join(f"{T:>8s}" for T in TARGETS))
    curve = {}
    for d in dets:
        vals = [median_inf(sum((delays[T][d][sc] for sc in SCENARIOS), [])) for T in TARGETS]
        curve[d] = vals
        P(f"{d:17s} " + " ".join(f"{fmt(v):>8s}" for v in vals))
    txt = "\n".join(lines)
    print("\n" + txt)
    open('results/matched_arl.txt', 'w').write(txt + "\n")
    json.dump({'summary': summary, 'curve': curve,
               'delays_main': {d: delays[MAIN][d] for d in dets}},
              open('results/matched_arl.json', 'w'), indent=1, default=lambda o: None)

    # delay vs ARL0 (Fig. 2)
    plt.rcParams.update({'font.size': 12, 'font.family': 'serif'})
    fig, ax = plt.subplots(figsize=(7.5, 5))
    x = [int(T) for T in TARGETS]
    show = ['FogDrift', 'Cent-Hist', 'CT(B=5)', 'CT(B=10)', 'MMD-cond',
            'CUSUM', 'ADWIN', 'Page-Hinkley']
    for d, mk in zip(show, 'osD^vP*X'):
        y = [v if np.isfinite(v) else np.nan for v in curve[d]]
        ax.plot(x, y, marker=mk, label=d)
    ax.set_xscale('log')
    ax.set_xticks(x)
    ax.set_xticklabels([r'$10^2$', r'$5{\times}10^2$', r'$10^3$', r'$5{\times}10^3$'])
    ax.set_xlabel(r'Target $\mathrm{ARL}_0$ (log scale)')
    ax.set_ylabel('Median detection delay (rounds)')
    ax.grid(True, which='both', alpha=0.3, linestyle='--')
    ax.set_ylim(0, max(v for d in show for v in curve[d] if np.isfinite(v)) + 4)
    ax.legend(ncol=4, fontsize=8, loc='upper center')
    plt.tight_layout()
    plt.savefig('results/delay_vs_arl.png', dpi=200)

    # steady-state bandwidth vs delay at the main ARL0 (Fig. 3).
    # Detectors that land on the same point are drawn once with a joint label.
    from matplotlib.ticker import FuncFormatter
    groups = {}
    for d in dets:
        s = summary[d]
        if not np.isfinite(s['median']) or d in ('FogDrift-fixedTV', 'FogDrift-mixw'):
            continue
        key = (round(np.log10(s['bw0']), 1), s['median'])   # same point on a log axis
        groups.setdefault(key, []).append(d)
    fig, ax = plt.subplots(figsize=(7.5, 5))
    for (bwk, med), names in sorted(groups.items()):
        x = np.mean([summary[n]['bw0'] for n in names])
        main = 'FogDrift' in names
        ax.scatter(x, med, s=120 if main else 60, marker='*' if main else 'o',
                   color='tab:blue' if main else 'tab:gray', zorder=3,
                   edgecolor='black', linewidth=0.6)
        below = x > 10 and med <= 2
        ax.annotate("\n".join(names) if below else ", ".join(names), (x, med),
                    textcoords='offset points', xytext=(0, -12 if below else 9),
                    ha='center', va='top' if below else 'bottom', fontsize=8)
    fd = summary['FogDrift']
    ax.annotate('', xy=(fd['bw1'], fd['median']), xytext=(fd['bw0'], fd['median']),
                arrowprops=dict(arrowstyle='->', color='tab:blue', lw=1.2, ls='--'))
    ax.text(fd['bw1'], fd['median'] - 0.6, 'FogDrift during attack', color='tab:blue',
            fontsize=8, ha='center')
    ax.set_xscale('log')
    from matplotlib.ticker import NullFormatter
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_xticks([1, 2, 5, 10, 20, 30])
    ax.set_xlim(1.3, 40)
    ymax = max(m for _, m in groups) + 2
    ax.set_ylim(-2.5, ymax)
    ax.set_yticks(range(0, int(ymax) + 1, 2))
    ax.set_xlabel('Bytes sent per round before attack onset (KB, log scale)')
    ax.set_ylabel(f'Median detection delay (rounds), ARL$_0$={MAIN}')
    ax.grid(True, which='both', alpha=0.3, linestyle='--')
    plt.tight_layout()
    plt.savefig('results/delay_vs_bandwidth.png', dpi=200)
    print(f"\nSaved results/matched_arl.txt, matched_arl.json, delay_vs_arl.png, delay_vs_bandwidth.png "
          f"[{(time.time() - t0) / 60:.1f} min]")


if __name__ == '__main__':
    main()
