# data

- `injecagent_toolkit_map.json`: maps every InjecAgent tool to its toolkit (tool identity)
  and to one of six context families (communication, scheduling, files, finance, home,
  health). Used by `exp_injecagent_replay.py`.
- `injecagent_gt_dh.jsonl`, `injecagent_gt_ds.jsonl`: the InjecAgent ground-truth cases as episode
  traces (`injecagent_traces.py`), for `exp_agentdojo_replay.py ... settle=300`.
- `agentdojo_<model>_<suite>.jsonl`: AgentDojo episode traces written by
  `agentdojo_collect.py` (one JSON line per episode) and read by `exp_agentdojo_replay.py`.
  The traces for Table XI(a) are `agentdojo_gptoss20b_banking.jsonl`.
- `agentdojo_runs_<model>.jsonl`: the same format, converted by `agentdojo_runs.py` from the
  run logs published with AgentDojo (github.com/ethz-spylab/agentdojo, `runs/`, MIT licence);
  Table XI(b).
