"""All detectors at a smaller drift magnitude and under partial compromise.

    python exp_baselines_small.py          # ~10 min
    python exp_baselines_small.py quick    # ~2 min, noisy

Same protocol as exp_matched_arl.py (Table IV): matched-ARL0 thresholds of
calibration.json at ARL0 = 1000, warm-up + 60 null rounds + 100 drift rounds,
K_p = 2, delay = r_alert - r_onset + 1, censored after 100 rounds; every
detector sees the same calls. Cases:
  m = 0.15 for each of the three drift scenarios, every agent
  policy poisoning m = 0.5 on 5 agents (10%) and on 1 agent
Compromised agents are drawn uniformly from the 50 (run_stream, seed + 7),
so they may share a fog.

Outputs: results/baselines_small.txt, results/baselines_small.json
"""
import json
import os
import sys
import time

import numpy as np

import fogdrift_core as fc
from exp_matched_arl import FOG, SCALAR, delay_of, load_cfg, median_inf

os.makedirs('results', exist_ok=True)
SEEDS = list(range(300, 330))
if 'quick' in sys.argv[1:]:
    SEEDS = SEEDS[:6]
    print("QUICK MODE: noisy")
PRE, POST = 60, 100
CASES = [('policy m=0.15', dict(scenario='policy', m=0.15)),
         ('prompt m=0.15', dict(scenario='prompt', m=0.15)),
         ('deprec m=0.15', dict(scenario='deprec', m=0.15)),
         ('policy m=0.5, 5 agents', dict(scenario='policy', m=0.5, q=5)),
         ('policy m=0.5, 1 agent', dict(scenario='policy', m=0.5, q=1))]


def fmt(v):
    return 'cens' if not np.isfinite(v) else f"{v:.1f}"


def main():
    t0 = time.time()
    cfg = load_cfg()
    th = json.load(open('calibration.json'))['1000']
    dets = FOG + SCALAR
    res = {}
    for name, kw in CASES:
        d = {k: [] for k in dets}
        for seed in SEEDS:
            out = fc.run_stream(seed, pre=PRE, post=POST, fd_cfg=cfg, keep_agent=False, **kw)
            for k in dets:
                d[k].append(delay_of(out, k, th.get(k)))
        res[name] = {k: {'median': median_inf(v), 'detected': sum(x is not None for x in v),
                         'n': len(v)} for k, v in d.items()}
        print(f"[{(time.time() - t0) / 60:4.1f} min] {name} done", flush=True)
    L = [f"All detectors at matched ARL0 = 1000 (calibration.json), {len(SEEDS)} seeds, onset "
         f"after {PRE} rounds, censored after {POST}: median delay in rounds (detected/runs); "
         "a median is shown only if more than half of the runs detect.",
         f"{'detector':17s} " + " ".join(f"{n:>24s}" for n, _ in CASES)]
    for k in dets:
        L.append(f"{k:17s} " + " ".join(
            f"{fmt(res[n][k]['median'])} ({res[n][k]['detected']}/{res[n][k]['n']})".rjust(24)
            for n, _ in CASES))
    txt = "\n".join(L)
    print(txt)
    open('results/baselines_small.txt', 'w').write(txt + "\n")
    json.dump(res, open('results/baselines_small.json', 'w'), indent=1)


if __name__ == '__main__':
    main()
