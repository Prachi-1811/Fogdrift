"""Conditional vs unconditional scoring under a pure workload shift
(Sec. V-D, Fig. 5).

    python exp_workload_invariance.py          # ~3 min
    python exp_workload_invariance.py quick    # ~1 min

Needs validation.csv from calibrate.py (for panel b).

Workload shift = context mixture changes from uniform to [0.10, 0.40, 0.10, 0.40]
while P(t|c) is unchanged (no drift). For each seed, scores are averaged over
100 monitoring rounds after a 30-round burn-in.
  conditional (equal weights) : FogDrift fog-aggregate score (the design)
  conditional (pi-weighted)   : same with mixture weights
  unconditional               : KL between the fleet marginal P(t) (context
                                histograms weighted by uncapped context counts)
                                and the warm-up marginal sum_c pi0_c P0(t|c)
Panel (b) shows the measured null ARL from calibrate.py (alarm rates, not scores).
Outputs: results/workload_invariance.txt, results/workload_invariance.png
"""
import os
import csv
import sys
from dataclasses import replace
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

SEEDS = list(range(800, 830))
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS = list(range(800, 805))
SHIFT = np.array([0.10, 0.40, 0.10, 0.40])
BURN, MEAS = 30, 100


def scores(seed, pi_run):
    cfg = fc.DEFAULT
    rng = np.random.default_rng(seed)
    P = fc.build_P0(rng, cfg)
    pi0 = np.ones(cfg.L) / cfg.L
    P0 = fc.estimate_P0(rng, P, pi0, cfg)
    eq = fc.HCDD(P0, cfg, trigger=False)                         # same statistics, all fresh
    mx = fc.HCDD(P0, replace(cfg, CTX_W='mixture'), trigger=False)
    pool = fc.Windows(cfg)
    ref_marg = pi0 @ P0
    a, b, u = [], [], []
    for r in range(BURN + MEAS):
        cs, ts = fc.gen_round(rng, P, pi_run, cfg)
        oa, ob = eq.step(cs, ts), mx.step(cs, ts)
        pool.add_round(cs, ts)
        if r < BURN:
            continue
        a.append(oa['fog_score'].mean())
        b.append(ob['fog_score'].mean())
        # marginal P(t): per-context histograms weighted by the UNCAPPED context
        # counts (the capped windows hold W observations per context whatever
        # the workload, so they cannot represent the mixture)
        Hc = fc.smooth(pool.cnt.sum(0), cfg)
        w = pool.ctx_sum.sum(0)
        pm = (w / w.sum()) @ Hc
        u.append(float(np.sum(pm * np.log(pm / ref_marg))))
    return np.mean(a), np.mean(b), np.mean(u)


def main():
    base = np.array([scores(s, np.ones(4) / 4) for s in SEEDS])
    shift = np.array([scores(s, SHIFT) for s in SEEDS])
    names = ['conditional (equal weights)', 'conditional (pi-weighted)', 'unconditional']
    L = [f"Workload invariance (Sec. V-D, Fig. 5a): mean score, uniform workload vs shifted workload "
         f"{SHIFT.tolist()}, no policy drift, {len(SEEDS)} seeds (mean +- sd over seeds)",
         f"{'score':30s} {'uniform':>16s} {'shifted':>16s} {'ratio':>7s}"]
    ratios = []
    for j, n in enumerate(names):
        r = shift[:, j].mean() / base[:, j].mean()
        ratios.append(r)
        L.append(f"{n:30s} {base[:, j].mean():8.4f}+-{base[:, j].std():.4f} "
                 f"{shift[:, j].mean():8.4f}+-{shift[:, j].std():.4f} {r:6.2f}x")
    arl = {}
    try:
        # tolerant parser: some validation.csv writers leave an unquoted comma in the
        # tier name "ENDPOINT Eq.(4), any fog"; the last five fields are numeric
        for line in open('validation.csv').read().splitlines()[1:]:
            f = line.split(',')
            if 'ENDPOINT Eq.(4)' in line and f[1] in ('FogDrift', 'FogDrift-mixw'):
                arl[(f[1], f[0])] = (float(f[-3]), float(f[-2]), float(f[-1]))
        L.append("")
        L.append("Null endpoint ARL from calibrate.py (target 1000, Fig. 5b): " + "; ".join(
            f"{d} {c}: {v[0]:.0f} [{v[1]:.0f}, {v[2]:.0f}]" for (d, c), v in arl.items()))
    except FileNotFoundError:
        L.append("validation.csv not found: run calibrate.py first for panel (b)")
    txt = "\n".join(L)
    print(txt)
    open('results/workload_invariance.txt', 'w').write(txt + "\n")

    plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})
    ncol = 2 if arl else 1
    fig, axs = plt.subplots(1, ncol, figsize=(11 if arl else 6, 4.2))
    axs = np.atleast_1d(axs)
    lab = ['conditional\n(equal w.)', 'conditional\n($\\pi$-weighted)', 'unconditional']
    axs[0].bar(lab, ratios, color=['tab:blue', 'tab:gray', 'tab:red'], edgecolor='black')
    axs[0].axhline(1, color='black', ls='--', lw=1)
    for i, r in enumerate(ratios):
        axs[0].text(i, r * 1.03 + 0.1, f"{r:.2f}x", ha='center', fontsize=10)
    axs[0].set_ylim(0, max(ratios) * 1.15)
    axs[0].set_ylabel('Mean score: shifted / uniform workload')
    axs[0].set_title('(a) score under a pure workload shift', fontsize=10)
    axs[0].grid(axis='y', alpha=.3, ls='--')
    if arl:
        conds = ['stationary', 'workload-drift']
        x = np.arange(2)
        for k, (d, c) in enumerate([('FogDrift', 'tab:blue'), ('FogDrift-mixw', 'tab:gray')]):
            v = [arl[(d, cc)] for cc in conds]
            axs[1].bar(x + (k - .5) * .38, [a[0] for a in v], .38, color=c, edgecolor='black',
                       yerr=[[a[0] - a[1] for a in v], [a[2] - a[0] for a in v]], capsize=3,
                       label='equal weights' if d == 'FogDrift' else '$\\pi$-weighted')
        axs[1].axhline(1000, color='black', ls='--', lw=1)
        axs[1].set_xticks(x); axs[1].set_xticklabels(conds)
        axs[1].set_ylabel('Null ARL (rounds per false alarm)')
        axs[1].set_title('(b) measured false-alarm rate, target ARL$_0$=1000', fontsize=10)
        axs[1].legend(fontsize=8); axs[1].grid(axis='y', alpha=.3, ls='--')
    plt.tight_layout(); plt.savefig('results/workload_invariance.png', dpi=200)
    print("Saved results/workload_invariance.txt, workload_invariance.png")


if __name__ == '__main__':
    main()
