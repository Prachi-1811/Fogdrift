"""Small persistent shifts: tracker reset rule and window size (Sec. V-H,
Tables VIII and IX).

    python exp_small_shift.py          # ~30 min
    python exp_small_shift.py quick    # ~5 min, noisy

(a) Tracker reset rule. Three edge variants, each calibrated to ARL0 = 1000
    on the null streams of calibrate.py (seeds 100-109, 10 x 5000 rounds) and
    validated on held-out seeds 200-209:
      reset on every summary   the paper (Alg. 1, line 10): S restarts after
                               every delivered summary, heartbeats included
      no reset on heartbeats   S restarts only after summaries sent because
                               TV > Delta_TV or S > Delta_cum
      no tracker               V5 of Table IX
    Attacks: K1, AA1, AA6, AA8 of Table VIII (AA1 and AA8 also followed for 300
    rounds) and the six regimes of Table IX, with their seeds (300-329),
    onset after 60 rounds.
(b) Window size. The per-context edge window W = 20 (paper), 50 and 100, and
    W = 20 with a parallel W = 100 window (alarm when either alarms; the
    single-window thresholds are scaled by one common factor to ARL0 = 1000).
    Same edge parameters; fog thresholds calibrated and validated as in (a).
    Shift attack as AA1: +delta on the suspicious tool (tool 6) in every
    context, renormalised, on every agent or on one agent. Detection rate
    within 100 and 300 rounds and the smallest delta of the grid detected in
    at least 90 % of runs; delays of K1 (m = 0.5), AA5 (one agent) and AA6
    (30-round ramp) to show what a larger window costs.
With ARL0 = 1000 a null stream alarms somewhere in the fleet within 100 rounds
in roughly one run in ten, so for every case the same seeds are also run
without an attack ('no attack'), and for one-agent attacks a detection is
also counted only if the alarm comes from the compromised agent's fog
('own fog').

Outputs: results/small_shift.txt, results/small_shift.json
"""
import json
import os
import sys
import time
from dataclasses import replace

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx
import exp_ablation as eab
import exp_adaptive as ead

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
BURN = 30
CAL_SEEDS = list(range(100, 110))
VAL_SEEDS = list(range(200, 210))
ROUNDS = 5000
SEEDS = list(range(300, 330))
PRE = 60
LONG = 300
DELTA_ALL = [0.012, 0.024, 0.048, 0.096]
DELTA_ONE = [0.024, 0.048, 0.096, 0.192]
if QUICK:
    CAL_SEEDS, VAL_SEEDS, ROUNDS, SEEDS = CAL_SEEDS[:3], VAL_SEEDS[:3], 1500, SEEDS[:6]
    print("QUICK MODE: noisy")
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def trim(sig):
    return {k: v[BURN:] for k, v in sig.items() if isinstance(v, np.ndarray)}


def nulls(seeds, cfg, extra):
    return [fc.run_stream(s, fd_cfg=cfg, base_dets=False, scalars=False, keep_agent=False,
                          extra=extra, pre=ROUNDS, post=0) for s in seeds]


def arl_ci(alarms):
    a, ev, n = fx.arl_of(alarms)
    lo, hi = fx.poisson_ci(ev, n)
    return {'ARL': a, 'events': ev, 'rounds': n, 'lo': lo, 'hi': hi}


def fmt_arl(x):
    return f"{x['ARL']:.0f} [{x['lo']:.0f}, {x['hi']:.0f}] ({x['events']})"


def shift(Pt, delta):
    Pd = Pt.copy()
    Pd[:, 6] += delta
    return Pd / Pd.sum(1, keepdims=True)


def shift_attack(delta, one):
    """AA1 with shift delta on every agent, or (one=True) AA8: on one agent."""
    if not one:
        return dict(scenario='policy', m=0.5, attack=lambda r, Pt, Pd: shift(Pt, delta))

    def att(r, Pt, Pd):
        full = np.broadcast_to(Pt, Pd.shape)
        comp = ~np.isclose(Pd, full).all(axis=(1, 2))
        out = full.copy()
        out[comp] = shift(Pt, delta)
        return out
    return dict(scenario='policy', m=0.5, q=1, attack=att)


# ---------------------------------------------------------------- alarms
def alarm(sig, th):
    """th = (tau_a, tau_l) for one window, or a list of them for parallel windows."""
    if isinstance(th, tuple):
        return fc.endpoint_fog(sig[0], th[0], th[1], KP)
    parts = [fc.endpoint_fog(s, a, l, KP) for s, (a, l) in zip(sig, th)]
    return (np.any([p[0] for p in parts], 0), np.hstack([p[1] for p in parts]),
            np.hstack([p[2] for p in parts]))


def delay(sig, th, onset, fog=None):
    """fog: keep only that fog's columns (one per window) - an alarm raised by
    the compromised agent's own fog."""
    _, st, sr = alarm(sig, th)
    if fog is not None:
        cols = [fog + j * st.shape[1] // len(sig) for j in range(len(sig))]
        st, sr = st[:, cols], sr[:, cols]
    return fc.detection_delay(st, sr, onset, KP)


def run_case(cal, extra, kw, post, sig_of, TH):
    """Delays for every variant: (any fog, own fog of the first compromised agent).
    kw=None runs the same seeds without an attack (onset = PRE for counting)."""
    d = {v: [] for v in sig_of}
    for seed in SEEDS:
        if kw is None:
            o = fc.run_stream(seed, fd_cfg=cal, base_dets=False, scalars=False, keep_agent=False,
                              extra=extra, scenario=None, pre=PRE + post, post=0)
            on = PRE
            agent = int(np.random.default_rng(seed + 7).choice(cal.N, 1, replace=False)[0])
        else:
            o = fc.run_stream(seed, fd_cfg=cal, base_dets=False, scalars=False, keep_agent=False,
                              extra=extra, pre=PRE, post=post, **kw)
            on = o['onset']
            agent = int(o['compromised'][0])
        for v in sig_of:
            sig = [o[k] for k in sig_of[v]]
            d[v].append((delay(sig, TH[v], on), delay(sig, TH[v], on, agent % cal.F)))
    return d


def summarise(d, post, own):
    hs = (100, LONG) if post == LONG else (100,)
    out = {}
    for v, x in d.items():
        out[v] = {str(h): summary([a for a, _ in x], h) for h in hs}
        if own:
            out[v].update({f'{h} own': summary([b for _, b in x], h) for h in hs})
    return out


def calibrate_parallel(sigs, base):
    """One factor k on every window's thresholds so that the OR endpoint has ARL0 = T."""
    f = lambda k: eab.arl([alarm(s, [(k * a, k * l) for a, l in base])[0] for s in sigs])
    k = eab.smallest(f, 0.8, 5.0, T)
    return [(k * a, k * l) for a, l in base]


def summary(v, horizon):
    x = np.array([np.inf if d is None or d > horizon else d for d in v], float)
    det = np.isfinite(x)
    return {'rate': float(det.mean()), 'median': float(np.median(x[det])) if det.any() else None,
            'n': len(v)}


def cell(s):
    m = '-' if s['median'] is None else f"{s['median']:.1f}"
    return f"{100 * s['rate']:4.0f}% {m:>5s}"


# ---------------------------------------------------------------- (a) tracker
def part_a(cal, th_paper):
    extra = {'no reset on heartbeats': lambda P0, c: fc.HCDD(P0, cal, reset='event',
                                                             name='event'),
             'no tracker': lambda P0, c: fc.HCDD(P0, cal, tracker=False, name='V5')}
    names = {'reset on every summary': 'FogDrift', **{k: k for k in extra}}
    cs = nulls(CAL_SEEDS, cal, extra)
    TH = {'reset on every summary': th_paper}
    for v in extra:
        TH[v] = eab.calibrate([trim(o[v]) for o in cs], 'both')
    vs = nulls(VAL_SEEDS, cal, extra)
    val = {v: arl_ci([alarm([trim(o[names[v]])], TH[v])[0] for o in vs]) for v in names}
    log("(a) calibrated and validated")
    cases = {'no attack': (None, LONG),
             'K1 baseline': (ead.ATTACKS['K1 baseline'], 100),
             'AA1 tiny shift': (ead.ATTACKS['AA1 tiny shift'], LONG),
             'AA6 slow ramp': (ead.ATTACKS['AA6 slow ramp'], 100),
             'AA8 tiny + one agent': (ead.ATTACKS['AA8 tiny + one agent'], LONG),
             **{f'IX {g}': (kw, 100) for g, kw in eab.REGIMES.items()}}
    res = {}
    sig_of = {v: [k] for v, k in names.items()}
    for case, (kw, post) in cases.items():
        d = run_case(cal, extra, kw, post, sig_of, TH)
        res[case] = summarise(d, post, own=case in ('no attack', 'AA8 tiny + one agent'))
        log(f"(a) {case} done")
    return {'th': {k: list(v) for k, v in TH.items()}, 'val': val, 'res': res}


# ---------------------------------------------------------------- (b) window size
def part_b(cal):
    extra = {f'W={w}': (lambda P0, c, w=w: fc.HCDD(P0, replace(cal, W=w), name=f'W{w}'))
             for w in (50, 100)}
    sig_of = {'W=20': ['FogDrift'], 'W=50': ['W=50'], 'W=100': ['W=100'],
              'W=20 + W=100': ['FogDrift', 'W=100']}
    cs = nulls(CAL_SEEDS, cal, extra)
    get = lambda o, v: [trim(o[k]) for k in sig_of[v]]
    TH = {}
    for v in ('W=20', 'W=50', 'W=100'):
        TH[v] = eab.calibrate([get(o, v)[0] for o in cs], 'both')
    TH['W=20 + W=100'] = calibrate_parallel([get(o, 'W=20 + W=100') for o in cs],
                                            [TH['W=20'], TH['W=100']])
    vs = nulls(VAL_SEEDS, cal, extra)
    val = {v: arl_ci([alarm(get(o, v), TH[v])[0] for o in vs]) for v in sig_of}
    KB = {v: float(np.mean([sum(np.asarray(o[k]['sent'], float)[-1] for k in sig_of[v])
                            / ROUNDS / 1024 for o in vs])) for v in sig_of}
    log("(b) calibrated and validated")
    cases = {'no attack': (None, LONG),
             **{f'all agents, delta={d}': (shift_attack(d, False), LONG) for d in DELTA_ALL},
             **{f'one agent, delta={d}': (shift_attack(d, True), LONG) for d in DELTA_ONE},
             'K1 m=0.5': (ead.ATTACKS['K1 baseline'], 100),
             'AA5 one agent m=0.5': (ead.ATTACKS['AA5 one agent'], 100),
             'AA6 30-round ramp': (ead.ATTACKS['AA6 slow ramp'], 100)}
    res = {}
    for case, (kw, post) in cases.items():
        d = run_case(cal, extra, kw, post, sig_of, TH)
        res[case] = summarise(d, post, own=case == 'no attack' or case.startswith('one agent'))
        log(f"(b) {case} done")
    mds = {}
    for v in sig_of:
        for who, grid in (('all agents', DELTA_ALL), ('one agent', DELTA_ONE)):
            for h in (100, LONG):
                key = str(h) if who == 'all agents' else f'{h} own'
                ok = [dl for dl in grid if res[f'{who}, delta={dl}'][v][key]['rate'] >= 0.9]
                mds[f'{v}|{who}|{h}'] = min(ok) if ok else None
    return {'th': {k: (list(v) if isinstance(v, tuple) else [list(x) for x in v])
                   for k, v in TH.items()}, 'val': val, 'KB': KB, 'res': res, 'mds': mds}


# ---------------------------------------------------------------- report
def report(a, b):
    L = ["Small persistent shifts at matched ARL0 = 1000. Thresholds calibrated on "
         f"{len(CAL_SEEDS)} x {ROUNDS - BURN} null rounds (seeds {CAL_SEEDS[0]}-{CAL_SEEDS[-1]}), held-out "
         f"ARL on {len(VAL_SEEDS)} x {ROUNDS - BURN} rounds (seeds {VAL_SEEDS[0]}-{VAL_SEEDS[-1]}): ARL [exact "
         f"95% Poisson CI] (events). Attacks: seeds {SEEDS[0]}-{SEEDS[-1]}, onset after {PRE} rounds. "
         "Cells: detected within the horizon (%), median delay over detected runs.", "",
         "(a) Tracker reset rule"]
    vs = list(a['val'])
    for v in vs:
        L.append(f"  {v:24s} thresholds ({a['th'][v][0]:.3f}, {a['th'][v][1]:.4f})  "
                 f"held-out ARL {fmt_arl(a['val'][v])}")
    L.append(f"  {'attack (horizon)':34s} " + " ".join(f"{v:>24s}" for v in vs))
    for case, row in a['res'].items():
        for h in row[vs[0]]:
            L.append(f"  {case + ' (' + h + ')':34s} " + " ".join(f"{cell(row[v][h]):>24s}" for v in vs))
    L += ["", "(b) Window size W per context (same edge parameters)"]
    vs = list(b['val'])
    for v in vs:
        th = b['th'][v]
        ths = (f"({th[0]:.3f}, {th[1]:.4f})" if not isinstance(th[0], list) else
               " + ".join(f"({x[0]:.3f}, {x[1]:.4f})" for x in th))
        L.append(f"  {v:14s} thresholds {ths:34s} held-out ARL {fmt_arl(b['val'][v]):24s} "
                 f"KB/round {b['KB'][v]:.2f}")
    L.append(f"  {'attack (horizon)':34s} " + " ".join(f"{v:>14s}" for v in vs))
    for case, row in b['res'].items():
        for h in row[vs[0]]:
            L.append(f"  {case + ' (' + h + ')':34s} " + " ".join(f"{cell(row[v][h]):>14s}" for v in vs))
    L += ["", "Smallest delta of the grid detected in >= 90 % of runs (tool-6 probability shift; "
          "one agent: alarm from the compromised agent's own fog; "
          f"grids: every agent {DELTA_ALL}, one agent {DELTA_ONE}; '-' = none)"]
    for v in vs:
        L.append(f"  {v:14s} " + "  ".join(
            f"{who} within {h}: {b['mds'][f'{v}|{who}|{h}'] or '-'}"
            for who in ('all agents', 'one agent') for h in (100, LONG)))
    return "\n".join(L)


def main():
    cal = eab.load_cfg()
    th = json.load(open('calibration.json'))[str(T)]['FogDrift']
    a = part_a(cal, (th['tau_a'], th['tau_l']))
    b = part_b(cal)
    txt = report(a, b)
    print(txt)
    open('results/small_shift.txt', 'w').write(txt + "\n")
    json.dump({'a': a, 'b': b}, open('results/small_shift.json', 'w'), indent=1, default=float)


if __name__ == '__main__':
    main()
