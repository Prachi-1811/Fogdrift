"""Warm-up length W0 (Sec. V-K).

    python exp_warmup.py          # ~6 min
    python exp_warmup.py quick    # ~1 min

Needs edge_params.json and calibration.json (calibrate.py).

The reference P0 is estimated from W0 warm-up rounds. Thresholds stay at the
values calibrated with W0 = 50 (an operator does not re-calibrate when the
warm-up is cut short). A shorter warm-up gives a noisier P0, which raises
the null score and therefore the false-alarm rate at fixed thresholds.
Per seed: 200 null monitoring rounds (alarm events counted) then 100 drift
rounds (policy poisoning m = 0.5). Detection only counts alarms whose run
starts after onset.
Output: results/warmup.txt
"""
import json
import os
import sys
from dataclasses import fields, replace
import numpy as np
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

SEEDS = list(range(1000, 1030))
W0S = [10, 25, 50, 200]
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS = list(range(1000, 1005))
KP = fc.DEFAULT.KP
NULL = 200


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def main():
    cal = load_cfg()
    th = json.load(open('calibration.json'))['1000']['FogDrift']
    L = [f"Warm-up length W0 (Sec. V-K), thresholds fixed at their W0=50 values "
         f"(matched ARL0=1000), {len(SEEDS)} seeds, {NULL} null rounds + 100 drift rounds each",
         f"{'W0':>4s} {'null alarm events':>18s} {'events per 1000 rounds':>23s} "
         f"{'det.rate':>9s} {'median delay':>13s}"]
    for w0 in W0S:
        ev = n = 0
        ds = []
        for s in SEEDS:
            out = fc.run_stream(s, cfg=replace(fc.DEFAULT, W0=w0), fd_cfg=replace(cal, W0=w0),
                                base_dets=False, scalars=False, keep_agent=False,
                                scenario='policy', m=0.5, pre=NULL, post=100)
            sig = out['FogDrift']
            a, st, sr = fc.endpoint_fog(sig, th['tau_a'], th['tau_l'], KP)
            ev += fc.count_events(a[30:NULL])
            n += NULL - 30
            ds.append(fc.detection_delay(st, sr, out['onset'], KP))
        x = np.array([np.inf if d is None else d for d in ds], float)
        det = np.isfinite(x)
        md = f"{np.median(x[det]):.1f}" if det.any() else '-'
        L.append(f"{w0:4d} {ev:10d}/{n:<7d} {1000 * ev / n:23.1f} {det.mean():9.2f} {md:>13s}")
    txt = "\n".join(L)
    print(txt)
    open('results/warmup.txt', 'w').write(txt + "\n")


if __name__ == '__main__':
    main()
