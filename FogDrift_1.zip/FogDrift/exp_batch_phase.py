"""Detection timeline and batch-phase causality audit (Sec. V-C).

    python exp_batch_phase.py          # ~4 min
    python exp_batch_phase.py quick    # ~1 min

Needs edge_params.json and calibration.json (calibrate.py).

The attack starts `o` rounds after a tuple-batch boundary (o = 0..B-1).
Prediction for Centralised-Tuples with batch B and persistence K_p = 2:
the first batch that carries attack data arrives a = B - o rounds after onset
(a = B when o = 0), so the earliest possible alarm is a + K_p - 1 = a + 1.
A detector is causal if no measured delay is below this bound.
FogDrift and Centralised-Histogram are run on the same streams for reference
(their messages are not batched, so their bound is K_p = 2 for every o).
Output: results/batch_phase.txt
"""
import json
import os
import sys
from dataclasses import fields
import numpy as np
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

SEEDS = list(range(700, 730))
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS = list(range(700, 705))
KP = fc.DEFAULT.KP


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def main():
    cfg = load_cfg()
    th = json.load(open('calibration.json'))['1000']
    extra = {'Cent-Hist': lambda P0, c: fc.HCDD(P0, c, trigger=False, name='Cent-Hist'),
             'CT(B=5)': lambda P0, c: fc.CentralTuples(P0, c, B=5),
             'CT(B=10)': lambda P0, c: fc.CentralTuples(P0, c, B=10)}
    L = [f"Batch-phase audit (Sec. V-C), policy poisoning m=0.5, matched ARL0=1000, "
         f"{len(SEEDS)} seeds per offset",
         "o = rounds between the last batch boundary and onset; a = predicted arrival of the "
         "first attack data (rounds after onset); bound = a + K_p - 1",
         f"{'detector':10s} {'o':>3s} {'a':>3s} {'bound':>6s} {'min':>5s} {'median':>7s} "
         f"{'max':>5s} {'below bound':>12s}"]
    for B, name in [(5, 'CT(B=5)'), (10, 'CT(B=10)')]:
        for o in range(B):
            ds = []
            for s in SEEDS:
                # batches close at rounds that are multiples of B (1-indexed);
                # onset index `pre` gives offset o = pre mod B
                pre = 60 + o
                out = fc.run_stream(s, fd_cfg=cfg, base_dets=False, scalars=False,
                                    keep_agent=False, extra=extra, scenario='policy',
                                    m=0.5, pre=pre, post=60)
                t = th[name]
                _, st, sr = fc.endpoint_fog(out[name], t['tau_a'], t['tau_l'], KP)
                ds.append(fc.detection_delay(st, sr, out['onset'], KP))
            a = B - o if o > 0 else B
            bound = a + KP - 1
            x = np.array([np.nan if d is None else d for d in ds], float)
            below = int(np.nansum(x < bound))
            L.append(f"{name:10s} {o:3d} {a:3d} {bound:6d} {np.nanmin(x):5.0f} "
                     f"{np.nanmedian(x):7.1f} {np.nanmax(x):5.0f} {below:7d}/{len(ds)}")
        L.append("")
    # reference: unbatched detectors, onset offsets do not matter
    for name in ['FogDrift', 'Cent-Hist']:
        ds = []
        for s in SEEDS:
            out = fc.run_stream(s, fd_cfg=cfg, base_dets=False, scalars=False,
                                keep_agent=False, extra=extra, scenario='policy',
                                m=0.5, pre=60, post=60)
            t = th[name]
            _, st, sr = fc.endpoint_fog(out[name], t['tau_a'], t['tau_l'], KP)
            ds.append(fc.detection_delay(st, sr, out['onset'], KP))
        x = np.array([np.nan if d is None else d for d in ds], float)
        L.append(f"{name:10s} {'-':>3s} {'1':>3s} {KP:6d} {np.nanmin(x):5.0f} "
                 f"{np.nanmedian(x):7.1f} {np.nanmax(x):5.0f} {int(np.nansum(x < KP)):7d}/{len(ds)}")
    txt = "\n".join(L)
    print(txt)
    open('results/batch_phase.txt', 'w').write(txt + "\n")


if __name__ == '__main__':
    main()
