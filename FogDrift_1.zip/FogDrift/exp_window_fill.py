"""Partly filled context windows and the minimum-sample rule (Sec. III-C).

    python exp_window_fill.py          # ~20 min
    python exp_window_fill.py quick    # ~4 min, noisy

The edge window of each context holds the last W = 20 calls of that context
and never expires, so n_c = W once a context has been seen W times. Windows
start empty when monitoring starts: the W0 = 50 warm-up rounds only estimate
P0 (pooled over the fleet) and do not fill the windows; the first BURN = 30
monitored rounds fill them and raise no alarm (they are excluded from
calibration and from every ARL). A context enters the score once
n_c >= n_min (10 per agent, 30 per fog); between n_min and W its plug-in KL
term has a larger bias than at the full windows the thresholds were
calibrated on.

Calibrated edge parameters and thresholds (edge_params.json, calibration.json,
target ARL0 = 1000). Rules, all run on the same calls:
  paper            n_min = 10 per agent / 30 per fog, reference from W0 = 50
  n_min = W        20 / 200 (full windows only), W0 = 50
  count warm-up    paper n_min, warm-up extended until the rarest context has
                   N_REF = 4000 calls (500 rounds at pi = 0.02; 50 otherwise)
  n_min = W, count warm-up
  count warm-up + offset
                   paper n_min, count warm-up, and each context term minus
                   b(n_c) - b(W): b(n) is the null mean of the term at n
                   calls, computed by Monte Carlo from P0 itself (agent:
                   n = 0..W; fog: total over its agents, grid of 10, split
                   evenly at random); zero at full windows, so the
                   thresholds are unchanged.
With full windows the rules give identical scores (except the reference),
so they share the thresholds.

Workloads: stationary uniform contexts (paper default); workload drift (fresh
pi ~ Dir(2) every 100 rounds, as in Table XII); one rare context
(pi = 0.02, other three 0.98/3), stationary.

(a) Null mean of one context's plug-in KL term against the estimated P0, by
    sample size (agent window; fog aggregate of 10 agents).
(b) Share of eligible context terms with n_min <= n_c < W (fog: < 10 W)
    after the burn-in.
(c) Held-out ARL after the burn-in (any-fog endpoint, Poisson 95% CI),
    10 x 5000 rounds.
(d) Ramp-up, 200 fresh streams of 150 rounds: share with an endpoint alarm
    in the first BURN rounds, and alarm events per 1000 rounds in rounds
    31-150 (target 1), while a rare context's windows are still filling.
(e) Detection delay, 30 seeds, onset at round 60: policy poisoning m = 0.5
    and 0.15 on all contexts, and m = 0.5 on the rare context only.

Outputs: results/window_fill.txt, results/window_fill.json
"""
import json
import os
import sys
import time
from dataclasses import fields, replace

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
BURN = 30
ROUNDS = 5000
NULL_SEEDS = list(range(5300, 5310))
RAMP_SEEDS = list(range(5400, 5600))
RAMP_ROUNDS = 150
RUN_SEEDS = list(range(5600, 5630))
BIAS_SEEDS = list(range(5700, 5740))
PRE, POST = 60, 200
RARE = 0.02
N_REF = 4000
MC = 300                                   # Monte Carlo draws per offset point
if QUICK:
    NULL_SEEDS, ROUNDS = NULL_SEEDS[:3], 1500
    RAMP_SEEDS, RUN_SEEDS, BIAS_SEEDS = RAMP_SEEDS[:40], RUN_SEEDS[:8], BIAS_SEEDS[:8]
    MC = 100
    print("QUICK MODE: noisy")
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


CFG = load_cfg()
TH = json.load(open('calibration.json'))[str(T)]['FogDrift']
TA, TL = TH['tau_a'], TH['tau_l']
PER = CFG.N // CFG.F                       # agents per fog
FULL_FOG = CFG.W * PER
CFG_W = replace(CFG, NMIN_AGENT=CFG.W, NMIN_FOG=FULL_FOG)
# rule -> (detector config, count-based warm-up, bias offset)
RULES = {'paper': (CFG, False, False),
         'n_min = W': (CFG_W, False, False),
         'count warm-up': (CFG, True, False),
         'n_min = W, count warm-up': (CFG_W, True, False),
         'count warm-up + offset': (CFG, True, True)}
UNIFORM = np.full(CFG.L, 1.0 / CFG.L)
RARE_PI = np.array([RARE] + [(1 - RARE) / (CFG.L - 1)] * (CFG.L - 1))
WORKLOADS = ['stationary', 'workload drift', 'rare context']


def warmup_rounds(pi_w, count_based):
    """W0, or enough rounds for N_REF warm-up calls of the rarest context."""
    if not count_based:
        return CFG.W0
    return max(CFG.W0, int(np.ceil(N_REF / (CFG.N * CFG.K * pi_w.min()))))


def workload(name, seed, rounds):
    """(warm-up mixture, per-round mixture function)."""
    if name == 'stationary':
        return UNIFORM, lambda r: UNIFORM
    if name == 'rare context':
        return RARE_PI, lambda r: RARE_PI
    wr = np.random.default_rng(seed + 300_000)
    pis = [wr.dirichlet(np.full(CFG.L, 2.0)) for _ in range(rounds // 100 + 1)]
    return UNIFORM, lambda r: pis[r // 100]


# --------------------------------------------------------------------------
# Null mean of one context term by sample size
# --------------------------------------------------------------------------
def kl_rows(cnt, p0):
    H = fc.smooth(cnt, CFG)
    return np.sum(H * np.log(H / p0), -1)


def agent_term_mean(rng, p_gen, p0, n, size):
    return float(kl_rows(rng.multinomial(np.full(size, n), p_gen), p0).mean())


def fog_term_mean(rng, p_gen, p0, tot, size):
    k = rng.multinomial(tot, np.full(PER, 1.0 / PER), size=size)        # (S, PER)
    cnt = rng.multinomial(k.ravel(), p_gen).reshape(size, PER, CFG.M)
    H = fc.smooth(cnt, CFG)
    Hf = (k[..., None] * H).sum(1) / max(tot, 1)
    return float(np.sum(Hf * np.log(Hf / p0), -1).mean())


def bias_table():
    rows = {'agent': {n: [] for n in (10, 15, 20)}, 'fog': {n: [] for n in (30, 100, 200)}}
    for s in BIAS_SEEDS:
        rng = np.random.default_rng(s)
        Pt = fc.build_P0(rng, CFG)
        P0 = fc.estimate_P0(rng, Pt, UNIFORM, CFG)
        for n in rows['agent']:
            rows['agent'][n].append(np.mean([agent_term_mean(rng, Pt[c], P0[c], n, 400)
                                             for c in range(CFG.L)]))
        for n in rows['fog']:
            rows['fog'][n].append(np.mean([fog_term_mean(rng, Pt[c], P0[c], n, 200)
                                           for c in range(CFG.L)]))
    return {t: {str(n): float(np.mean(x)) for n, x in d.items()} for t, d in rows.items()}


def make_offsets(P0, rng):
    """b(n) - b(W) per context from P0 alone (what a deployment can compute)."""
    L = CFG.L
    ba = np.zeros((L, CFG.W + 1))
    grid = np.arange(0, FULL_FOG + 1, 10)
    bf = np.zeros((L, len(grid)))
    for c in range(L):
        for n in range(1, CFG.W + 1):
            ba[c, n] = agent_term_mean(rng, P0[c], P0[c], n, MC)
        for j, g in enumerate(grid[1:], 1):
            bf[c, j] = fog_term_mean(rng, P0[c], P0[c], int(g), MC)
    ba -= ba[:, -1:]
    bf -= bf[:, -1:]
    cidx = np.arange(L)

    def agent_off(n_c):
        n = np.clip(n_c, 0, CFG.W).astype(int)
        return ba[cidx, n]

    def fog_off(tot):
        t = np.clip(tot, 0, FULL_FOG)
        return np.array([np.interp(t[c], grid, bf[c]) for c in range(L)])

    return agent_off, fog_off


# --------------------------------------------------------------------------
# One stream, every rule on the same calls
# --------------------------------------------------------------------------
def stream(seed, wl, rounds, onset=None, m=0.5, rare_only=False, occupancy=False):
    rng = np.random.default_rng(seed)
    pi_w, pi_r = workload(wl, seed, rounds)
    Pt = fc.build_P0(rng, CFG)
    nw = max(warmup_rounds(pi_w, cb) for _, cb, _ in RULES.values())
    cnt, refs = np.zeros((CFG.L, CFG.M)), {}
    for w in range(nw):
        cs, ts = fc.gen_round(rng, Pt, pi_w, CFG)
        np.add.at(cnt, (cs.ravel(), ts.ravel()), 1)
        refs[w + 1] = fc.smooth(cnt, CFG)
    off_rng = np.random.default_rng(seed + 900_000)
    dets, offs = {}, {}
    for k, (cfg, cb, use_off) in RULES.items():
        P0 = refs[warmup_rounds(pi_w, cb)]
        if use_off:
            offs.setdefault(id(P0), make_offsets(P0, off_rng))
        dets[k] = fc.HCDD(P0, cfg, offsets=offs[id(P0)] if use_off else None)
    P_att = Pt
    if onset is not None:
        Pd = fc.drifted(Pt, 'policy', m, seed)
        P_att = Pd
        if rare_only:
            P_att = Pt.copy()
            P_att[0] = Pd[0]
    sig = {k: {'fog_score': [], 'fog_amax': [], 'fog_has': []} for k in dets}
    occ = {'agent_partial': 0, 'agent_terms': 0, 'fog_partial': 0, 'fog_terms': 0}
    fog_of = np.arange(CFG.N) % CFG.F
    for r in range(rounds):
        P = P_att if onset is not None and r >= onset else Pt
        cs, ts = fc.gen_round(rng, P, pi_r(r), CFG)
        for k, d in dets.items():
            o = d.step(cs, ts)
            for key in sig[k]:
                sig[k][key].append(o[key])
        if occupancy and r >= BURN:
            fn = dets['paper'].fn                             # counts the fog uses
            elig = fn >= CFG.NMIN_AGENT
            occ['agent_terms'] += int(elig.sum())
            occ['agent_partial'] += int((elig & (fn < CFG.W)).sum())
            tot = np.stack([fn[fog_of == f].sum(0) for f in range(CFG.F)])
            elig = tot >= CFG.NMIN_FOG
            occ['fog_terms'] += int(elig.sum())
            occ['fog_partial'] += int((elig & (tot < FULL_FOG)).sum())
    return {k: {kk: np.array(v) for kk, v in s.items()} for k, s in sig.items()}, occ


def endpoint(sig):
    return fc.endpoint_fog(sig, TA, TL, KP)


def null_part():
    out = {}
    for wl in WORKLOADS:
        streams = [stream(s, wl, ROUNDS, occupancy=True) for s in NULL_SEEDS]
        occ = {k: sum(o[k] for _, o in streams) for k in streams[0][1]}
        res = {'occupancy': {'agent': occ['agent_partial'] / max(occ['agent_terms'], 1),
                             'fog': occ['fog_partial'] / max(occ['fog_terms'], 1)}}
        for k in RULES:
            al = [endpoint(fx.trim(sg[k], BURN))[0] for sg, _ in streams]
            arl, ev, n = fx.arl_of(al)
            lo, hi = fx.poisson_ci(ev, n)
            res[k] = {'ARL': arl, 'events': ev, 'rounds': n, 'lo': lo, 'hi': hi}
        log(f"null {wl}: {res}")
        ramp = {k: [0, 0] for k in RULES}
        for s in RAMP_SEEDS:
            sg, _ = stream(s, wl, RAMP_ROUNDS)
            for k in RULES:
                st = endpoint(sg[k])[0]
                rise = st & ~np.concatenate([[False], st[:-1]])     # event starts
                ramp[k][0] += int(st[:BURN].any())
                ramp[k][1] += int(rise[BURN:].sum())
        n_after = len(RAMP_SEEDS) * (RAMP_ROUNDS - BURN)
        res['ramp'] = {k: {'first': v[0] / len(RAMP_SEEDS), 'rate_after': 1000 * v[1] / n_after,
                           'events_after': v[1], 'rounds_after': n_after}
                       for k, v in ramp.items()}
        log(f"ramp {wl}: {res['ramp']}")
        out[wl] = res
    return out


def delay_part():
    cases = [('stationary', 0.5, False), ('stationary', 0.15, False),
             ('workload drift', 0.5, False), ('workload drift', 0.15, False),
             ('rare context', 0.5, False), ('rare context', 0.15, False),
             ('rare context', 0.5, True)]
    out = []
    for wl, m, rare in cases:
        row = {'workload': wl, 'm': m, 'attack': 'rare context only' if rare else 'all contexts'}
        d = {k: [] for k in RULES}
        for s in RUN_SEEDS:
            sg, _ = stream(s, wl, PRE + POST, onset=PRE, m=m, rare_only=rare)
            for k in RULES:
                _, st, sr = endpoint(sg[k])
                d[k].append(fc.detection_delay(st, sr, PRE, KP))
        for k in RULES:
            row[k] = {'median': fx.med(d[k]), 'detected': sum(x is not None for x in d[k]),
                      'n': len(d[k])}
        out.append(row)
        log(f"delay {row}")
    return out


def report(res):
    L = [f"Partly filled context windows. Calibrated FogDrift (edge_params.json, "
         f"calibration.json, ARL0 = {T}, tau_a = {TA:.3f}, tau_l = {TL:.4f}); W = {CFG.W}; "
         f"windows start empty and fill in the first {BURN} monitored rounds (burn-in, no "
         f"alarm); the W0 = {CFG.W0} warm-up rounds only estimate P0. Rules: paper n_min = "
         f"10 per agent / 30 per fog; n_min = W: 20 / {FULL_FOG}; count warm-up: until the "
         f"rarest context has {N_REF} warm-up calls; offset: each context term minus "
         f"b(n_c) - b(W). Rare context: pi = {RARE}.", "",
         "(a) Null mean of one context's plug-in KL term against the estimated P0 "
         f"({len(BIAS_SEEDS)} references); (M-1)/(2n) in brackets"]
    M = CFG.M
    for t, d in res['bias'].items():
        L.append(f"  {t:6s} " + "  ".join(f"n={n}: {v:.3f} [{(M - 1) / (2 * int(n)):.3f}]"
                                          for n, v in d.items()))
    L += ["", "(b)-(d) Null streams. Partial: share of eligible context terms with "
          "n_min <= n_c < W after the burn-in (paper rule). ARL after the burn-in "
          f"({len(NULL_SEEDS)} x {ROUNDS} rounds). Ramp-up ({len(RAMP_SEEDS)} fresh streams of "
          f"{RAMP_ROUNDS} rounds): share with an alarm in rounds 1-{BURN}, and alarm events per "
          f"1000 rounds in rounds {BURN + 1}-{RAMP_ROUNDS} (target 1)."]
    L.append(f"{'workload':15s} {'partial agent':>13s} {'partial fog':>11s}  "
             f"{'rule':25s} {'ARL [95% CI] (events)':>28s} {'1-30':>6s} {'/1000 after':>11s}")
    for wl, r in res['null'].items():
        for i, k in enumerate(RULES):
            a = r[k]
            occ = (f"{r['occupancy']['agent']:13.4f} {r['occupancy']['fog']:11.4f}" if i == 0
                   else f"{'':13s} {'':11s}")
            ci = f"{a['ARL']:.0f} [{a['lo']:.0f}, {a['hi']:.0f}] ({a['events']})"
            L.append(f"{wl if i == 0 else '':15s} {occ}  {k:25s} {ci:>28s} "
                     f"{r['ramp'][k]['first']:6.3f} {r['ramp'][k]['rate_after']:11.2f}")
    L += ["", f"(e) Detection delay, policy poisoning, onset at round {PRE}, {len(RUN_SEEDS)} "
          "seeds: median rounds (detected)"]
    L.append(f"{'workload':15s} {'m':>5s} {'drift on':18s} " +
             " ".join(f"{k:>25s}" for k in RULES))
    for r in res['delay']:
        L.append(f"{r['workload']:15s} {r['m']:5.2f} {r['attack']:18s} " +
                 " ".join(f"{fx.fmt(r[k]['median'], 1) + ' (' + str(r[k]['detected']) + '/' + str(r[k]['n']) + ')':>25s}"
                          for k in RULES))
    return "\n".join(L)


if __name__ == '__main__':
    res = {'bias': bias_table()}
    log(f"bias {res['bias']}")
    res['null'] = null_part()
    res['delay'] = delay_part()
    txt = report(res)
    print(txt)
    open('results/window_fill.txt', 'w').write(txt + "\n")
    json.dump(res, open('results/window_fill.json', 'w'), indent=2, default=float)
