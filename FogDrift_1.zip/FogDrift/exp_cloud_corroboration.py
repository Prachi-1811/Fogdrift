"""Cloud tier of Eq. (6): calibration of tau_g and multi-fog corroboration
(Sec. V-M, Table XII, Table IX row V3).

    python exp_cloud_corroboration.py          # ~15 min
    python exp_cloud_corroboration.py quick    # ~3 min, noisy
    python exp_cloud_corroboration.py report   # rebuild the text from the JSON

Needs edge_params.json and calibration.json (calibrate.py) and
results/ablation_thresholds.json (exp_ablation.py). tau_a and tau_l keep their
calibrated values; only the cloud alarm is studied. Null streams use the
generator of calibrate.py, so seeds 100-109 and 200-209 reproduce Table XII.

Cloud rules compared:
  A  untrimmed:   corroboration OR mean of the fog scores > tau_g
                  (tau_g calibrated on null streams, as calibrate.py does);
  B               corroboration branch alone;
  C  Eq. (6):     corroboration OR mean of the fog scores without the largest
                  > tau_g, with tau_g calibrated on null streams in which one
                  fog reports a fabricated stable alert in every round, so the
                  two branches share the false-alarm budget in that worst case.

(a) tau_g of rule A from 10 seeds (calibrate.py), 40 seeds and four disjoint
    10-seed blocks; held-out ARL on 40 seeds (Poisson and stream-bootstrap CI),
    per-stream dispersion of events, within-stream correlation of the fog
    scores and the between-stream share of their variance.
(b) Long-run duty cycle and ARL on the 40 held-out streams: no fault,
    workload drift, one or two faulty fogs (fabricated alert, score 2 tau_l),
    and a benign tool outage (top-2 tools deprecated, m = 0.5) on the 10
    agents of one fog. Rule C on the 10 seeds of Table XII.
(c) Detection, 30 seeds: fleet-wide policy poisoning m = 0.5 and 0.15, and
    m = 0.5 with one fog silent.
(d) Table IX regimes (exp_ablation.py, seeds 300-329) with the cloud alarm as
    endpoint (row V3).
(e) Corroboration branch on the 40 held-out null streams: per-fog stable-alert
    duty cycles and events, the number of rounds with two or more fogs in
    stable alert expected if the fogs alarmed independently, and the observed
    number; with one faulty fog, the branch fires on every stable alert of the
    other four fogs, so its ARL is predicted from their events.

Outputs: results/cloud_corroboration.txt, results/cloud_corroboration.json
"""
import json
import os
import sys
import time
from dataclasses import fields

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)

QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
P_CORR = fc.DEFAULT.P_CORR
BURN = 30
ROUNDS = 5000
CAL_SEEDS = list(range(100, 110)) + list(range(4000, 4030))      # 40 x 5000
VAL_SEEDS = list(range(200, 210)) + list(range(4100, 4130))      # 40 x 5000
RUN_SEEDS = list(range(4200, 4230))
PRE, POST = 60, 100
FAB_SCORE = 2                      # fabricated fog score, in units of tau_l
if QUICK:
    CAL_SEEDS = CAL_SEEDS[:4] + list(range(4000, 4004))
    VAL_SEEDS = VAL_SEEDS[:4] + list(range(4100, 4104))
    RUN_SEEDS, ROUNDS = RUN_SEEDS[:6], 1500
    print("QUICK MODE: noisy")
NBLOCK = len(CAL_SEEDS) // 10 if not QUICK else 2
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


def trim(sig):
    return {k: v[BURN:] for k, v in sig.items()
            if isinstance(v, np.ndarray) and v.ndim >= 1 and len(v) > BURN}


# --------------------------------------------------------------------------
# Cloud rule, Eq. (6), with two choices of the average-score statistic
# --------------------------------------------------------------------------
def avg_score(sig, agg):
    has = sig['fog_has']
    n = has.sum(1)
    s = np.where(has, sig['fog_score'], 0.0)
    if agg == 'mean':
        return s.sum(1) / np.maximum(n, 1)
    top = np.where(has, sig['fog_score'], -np.inf).max(1)
    return np.where(n >= 2, (s.sum(1) - top) / np.maximum(n - 1, 1), 0.0)


def cloud(sig, ta, tl, tg, agg='mean'):
    """Returns (cloud alarm, corroboration branch, average-score branch)."""
    _, st, _ = fc.endpoint_fog(sig, ta, tl, KP)
    has = sig['fog_has']
    corr = (st & has).sum(1) / np.maximum(has.sum(1), 1) >= P_CORR
    avg, _ = fc.stable_alarm(avg_score(sig, agg) > tg, KP)
    return corr | avg, corr, avg


def calibrate_tg(sigs, ta, tl, agg):
    f = lambda tg: fx.arl_of([cloud(s, ta, tl, tg, agg)[0] for s in sigs])
    return fx.smallest_param(f, 1e-4, 10.0, T)


def profile(alarms):
    p = fx.alarm_profile(alarms)
    ev = [fc.count_events(a) for a in alarms]
    p['dispersion'] = float(np.var(ev, ddof=1) / max(np.mean(ev), 1e-9)) if len(ev) > 1 else np.nan
    return p


def boot_ci(alarms, reps=10000, seed=0):
    """95% CI of the pooled ARL from resampling whole streams (events cluster
    by stream, so the Poisson CI is too narrow)."""
    rng = np.random.default_rng(seed)
    ev = np.array([fc.count_events(a) for a in alarms])
    n = np.array([len(a) for a in alarms])
    b = []
    for _ in range(reps):
        i = rng.integers(0, len(alarms), len(alarms))
        e = ev[i].sum()
        b.append(n[i].sum() / e if e else np.inf)
    return [float(np.percentile(b, 2.5)), float(np.percentile(b, 97.5))]


def null_streams(cfg, seeds, workload=False):
    out = []
    for s in seeds:
        sched = None
        if workload:
            wr = np.random.default_rng(s + 300_000)
            pis = [wr.dirichlet(np.full(cfg.L, 2.0)) for _ in range(ROUNDS // 100 + 1)]
            sched = lambda r, pis=pis: pis[r // 100]
        o = fc.run_stream(s, pre=ROUNDS, post=0, fd_cfg=cfg, pi_schedule=sched,
                          keep_agent=False, scalars=False, base_dets=False)
        out.append(trim(o['FogDrift']))
    return out


def score_structure(sigs):
    """Within-stream correlation of the five fog scores, and the share of the
    variance of the mean fog score that lies between streams."""
    cors, means, within = [], [], []
    for s in sigs:
        x = s['fog_score']
        c = np.corrcoef(x.T)
        cors.append(np.mean(c[np.triu_indices_from(c, 1)]))
        a = x.mean(1)
        means.append(a.mean())
        within.append(a.var())
    between = np.var(means, ddof=1)
    return {'cross_fog_corr': float(np.mean(cors)),
            'between_share': float(between / (between + np.mean(within)))}


# --------------------------------------------------------------------------
# Scenarios
# --------------------------------------------------------------------------
def delay(alarm, onset):
    st, sr = fc.stable_alarm(np.asarray(alarm, bool), 1)
    return fc.detection_delay(st, sr, onset, KP)


def local_outage(cfg):
    fog0 = np.arange(cfg.N) % cfg.F == 0

    def attack(r, Pt, Pd):
        Pa = np.broadcast_to(Pt, (cfg.N, cfg.L, cfg.M)).copy()
        Pa[fog0] = Pd
        return Pa
    return attack


def fabricate(sig, fogs, onset, score):
    s = {k: v.copy() for k, v in sig.items()}
    s['fog_score'][onset:, fogs] = score
    s['fog_has'][onset:, fogs] = True
    return s


def suppress(sig, fogs, onset):
    s = {k: v.copy() for k, v in sig.items()}
    s['fog_score'][onset:, fogs] = 0.0
    s['fog_amax'][onset:, fogs] = 0.0
    s['fog_has'][onset:, fogs] = False
    return s


def run(cfg, seed, **kw):
    o = fc.run_stream(seed, pre=PRE, post=POST, fd_cfg=cfg, keep_agent=False,
                      scalars=False, base_dets=False, **kw)
    return o['FogDrift'], o['onset']


# --------------------------------------------------------------------------
RULES = ['fog endpoint', 'A: Eq.(6)', 'B: corroboration only', 'C: robust Eq.(6)']


def alarms_by_rule(sig, ta, tl, tg):
    return {'fog endpoint': fc.endpoint_fog(sig, ta, tl, KP)[0],
            'A: Eq.(6)': cloud(sig, ta, tl, tg['A'], 'mean')[0],
            'B: corroboration only': cloud(sig, ta, tl, np.inf, 'mean')[1],
            'C: robust Eq.(6)': (cloud(sig, ta, tl, tg['C'], 'trimmed')[0]
                                 if tg['C'] is not None else np.zeros(len(sig['fog_has']), bool))}


def coincidence(sigs, ta, tl, faulty=None):
    """Per-fog stable-alert duty and events; rounds with >= ceil(p F) fogs in
    stable alert, observed and expected under independent fogs."""
    need = int(np.ceil(P_CORR * sigs[0]['fog_has'].shape[1] - 1e-9))
    duty, ev, obs, exp_r, rounds = [], [], 0, 0.0, 0
    for s in sigs:
        _, st, _ = fc.endpoint_fog(s, ta, tl, KP)
        st = st & s['fog_has']
        d = st.mean(0)
        duty.append(d)
        ev.append([fc.count_events(st[:, f]) for f in range(st.shape[1])])
        obs += int((st.sum(1) >= need).sum())
        # P(at least `need` of F independent Bernoulli(d_f)) per round
        pk = np.zeros(st.shape[1] + 1)
        pk[0] = 1.0
        for q in d:
            pk[1:] = pk[1:] * (1 - q) + pk[:-1] * q
            pk[0] *= 1 - q
        exp_r += pk[need:].sum() * len(st)
        rounds += len(st)
    ev = np.array(ev)
    out = {'need': need, 'rounds': rounds, 'duty_per_fog': np.mean(duty, 0).tolist(),
           'events_per_fog': ev.sum(0).tolist(), 'observed_rounds': obs,
           'expected_rounds_independent': float(exp_r)}
    if faulty is not None:
        others = [f for f in range(ev.shape[1]) if f not in faulty]
        out['predicted_ARL_one_faulty'] = float(rounds / max(ev[:, others].sum(), 1))
    return out


def long_run(sigs, ta, tl, tg):
    out = {}
    for r in RULES:
        out[r] = profile([alarms_by_rule(s, ta, tl, tg)[r] for s in sigs])
    return out


def main():
    cfg = load_cfg()
    th = json.load(open('calibration.json'))[str(T)]['FogDrift']
    ta, tl, tg10 = th['tau_a'], th['tau_l'], th['tau_g']
    fab = FAB_SCORE * tl
    res = {'tau_a': ta, 'tau_l': tl, 'tau_g_calibrate': tg10, 'fab_score': fab}

    # ---------------- Part 1: tau_g of Eq. (6) ----------------
    cal = null_streams(cfg, CAL_SEEDS)
    log(f"{len(cal)} calibration streams")
    val = null_streams(cfg, VAL_SEEDS)
    val_w = null_streams(cfg, VAL_SEEDS, workload=True)
    log(f"{len(val)} + {len(val_w)} held-out streams")
    n10 = 10 if not QUICK else 4
    nb = len(cal) // NBLOCK
    srcs = {'calibrate.py (10 seeds)': None, 'first 10 seeds': cal[:n10],
            f'all {len(cal)} seeds': cal}
    for b in range(NBLOCK):
        srcs[f'block {b} (10 seeds)'] = cal[b * nb:(b + 1) * nb]
    part1 = []
    for src, sub in srcs.items():
        tg = tg10 if sub is None else calibrate_tg(sub, ta, tl, 'mean')
        sub = cal[:n10] if sub is None else sub
        row = {'calibration': src, 'tau_g': tg,
               'cal': profile([cloud(s, ta, tl, tg)[0] for s in sub]),
               'val': profile([cloud(s, ta, tl, tg)[0] for s in val]),
               'val_workload': profile([cloud(s, ta, tl, tg)[0] for s in val_w]),
               'val_first10': profile([cloud(s, ta, tl, tg)[0] for s in val[:n10]]),
               'val_corr': profile([cloud(s, ta, tl, tg)[1] for s in val]),
               'val_avg': profile([cloud(s, ta, tl, tg)[2] for s in val]),
               'val_boot': boot_ci([cloud(s, ta, tl, tg)[0] for s in val]),
               'val_first10_boot': boot_ci([cloud(s, ta, tl, tg)[0] for s in val[:n10]])}
        part1.append(row)
        log(f"tau_g from {src}: {tg:.5f}; cal ARL {row['cal']['ARL']:.0f} ({row['cal']['events']}); "
            f"held-out {row['val']['ARL']:.0f} [{row['val']['ARL_lo']:.0f},{row['val']['ARL_hi']:.0f}]; "
            f"workload {row['val_workload']['ARL']:.0f}; first-10 {row['val_first10']['ARL']:.0f}")
    res['part1'] = part1
    res['structure'] = score_structure(cal)
    log(f"score structure {res['structure']}")

    # ---------------- Part 2: what corroboration is for ----------------
    tgA = calibrate_tg(cal, ta, tl, 'mean')
    # C: corroboration OR trimmed mean, tau_g calibrated for the worst case of
    # one faulty fog (fog 0 reports a fabricated stable alert in every round)
    cal_f = [fabricate(s, [0], 0, fab) for s in cal]
    tgC = calibrate_tg(cal_f, ta, tl, 'trimmed')
    corr_only_f = profile([cloud(s, ta, tl, np.inf)[1] for s in cal_f])
    tg = {'A': tgA, 'C': tgC}
    res['tau_g_used'] = tg
    res['corr_branch_one_faulty_cal'] = corr_only_f
    log(f"tau_g A={tgA:.5f}, C={tgC}; corroboration alone with one faulty fog (calibration): "
        f"ARL {corr_only_f['ARL']:.0f}")
    lr = {}
    lr['no fault'] = long_run(val, ta, tl, tg)
    lr['workload drift'] = long_run(val_w, ta, tl, tg)
    lr['1 faulty fog'] = long_run([fabricate(s, [0], 0, fab) for s in val], ta, tl, tg)
    lr['2 faulty fogs'] = long_run([fabricate(s, [0, 1], 0, fab) for s in val], ta, tl, tg)
    loc = []
    for s in VAL_SEEDS:
        o = fc.run_stream(s, pre=0, post=ROUNDS, fd_cfg=cfg, scenario='deprec', m=0.5,
                          attack=local_outage(cfg), keep_agent=False, scalars=False,
                          base_dets=False)
        loc.append(trim(o['FogDrift']))
    lr['local outage, one fog'] = long_run(loc, ta, tl, tg)
    for k, v in lr.items():
        log(f"long run {k}: " + "; ".join(f"{r} {v[r]['ARL']:.0f}" for r in RULES))
    res['long_run'] = lr
    res['table12_cloud'] = {
        'stationary': profile([cloud(s, ta, tl, tgC, 'trimmed')[0] for s in val[:n10]]),
        'workload drift': profile([cloud(s, ta, tl, tgC, 'trimmed')[0] for s in val_w[:n10]])}

    win = {}
    for name, kw, post in (('fleet-wide, m=0.5', dict(scenario='policy', m=0.5), None),
                           ('fleet-wide, m=0.15', dict(scenario='policy', m=0.15), None),
                           ('fleet-wide m=0.5, 1 fog silent', dict(scenario='policy', m=0.5), 'silent')):
        ds = {r: [] for r in RULES}
        for sd in RUN_SEEDS:
            sig, on = run(cfg, sd, **kw)
            if post == 'silent':
                sig = suppress(sig, [0], on)
            al = alarms_by_rule(sig, ta, tl, tg)
            for r in RULES:
                ds[r].append(delay(al[r], on))
        win[name] = {r: {'rate': float(np.mean([d is not None for d in v])), 'median': fx.med(v)}
                     for r, v in ds.items()}
        log(f"{name}: " + "; ".join(f"{r} {fx.fmt(v['median'])} ({v['rate']:.2f})"
                                    for r, v in win[name].items()))
    res['detection'] = win

    # ---------------- Part 3: Table IX regimes, cloud as endpoint ----------------
    import exp_ablation as ab
    abl = json.load(open('results/ablation_thresholds.json'))
    ta1, tl1 = abl['V1 FogDrift']
    seeds3 = ab.SEEDS if not QUICK else ab.SEEDS[:5]
    variants = {'A, tau_g 10 seeds': lambda s: cloud(s, ta1, tl1, abl['V3 cloud tau_g'])[0],
                f'A, tau_g {len(cal)} seeds': lambda s: cloud(s, ta1, tl1, tgA)[0],
                'B': lambda s: cloud(s, ta1, tl1, np.inf)[1],
                'C': lambda s: cloud(s, ta1, tl1, tgC, 'trimmed')[0]}
    p3 = {}
    for g, kw in ab.REGIMES.items():
        d = {v: [] for v in variants}
        for seed in seeds3:
            o = fc.run_stream(seed, fd_cfg=cfg, base_dets=False, scalars=False,
                              keep_agent=False, pre=60, post=100, **kw)
            for v, f in variants.items():
                d[v].append(delay(f(o['FogDrift']), o['onset']))
        p3[g] = {v: [fx.med(x), int(sum(a is not None for a in x)), len(x)] for v, x in d.items()}
        log(f"V3 {g}: {p3[g]}")
    res['table9_v3'] = p3

    # ---------------- Part 4: why the corroboration branch is silent ----------------
    res['coincidence'] = coincidence(val, ta, tl, faulty=[0])
    log(f"coincidence {res['coincidence']}")
    json.dump(res, open('results/cloud_corroboration.json', 'w'), indent=1, default=float)
    report(res)


def report(res):
    L = []
    P = L.append
    ncal, nval = len(CAL_SEEDS), len(VAL_SEEDS)
    P(f"Cloud tier, Eq. (6): FogDrift tau_a={res['tau_a']:.4f}, tau_l={res['tau_l']:.4f} "
      f"(calibration.json), target ARL0 = {T}, K_p = {KP}, p = {P_CORR}; null streams of "
      f"{ROUNDS} rounds ({BURN}-round burn-in).")
    P(f"(a) tau_g of Eq. (6): held-out = {nval} seeds (the first 10 are those of Table XII). "
      f"ARL [95% Poisson CI] (events); disp. = variance/mean of events per held-out stream.")
    P(f"{'tau_g calibrated on':24s} {'tau_g':>8s} {'cal ARL (ev)':>13s} {'held-out':>24s} "
      f"{'workload drift':>24s} {'Table XII seeds':>15s} {'disp.':>6s} {'corr/avg ev':>12s}")
    for r in res['part1']:
        c, v, w, f = r['cal'], r['val'], r['val_workload'], r['val_first10']
        P(f"{r['calibration']:24s} {r['tau_g']:8.5f} {c['ARL']:7.0f} ({c['events']:3d}) "
          f"{v['ARL']:6.0f} [{v['ARL_lo']:4.0f},{v['ARL_hi']:5.0f}] ({v['events']:3d}) "
          f"{w['ARL']:6.0f} [{w['ARL_lo']:4.0f},{w['ARL_hi']:5.0f}] ({w['events']:3d}) "
          f"{f['ARL']:9.0f} ({f['events']:2d}) {v['dispersion']:6.2f} "
          f"{r['val_corr']['events']:5d}/{r['val_avg']['events']:<5d}")
    for r in res['part1']:
        if r['calibration'] in ('calibrate.py (10 seeds)', f'all {ncal} seeds'):
            P(f"stream-bootstrap 95% CI, tau_g from {r['calibration']}: held-out "
              f"[{r['val_boot'][0]:.0f}, {r['val_boot'][1]:.0f}], Table XII seeds "
              f"[{r['val_first10_boot'][0]:.0f}, {r['val_first10_boot'][1]:.0f}]")
    s = res['structure']
    P(f"null fog scores (calibration streams): mean within-stream correlation between fogs "
      f"{s['cross_fog_corr']:.3f}; between-stream share of the variance of the mean fog score "
      f"{s['between_share']:.3f}")
    P("")
    tg = res['tau_g_used']
    P(f"(b) Long-run false-alarm ARL on the {nval} held-out streams [95% CI] (events). Rules: "
      f"A = Eq. (6) with tau_g={tg['A']:.5f} ({ncal} seeds); B = corroboration branch alone; "
      f"C = corroboration OR mean of the fog scores without the largest, tau_g={tg['C']:.5f} "
      f"calibrated with one faulty fog. Faulty fog: reports a stable alert with score "
      f"{FAB_SCORE} tau_l in every round. Local outage: top-2 tools deprecated (m=0.5) on the "
      f"10 agents of one fog.")
    P("cell = duty cycle (fraction of rounds in alarm) / ARL [95% CI] (events); with a fault "
      "present from the start, an alarm that never clears is one event, so read the duty cycle.")
    P(f"{'condition':24s} " + " ".join(f"{r:>34s}" for r in RULES))
    for k, v in res['long_run'].items():
        P(f"{k:24s} " + " ".join(
            f"{v[r]['duty']:6.4f} / {v[r]['ARL']:6.0f} [{v[r]['ARL_lo']:5.0f},{v[r]['ARL_hi']:6.0f}] "
            f"({v[r]['events']:3d})" for r in RULES))
    for k, v in res['table12_cloud'].items():
        P(f"Table XII, cloud row (rule C, the 10 held-out seeds of Table XII), {k}: "
          f"ARL {v['ARL']:.0f} [{v['ARL_lo']:.0f}, {v['ARL_hi']:.0f}] ({v['events']} events)")
    P(f"corroboration branch alone with one faulty fog on the calibration streams: ARL "
      f"{res['corr_branch_one_faulty_cal']['ARL']:.0f}")
    P("")
    P(f"(c) Detection, {len(RUN_SEEDS)} seeds, onset after {PRE} rounds, window {POST} rounds: "
      f"median delay (detection rate)")
    P(f"{'scenario':32s} " + " ".join(f"{r:>22s}" for r in RULES))
    for k, v in res['detection'].items():
        P(f"{k:32s} " + " ".join(f"{fx.fmt(v[r]['median']):>14s} ({v[r]['rate']:.2f})" for r in RULES))
    P("")
    P("(d) Table IX regimes (seeds 300-329) with a cloud rule as endpoint: median delay "
      "(detected/runs)")
    names = list(next(iter(res['table9_v3'].values())))
    P(f"{'regime':22s} " + " ".join(f"{n:>22s}" for n in names))
    for g, x in res['table9_v3'].items():
        P(f"{g:22s} " + " ".join(f"{fx.fmt(x[n][0]):>14s} ({x[n][1]:2d}/{x[n][2]})" for n in names))
    if 'coincidence' in res:
        c = res['coincidence']
        P("")
        P(f"(e) Corroboration branch on the {nval} held-out null streams ({c['rounds']} rounds), "
          f"needs {c['need']} fogs in stable alert. Per-fog duty cycle: "
          + ", ".join(f"{d:.5f}" for d in c['duty_per_fog']) + "; events per fog: "
          + ", ".join(str(e) for e in c['events_per_fog']) + ".")
        P(f"rounds with >= {c['need']} fogs in stable alert: observed {c['observed_rounds']}, "
          f"expected if fogs alarm independently {c['expected_rounds_independent']:.2f}")
        P(f"one faulty fog (fog 0): corroboration fires on every stable alert of fogs 1-4; "
          f"predicted ARL from their null events {c['predicted_ARL_one_faulty']:.0f} "
          f"(observed in (b), B: corroboration only)")
    txt = "\n".join(L)
    print("\n" + txt)
    open('results/cloud_corroboration.txt', 'w').write(txt + "\n")


if __name__ == '__main__':
    if 'report' in sys.argv[1:]:
        report(json.load(open('results/cloud_corroboration.json')))
    else:
        main()
