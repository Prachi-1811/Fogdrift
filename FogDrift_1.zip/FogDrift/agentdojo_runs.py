"""Convert AgentDojo's published benchmark runs into the trace format of
agentdojo_collect.py (input to exp_agentdojo_replay.py).

The AgentDojo repository (github.com/ethz-spylab/agentdojo, MIT licence)
ships the logs of its benchmark runs under runs/<model>/<suite>/<user_task>/
<attack>/<injection_task>.json, one file per episode, with the full message
history and AgentDojo's own utility and security (attack success) labels.

    git clone --depth 1 --filter=blob:none --sparse \
        https://github.com/ethz-spylab/agentdojo
    cd agentdojo && git sparse-checkout set --no-cone \
        '/runs/gpt-4o-mini-2024-07-18/*/user_task_*/important_instructions/*' \
        '/runs/gpt-4o-mini-2024-07-18/*/user_task_*/none/*'      # etc. per model
    python agentdojo_runs.py path/to/agentdojo/runs gpt-4o-mini-2024-07-18 ...

Kept: benign episodes (attack none) and episodes under the
important_instructions attack, every suite. Tool calls are read from the
assistant messages in order. harm_tools / user_gt_tools are the functions of
the injection / user task's ground truth (AgentDojo package, benchmark
v1.2.2, else v1). Episodes with an error are kept with their error.
Output: data/agentdojo_runs_<model>.jsonl
"""
import glob
import json
import os
import sys
import warnings

warnings.filterwarnings("ignore")
ATTACK = 'important_instructions'


def gt_tools(task, suite):
    try:
        env = suite.load_and_inject_default_environment({})
        if hasattr(task, 'init_environment'):
            env = task.init_environment(env)
        return sorted({c.function for c in task.ground_truth(env)})
    except Exception:
        return []


def main(root, models):
    from agentdojo.task_suite.load_suites import get_suites
    versions = [('v1.2.2', get_suites('v1.2.2')), ('v1', get_suites('v1'))]
    cache = {}

    def gt(suite, kind, tid):
        key = (suite, kind, tid)
        if key not in cache:
            cache[key] = ([], None)
            for ver, S in versions:
                tasks = S[suite].user_tasks if kind == 'user' else S[suite].injection_tasks
                if tid in tasks:
                    cache[key] = (gt_tools(tasks[tid], S[suite]), ver)
                    break
        return cache[key]

    os.makedirs('data', exist_ok=True)
    for model in models:
        files = sorted(glob.glob(os.path.join(root, model, '*', 'user_task_*', ATTACK, '*.json')) +
                       glob.glob(os.path.join(root, model, '*', 'user_task_*', 'none', 'none.json')))
        out = os.path.join('data', f'agentdojo_runs_{model}.jsonl')
        n = 0
        with open(out, 'w') as fh:
            for fn in files:
                d = json.load(open(fn))
                calls, args = [], []
                for m in d.get('messages') or []:
                    if m.get('role') == 'assistant':
                        for c in m.get('tool_calls') or []:
                            calls.append(c['function'])
                            args.append(json.dumps(c.get('args', {}), default=str)[:500])
                inj = d.get('injection_task_id')
                su, ut = d['suite_name'], d['user_task_id']
                ugt, ver = gt(su, 'user', ut)
                rec = {'model': model, 'suite': su, 'user_task': ut, 'injection_task': inj,
                       'attack': d.get('attack_type'), 'rep': 0, 'utility': d.get('utility'),
                       'security': d.get('security') if inj is not None else None,
                       'calls': calls, 'args': args, 'n_calls': len(calls),
                       'harm_tools': gt(su, 'injection', inj)[0] if inj is not None else [],
                       'user_gt_tools': ugt, 'error': d.get('error'),
                       'benchmark_version': ver or 'v1', 'source': 'agentdojo runs/'}
                fh.write(json.dumps(rec) + "\n")
                n += 1
        print(f"{model}: {n} episodes -> {out}", flush=True)


if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2:])
