"""Resource scaling in N, L and M (Sec. V-J).

    python exp_scaling.py          # ~10 min
    python exp_scaling.py quick    # ~2 min (sanity only)

One axis is varied at a time around the default (N=50, L=4, M=12).
K = max(8, 2L) tool calls per agent per round, so every context still
receives observations when L grows. For every configuration the edge
parameters are re-calibrated on null data (same rule as calibrate.py),
because Delta_TV depends on L and M.

Measured per configuration (null stream, 300 rounds after a 60-round burn-in):
  edge message size  bytes of one edge->fog summary (computed from L and M)
  tx rate            fraction of agent-rounds with a transmission
  KB/round sent      all bytes on the edge->fog and fog->cloud links
  ms/round           wall-clock time of one monitor step for the whole fleet
                     (all three tiers in one process; machine dependent)
  state MB           memory held by the monitor (edge windows + fog store)
Power-law exponents b (y ~ x^b) are fitted on log-log axes.
Outputs: results/scaling.txt, results/scaling.png
"""
import os
import sys
import time
from dataclasses import replace
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc

os.makedirs('results', exist_ok=True)

AXES = {'N': [50, 100, 200, 500, 1000], 'L': [4, 8, 16, 32], 'M': [12, 24, 48, 96]}
BURN, MEAS = 60, 300
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    AXES = {'N': [50, 100, 200], 'L': [4, 8, 16], 'M': [12, 24, 48]}
    BURN, MEAS = 40, 100
    print("QUICK MODE")


def state_mb(det):
    arrs = [det.win.buf, det.win.ptr, det.win.fill, det.win.cnt, det.win.ctx_ring,
            det.win.ctx_sum, det.H_last, det.S, det.since, det.fH, det.fn, det.fpi, det.fts]
    return sum(a.nbytes for a in arrs) / 2**20


def measure(N, L, M, seed=0):
    base = replace(fc.DEFAULT, N=N, L=L, M=M, K=max(8, 2 * L))
    cfg, _ = fc.calibrate_edge_params(range(2), base, rounds=200, burn=40)
    rng = np.random.default_rng(seed)
    P = fc.build_P0(rng, cfg)
    pi = np.ones(L) / L
    P0 = fc.estimate_P0(rng, P, pi, cfg)
    det = fc.HCDD(P0, cfg)
    for _ in range(BURN):
        det.step(*fc.gen_round(rng, P, pi, cfg))
    s0, tx0 = det.sent, det.tx_agent_rounds
    rounds = [fc.gen_round(rng, P, pi, cfg) for _ in range(MEAS)]
    t = time.perf_counter()
    for cs, ts in rounds:
        det.step(cs, ts)
    ms = (time.perf_counter() - t) * 1000 / MEAS
    return {'msg_B': fc.edge_msg_bytes(cfg), 'tx': (det.tx_agent_rounds - tx0) / (MEAS * N),
            'kb': (det.sent - s0) / MEAS / 1024, 'ms': ms, 'mb': state_mb(det),
            'DTV': cfg.DTV}


def fit(x, y):
    b, a = np.polyfit(np.log(x), np.log(np.maximum(y, 1e-12)), 1)
    return b


def main():
    t0 = time.time()
    res = {}
    for ax, vals in AXES.items():
        for v in vals:
            N, L, M = 50, 4, 12
            N, L, M = (v, L, M) if ax == 'N' else (N, v, M) if ax == 'L' else (N, L, v)
            res[(ax, v)] = measure(N, L, M)
            r = res[(ax, v)]
            print(f"[{(time.time()-t0)/60:4.1f} min] {ax}={v}: msg={r['msg_B']}B tx={r['tx']:.2f} "
                  f"kb={r['kb']:.2f} ms={r['ms']:.1f} mb={r['mb']:.2f} DTV={r['DTV']:.3f}",
                  flush=True)
    L_ = ["FogDrift resource scaling (Sec. V-J), one axis varied at a time "
          "(default N=50, L=4, M=12, K=max(8,2L)); null stream; edge parameters "
          "re-calibrated per configuration",
          f"{'axis':>4s} {'value':>6s} {'msg (B)':>8s} {'tx rate':>8s} {'KB/rnd':>8s} "
          f"{'ms/rnd':>8s} {'state MB':>9s} {'Delta_TV':>9s}"]
    for (ax, v), r in res.items():
        L_.append(f"{ax:>4s} {v:6d} {r['msg_B']:8d} {r['tx']:8.2f} {r['kb']:8.2f} "
                  f"{r['ms']:8.1f} {r['mb']:9.2f} {r['DTV']:9.3f}")
    L_.append("")
    L_.append("power-law exponents b (y ~ x^b):")
    for ax, vals in AXES.items():
        parts = []
        for key, lab in [('kb', 'KB/rnd'), ('ms', 'ms/rnd'), ('mb', 'state MB')]:
            parts.append(f"{lab} b={fit(vals, [res[(ax, v)][key] for v in vals]):+.2f}")
        L_.append(f"  {ax}: " + ", ".join(parts))
    txt = "\n".join(L_)
    print("\n" + txt)
    open('results/scaling.txt', 'w').write(txt + "\n")

    draw(res)
    print(f"\nSaved results/scaling.txt, scaling.png [{(time.time()-t0)/60:.1f} min]")


def draw(res):
    plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})
    fig, axs = plt.subplots(1, 3, figsize=(14, 4.2))
    for a, (ax, vals) in zip(axs, AXES.items()):
        for key, lab, mk in [('kb', 'KB sent / round', 's'), ('ms', 'ms / round', 'o'),
                             ('mb', 'monitor state (MB)', '^')]:
            a.loglog(vals, [res[(ax, v)][key] for v in vals], marker=mk, label=lab)
        from matplotlib.ticker import NullFormatter
        a.set_xlabel(f'${ax}$'); a.set_xticks(vals); a.set_xticklabels([str(v) for v in vals])
        a.xaxis.set_minor_formatter(NullFormatter())
        a.grid(True, which='both', alpha=.3, ls='--')
    axs[0].legend(fontsize=8)
    plt.tight_layout(); plt.savefig('results/scaling.png', dpi=200)


if __name__ == '__main__':
    main()
