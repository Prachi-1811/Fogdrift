"""fogdrift_core.py -- simulator, FogDrift (HCDD) and baseline detectors.

Every experiment script imports this module, so all results share one data
generator, one set of detectors, one detection endpoint and one byte model.

Contents
--------
* Config                 fleet and detector parameters (paper Table III).
* gen_round, estimate_P0 the event generator and the warm-up reference
                         estimator used by every detector, so all detectors
                         see exactly the same events for a given seed.
* drifted                the three drift scenarios of Sec. IV (policy
                         poisoning, prompt perturbation, tool deprecation).
* HCDD                   FogDrift (Alg. 1): event trigger (Delta_TV),
                         Page-Hinkley tracker (Eq. 5), heartbeat (T_hb),
                         freshness (T_fresh), per-agent scores, sample-weighted
                         fog aggregation (Eq. 3), fog alert (Eq. 4) with K_p
                         persistence and the cloud rule (Eq. 6). Flags switch
                         off individual components for the ablations.
* CentralTuples          Centralised-Tuples with batch size B; the cloud
                         rebuilds its windows only from tuples that arrived.
                         Optional acknowledgement and retransmission (CT+ACK).
* MMD, CUSUM, ADWIN, Page-Hinkley, DDM
                         two-sample and sequential baselines on the same stream.
* calibrate_edge_params  null-data estimate of Delta_TV, Delta_0, Delta_cum.
* endpoint_fog, detection_delay, count_events
                         the shared alarm endpoint and delay convention:
                         delay = r_alert - r_onset + 1 (minimum K_p).

Bandwidth is recorded twice: bytes SENT (every attempt, including lost
messages, retransmissions and ACKs) and bytes DELIVERED. When a link fails the
edge still updates its own window; only the message is lost. Edges send
uncapped context counts (last W_pi rounds) next to the capped histogram counts.
Message sizes are computed from L and M (float32 histogram, uint16 counts).
"""
from dataclasses import dataclass, replace
import numpy as np


# --------------------------------------------------------------------------
# Configuration (paper Table III)
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Config:
    N: int = 50          # agents
    F: int = 5           # fog nodes
    L: int = 4           # contexts
    M: int = 12          # tools
    K: int = 8           # tool calls per agent per round
    W: int = 20          # edge window, observations PER CONTEXT
    W_PI: int = 20       # rounds used for the uncapped context-mixture counts
    W0: int = 50         # warm-up rounds used to estimate P0
    NMIN_AGENT: int = 10
    NMIN_FOG: int = 30
    DTV: float = 0.015   # event-trigger threshold Delta_TV (hand-set default;
                         # calibrated values are read from edge_params.json)
    D0: float = 0.005    # tracker slack Delta_0
    DCUM: float = 0.10   # tracker bound Delta_cum
    THB: int = 10        # heartbeat (rounds)
    TFRESH: int = 15     # freshness limit (rounds)
    KP: int = 2          # persistence
    P_CORR: float = 0.30 # cloud corroboration ratio p
    TOPK: int = 5
    MIN_COV: float = 1.0 # fog aggregate used only if this fraction of members is fresh (tau_l is calibrated at full coverage)
    CTX_W: str = 'equal' # 'equal' (finite-sample workload invariant) | 'mixture' (pi-weighted)

    @property
    def alpha(self):
        return 1.0 / self.M


DEFAULT = Config()

# Byte model (Sec. III-G2)
HEADER_B = 40      # transport framing (TCP + IPv4, no options), once per message
ACK_B = 20         # acknowledgement
FLOAT_B = 4        # float32
U16_B = 2          # uint16
TUPLE_B = 5        # varint (agent, context, tool, seq) tuple
RAW_TRACE_B = 60   # raw trace record per tool call (no per-message header)


def edge_msg_bytes(cfg):
    """Edge->fog summary: L*M float32 histogram + L capped counts +
    L uncapped context counts (uint16) + seq (4 B) + reference version (2 B)."""
    return HEADER_B + cfg.L * cfg.M * FLOAT_B + 2 * cfg.L * U16_B + 4 + 2


def fog_msg_bytes(cfg, k):
    """Fog->cloud: score (4) + stable-alert flag (1) + coverage (2) +
    k (agent id uint16 + score float32)."""
    return HEADER_B + 4 + 1 + 2 + k * (U16_B + FLOAT_B)


# --------------------------------------------------------------------------
# Data generation
# --------------------------------------------------------------------------
def build_P0(rng, cfg=DEFAULT):
    """True reference: per context 3 primary tools U[0.15,0.30] and
    M-3 background tools U[0.005,0.04], normalised."""
    P0 = np.zeros((cfg.L, cfg.M))
    for c in range(cfg.L):
        primary = rng.choice(cfg.M, 3, replace=False)
        bg = np.setdiff1d(np.arange(cfg.M), primary)
        P0[c, primary] = rng.uniform(0.15, 0.30, 3)
        P0[c, bg] = rng.uniform(0.005, 0.04, len(bg))
        P0[c] /= P0[c].sum()
    return P0


def gen_round(rng, P, pi_c, cfg=DEFAULT):
    """One round. P is (L,M) shared or (N,L,M) per agent.
    Returns contexts cs (N,K) and tools ts (N,K)."""
    cs = rng.choice(cfg.L, size=(cfg.N, cfg.K), p=pi_c)
    Pa = np.broadcast_to(P, (cfg.N, cfg.L, cfg.M)) if P.ndim == 2 else P
    cdf = np.cumsum(Pa, axis=-1)
    rows = cdf[np.arange(cfg.N)[:, None], cs]          # (N,K,M)
    u = rng.random((cfg.N, cfg.K))[..., None]
    ts = np.minimum((u > rows).sum(-1), cfg.M - 1)
    return cs, ts


def estimate_P0(rng, P_true, pi_c, cfg=DEFAULT, P_poison=None, alpha_poison=0.0):
    """Reference estimated from W0 warm-up rounds of pooled fleet events
    (Laplace-smoothed). If P_poison is given, each warm-up round is drawn from
    P_poison with probability alpha_poison (K2 reference poisoning)."""
    cnt = np.zeros((cfg.L, cfg.M))
    for _ in range(cfg.W0):
        P = P_poison if (P_poison is not None and rng.random() < alpha_poison) else P_true
        cs, ts = gen_round(rng, P, pi_c, cfg)
        np.add.at(cnt, (cs.ravel(), ts.ravel()), 1)
    return (cnt + cfg.alpha) / (cnt.sum(1, keepdims=True) + cfg.M * cfg.alpha)


# Drift scenarios (paper Sec. IV)
def policy_poison(P0, m=0.5, susp=6):
    Pd = (1 - m) * P0.copy()
    Pd[:, susp] += m
    return Pd / Pd.sum(1, keepdims=True)


def prompt_perturb(P0, m=0.5, seed=42):
    r = np.random.default_rng(seed)
    Pd = np.array([(1 - m) * P0[c] + m * r.dirichlet(np.full(P0.shape[1], 0.5))
                   for c in range(P0.shape[0])])
    return Pd / Pd.sum(1, keepdims=True)


def tool_deprec(P0, m=0.5):
    Pd = P0.copy()
    for c in range(P0.shape[0]):
        top2 = np.argsort(P0[c])[-2:]
        rem = P0[c, top2] * min(m * 1.6, 0.95)
        Pd[c, top2] -= rem
        other = np.setdiff1d(np.arange(P0.shape[1]), top2)
        Pd[c, other] += rem.sum() / len(other)
    Pd = np.maximum(Pd, 1e-10)
    return Pd / Pd.sum(1, keepdims=True)


def drifted(P0, scenario, m, seed):
    if scenario == 'policy':
        return policy_poison(P0, m)
    if scenario == 'prompt':
        return prompt_perturb(P0, m, seed + 1000)
    if scenario == 'deprec':
        return tool_deprec(P0, m)
    raise ValueError(scenario)


# --------------------------------------------------------------------------
# Statistics
# --------------------------------------------------------------------------
def smooth(cnt, cfg):
    return (cnt + cfg.alpha) / (cnt.sum(-1, keepdims=True) + cfg.M * cfg.alpha)


def cond_kl(H, P0, n_c, pi_w, nmin, off=None):
    """Eq. (1) on finite samples. H (...,L,M); n_c capped counts (...,L) used
    only for the minimum-sample rule; pi_w mixture weights (...,L).
    off (...,L), optional: subtracted from each context term (sample-size
    bias offset, zero at full windows; see exp_window_fill.py)."""
    kl = np.sum(H * np.log(H / P0), axis=-1)
    if off is not None:
        kl = kl - off
    w = pi_w * (n_c >= nmin)
    tot = w.sum(-1)
    return np.where(tot > 0, (w * kl).sum(-1) / np.maximum(tot, 1e-12), 0.0)


def weighted_tv(H1, H2, n_c):
    tv = 0.5 * np.abs(H1 - H2).sum(-1)              # (...,L)
    tot = n_c.sum(-1)
    return np.where(tot > 0, (n_c * tv).sum(-1) / np.maximum(tot, 1e-12), 0.0)


class Windows:
    """Per-agent, per-context ring buffers of the last W tools (capped counts)
    plus uncapped per-context counts over the last W_PI rounds."""
    def __init__(self, cfg):
        self.cfg = cfg
        N, L, M, W = cfg.N, cfg.L, cfg.M, cfg.W
        self.buf = np.zeros((N, L, W), dtype=np.int16)
        self.ptr = np.zeros((N, L), dtype=np.int64)
        self.fill = np.zeros((N, L), dtype=np.int64)
        self.cnt = np.zeros((N, L, M))
        self.ctx_ring = np.zeros((cfg.W_PI, N, L))
        self.ctx_sum = np.zeros((N, L))
        self.r = 0

    def _add_column(self, idx, c, t):
        p = self.ptr[idx, c]
        full = self.fill[idx, c] >= self.cfg.W
        old = self.buf[idx, c, p]
        np.subtract.at(self.cnt, (idx[full], c[full], old[full]), 1)
        self.buf[idx, c, p] = t
        np.add.at(self.cnt, (idx, c, t), 1)
        self.ptr[idx, c] = (p + 1) % self.cfg.W
        self.fill[idx, c] = np.minimum(self.fill[idx, c] + 1, self.cfg.W)

    def add_round(self, cs, ts):
        """All N agents, K events each (one column = one event per agent)."""
        idx = np.arange(self.cfg.N)
        for k in range(cs.shape[1]):
            self._add_column(idx, cs[:, k], ts[:, k])
        self._roll_ctx(cs, np.ones_like(cs, dtype=bool))

    def add_events(self, agent_events):
        """agent_events: list of (cs_i, ts_i) arrays per agent (variable length),
        used when only some tuples arrive (Centralised-Tuples)."""
        lens = np.array([len(e[0]) for e in agent_events])
        ctx_round = np.zeros((self.cfg.N, self.cfg.L))
        for j in range(lens.max(initial=0)):
            idx = np.where(lens > j)[0]
            c = np.array([agent_events[i][0][j] for i in idx])
            t = np.array([agent_events[i][1][j] for i in idx])
            self._add_column(idx, c, t)
            np.add.at(ctx_round, (idx, c), 1)
        self._roll_ctx_counts(ctx_round)

    def _roll_ctx(self, cs, mask):
        ctx_round = np.zeros((self.cfg.N, self.cfg.L))
        rows = np.repeat(np.arange(self.cfg.N), cs.shape[1])
        np.add.at(ctx_round, (rows, cs.ravel()), mask.ravel())
        self._roll_ctx_counts(ctx_round)

    def _roll_ctx_counts(self, ctx_round):
        slot = self.r % self.cfg.W_PI
        self.ctx_sum += ctx_round - self.ctx_ring[slot]
        self.ctx_ring[slot] = ctx_round
        self.r += 1


def ctx_weights(pi_c, cfg):
    """Context weights for the finite-sample score.
    'equal'  : every eligible context counts the same; the null distribution of
               the score then does not depend on the context mixture (all
               capped windows hold W observations), i.e. finite-sample
               workload invariance.
    'mixture': weights = uncapped context counts (pi-weighted Eq. 1)."""
    return np.ones_like(pi_c) if cfg.CTX_W == 'equal' else pi_c


def fog_signals(H, n_c, pi_c, has, fog_of, P0, cfg, offsets=None):
    """Fog tier for every fog: per-agent scores, Eq. (3) aggregate and its score.
    H (N,L,M) stored summaries, n_c capped counts, pi_c uncapped context counts,
    has (N,) bool = fresh summary available. offsets: optional pair of
    functions (agent, fog) mapping per-context counts to bias offsets."""
    agent = cond_kl(H, P0, n_c, ctx_weights(pi_c, cfg), cfg.NMIN_AGENT,
                    None if offsets is None else offsets[0](n_c))
    agent = np.where(has, agent, 0.0)
    fog_score = np.zeros(cfg.F)
    fog_amax = np.zeros(cfg.F)
    fog_has = np.zeros(cfg.F, dtype=bool)
    for f in range(cfg.F):
        members = fog_of == f
        mem = members & has
        if not mem.any():
            continue
        fog_has[f] = True
        fog_amax[f] = agent[mem].max()
        # Coverage rule: tau_l is calibrated with every member fresh. With few
        # fresh members the plug-in KL bias is larger, so the aggregate would
        # alarm on sample size alone (observed during outages). Below MIN_COV
        # coverage the aggregate branch stays silent; the agent branch is kept.
        if mem.sum() < cfg.MIN_COV * members.sum():
            continue
        w = n_c[mem][..., None]                                   # (n,L,1)
        tot = n_c[mem].sum(0)                                     # (L,)
        Hf = np.where(tot[:, None] > 0,
                      (w * H[mem]).sum(0) / np.maximum(tot[:, None], 1e-12),
                      P0)                                         # Eq. (3)
        pif = pi_c[mem].sum(0)                                    # uncapped mixture
        fog_score[f] = cond_kl(Hf, P0, tot, ctx_weights(pif, cfg), cfg.NMIN_FOG,
                               None if offsets is None else offsets[1](tot))
    return agent, fog_score, fog_amax, fog_has


# --------------------------------------------------------------------------
# Detectors that produce fog-level signals (same statistics, different transport)
# --------------------------------------------------------------------------
class HCDD:
    """FogDrift (Alg. 1). Flags allow the ablations of Table IX:
    trigger=False  -> report every round (V4 / Centralised-Histogram transport)
    tracker=False  -> no Page-Hinkley tracker (V5)
    heartbeat=False-> no heartbeat
    ack=True       -> edge retries a summary until a 20 B ACK arrives
    payload='hist' -> summary messages; payload='raw' -> raw traces (60 B/call),
                      i.e. the Centralised-KL transport with identical statistics.
    """
    def __init__(self, P0, cfg=DEFAULT, trigger=True, tracker=True,
                 heartbeat=True, ack=True, payload='hist', name='FogDrift',
                 offsets=None, reset='all'):
        # reset='all': the tracker restarts after every delivered summary
        # (Alg. 1, line 10); reset='event': only after summaries sent because
        # TV > Delta_TV or S > Delta_cum, so it keeps accumulating across
        # heartbeats (see exp_tracker_reset.py).
        self.P0, self.cfg, self.name = P0, cfg, name
        self.offsets = offsets
        self.reset = reset
        self.trigger, self.tracker, self.heartbeat = trigger, tracker, heartbeat
        self.ack, self.payload = ack, payload
        N = cfg.N
        self.win = Windows(cfg)
        self.fog_of = np.arange(N) % cfg.F
        self.H_last = np.broadcast_to(P0, (N, cfg.L, cfg.M)).copy()
        self.S = np.zeros(N)
        self.since = np.zeros(N, dtype=np.int64)
        self.retry = np.zeros(N, dtype=bool)
        # fog store
        self.fH = np.broadcast_to(P0, (N, cfg.L, cfg.M)).copy()
        self.fn = np.zeros((N, cfg.L))
        self.fpi = np.zeros((N, cfg.L))
        self.fts = np.full(N, -10**9)
        self.r = 0
        self.sent = 0
        self.delivered = 0
        self.tx_agent_rounds = 0
        self.tx_cause = {'tv': 0, 'cum': 0, 'hb': 0}   # first matching cause

    def step(self, cs, ts, link_up=None):
        cfg = self.cfg
        if link_up is None:
            link_up = np.ones(cfg.N, dtype=bool)
        self.r += 1
        self.win.add_round(cs, ts)                    # edge always sees its own calls
        H = smooth(self.win.cnt, cfg)
        n = self.win.cnt.sum(-1)
        self.since += 1
        if self.tracker:
            tv_ref = weighted_tv(H, self.P0[None], n)
            self.S = np.maximum(0.0, self.S + tv_ref - cfg.D0)
        if self.trigger:
            by_tv = weighted_tv(H, self.H_last, n) > cfg.DTV
            by_cum = (self.S > cfg.DCUM) if self.tracker else np.zeros(cfg.N, bool)
            by_hb = (self.since >= cfg.THB) if self.heartbeat else np.zeros(cfg.N, bool)
            want = by_tv | by_cum | by_hb
            self.tx_cause['tv'] += int(by_tv.sum())
            self.tx_cause['cum'] += int((by_cum & ~by_tv).sum())
            self.tx_cause['hb'] += int((by_hb & ~by_tv & ~by_cum).sum())
            stat = by_tv | by_cum
        else:
            want = np.ones(cfg.N, dtype=bool)
            stat = want
        attempt = want | self.retry
        ok = attempt & link_up
        if self.payload == 'raw':
            msg = cs.shape[1] * RAW_TRACE_B
        else:
            msg = edge_msg_bytes(cfg)
        self.sent += attempt.sum() * msg
        self.delivered += ok.sum() * msg
        self.tx_agent_rounds += attempt.sum()
        if self.ack:
            self.sent += ok.sum() * ACK_B
            self.delivered += ok.sum() * ACK_B
            updated = ok                               # edge knows what arrived
            self.retry = attempt & ~ok
        else:
            updated = attempt                          # fire-and-forget
        self.H_last[updated] = H[updated]
        self.S[updated & stat if self.reset == 'event' else updated] = 0.0
        self.since[updated] = 0
        # fog receives
        self.fH[ok] = H[ok]
        self.fn[ok] = n[ok]
        self.fpi[ok] = self.win.ctx_sum[ok]
        self.fts[ok] = self.r
        has = (self.r - self.fts) <= cfg.TFRESH
        agent, fs, fa, fh = fog_signals(self.fH, self.fn, self.fpi, has,
                                        self.fog_of, self.P0, cfg, self.offsets)
        f2c = fog_msg_bytes(cfg, cfg.TOPK) * fh.sum()
        self.sent += f2c
        self.delivered += f2c
        return {'fog_score': fs, 'fog_amax': fa, 'fog_has': fh, 'agent': agent,
                'n_tx': int(attempt.sum()), 'sent': self.sent,
                'deliv': self.delivered}


def last_per_context(pc, pt, W):
    """Keep, in order, only the W most recent tuples of each context."""
    seen, keep = {}, []
    for j in range(len(pc) - 1, -1, -1):
        c = pc[j]
        if seen.get(c, 0) < W:
            seen[c] = seen.get(c, 0) + 1
            keep.append(j)
    keep.reverse()
    return [pc[j] for j in keep], [pt[j] for j in keep]


class CentralTuples:
    """Centralised-Tuples: every agent ships its (c,t) tuples every B rounds.
    The cloud rebuilds windows ONLY from tuples that arrived, then computes the
    same per-agent / per-fog statistics as HCDD. ack=True buffers undelivered
    tuples (cap `buffer_cap`) and retransmits them at the next batch.
    buffer='ring' keeps only the W most recent unsent tuples of each context
    (older ones would leave the cloud's window anyway), so the buffer holds at
    most L*W tuples.
    phase shifts the batch boundaries by that many rounds (0: a batch closes
    in the round before onset when onset is a multiple of B)."""
    def __init__(self, P0, cfg=DEFAULT, B=5, ack=False, buffer_cap=5000,
                 name=None, phase=0, buffer='fifo'):
        self.P0, self.cfg, self.B, self.ack, self.cap = P0, cfg, B, ack, buffer_cap
        self.ring = buffer == 'ring'
        self.name = name or f"CT(B={B}{',ACK' if ack else ''})"
        self.win = Windows(cfg)
        self.fog_of = np.arange(cfg.N) % cfg.F
        self.pending = [([], []) for _ in range(cfg.N)]
        self.r = phase
        self.sent = 0
        self.delivered = 0
        self.tx_agent_rounds = 0

    def step(self, cs, ts, link_up=None):
        cfg = self.cfg
        if link_up is None:
            link_up = np.ones(cfg.N, dtype=bool)
        self.r += 1
        for i in range(cfg.N):
            self.pending[i][0].extend(cs[i].tolist())
            self.pending[i][1].extend(ts[i].tolist())
            if self.ring:
                self.pending[i] = last_per_context(*self.pending[i], cfg.W)
        arrived = [(np.array([], int), np.array([], int))] * cfg.N
        if self.r % self.B == 0:
            arrived = []
            for i in range(cfg.N):
                pc, pt = self.pending[i]
                nbytes = HEADER_B + TUPLE_B * len(pc)
                self.sent += nbytes
                self.tx_agent_rounds += 1
                if link_up[i]:
                    self.delivered += nbytes
                    arrived.append((np.array(pc, int), np.array(pt, int)))
                    if self.ack:
                        self.sent += ACK_B
                        self.delivered += ACK_B
                    self.pending[i] = ([], [])
                else:
                    arrived.append((np.array([], int), np.array([], int)))
                    if self.ack:                     # keep for retransmission
                        self.pending[i] = (pc[-self.cap:], pt[-self.cap:])
                    else:
                        self.pending[i] = ([], [])
        if any(len(a[0]) for a in arrived):
            self.win.add_events(arrived)
        else:
            self.win._roll_ctx_counts(np.zeros((cfg.N, cfg.L)))
        H = smooth(self.win.cnt, cfg)
        n = self.win.cnt.sum(-1)
        has = n.sum(-1) > 0
        agent, fs, fa, fh = fog_signals(H, n, self.win.ctx_sum, has,
                                        self.fog_of, self.P0, cfg)
        return {'fog_score': fs, 'fog_amax': fa, 'fog_has': fh, 'agent': agent,
                'n_tx': int(self.r % self.B == 0) * cfg.N, 'sent': self.sent,
                'deliv': self.delivered}


# --------------------------------------------------------------------------
# Scalar-stream detectors (one score per round, fleet level, raw-trace transport)
# --------------------------------------------------------------------------
class FleetPool:
    """Raw-trace pooled fleet view shared by the scalar baselines: last W
    observations per (agent, context), pooled over the fleet."""
    def __init__(self, P0, cfg=DEFAULT):
        self.P0, self.cfg = P0, cfg
        self.win = Windows(cfg)
        self.sent = 0

    def step(self, cs, ts):
        self.win.add_round(cs, ts)
        self.sent += cs.size * RAW_TRACE_B
        cnt = self.win.cnt.sum(0)                     # (L,M)
        pi = self.win.ctx_sum.sum(0)                  # (L,)
        return cnt, pi


def fleet_cond_kl(cnt, pi, P0, cfg):
    return float(cond_kl(smooth(cnt, cfg), P0, cnt.sum(-1), ctx_weights(pi, cfg),
                         cfg.NMIN_FOG))


def mmd_joint(cnt, pi_ref, P0):
    """Delta-kernel MMD^2 on the joint (c,t) distribution against the warm-up
    joint pi_ref x P0. Sensitive to workload (context-mixture) shifts."""
    emp = cnt / max(cnt.sum(), 1)
    ref = pi_ref[:, None] * P0
    return float(np.sum((emp - ref) ** 2))


def mmd_conditional(cnt, pi, P0):
    """Context-stratified delta-kernel MMD^2: sum_c pi_c ||H_c - P0_c||^2.
    Workload-invariant at the population level, like Eq. (1)."""
    nc = cnt.sum(-1)
    H = cnt / np.maximum(nc[:, None], 1)
    w = pi / max(pi.sum(), 1e-12)
    return float(np.sum(w * np.sum((H - P0) ** 2, -1)))


class MultinomialCUSUM:
    """Per-context CUSUM on per-round fleet counts:
        S_c <- max(0, S_c + n_c KL(p_c || P0_c) - nu_c),
    where nu_c is the mean null increment estimated from warm-up rounds plus a
    slack of k = 1 standard deviation (a data-driven reference value; with
    k = 0.5 the 50-round estimate of nu was too noisy and one seed in ten
    drifted upward under the null). Without
    nu_c the increment is always >= 0 and S grows forever under the null,
    so the statistic could not be calibrated."""
    def __init__(self, P0, cfg=DEFAULT, k_sd=1.0):
        self.P0, self.cfg, self.k_sd = P0, cfg, k_sd
        self.warm = []
        self.nu = None
        self.S = np.zeros(cfg.L)

    def _inc(self, cs, ts):
        cnt = np.zeros((self.cfg.L, self.cfg.M))
        np.add.at(cnt, (cs.ravel(), ts.ravel()), 1)
        n = cnt.sum(-1)
        p = smooth(cnt, self.cfg)
        return n * np.sum(p * np.log(p / self.P0), -1)

    def warmup(self, cs, ts):
        self.warm.append(self._inc(cs, ts))

    def step(self, cs, ts):
        if self.nu is None:
            w = np.array(self.warm)
            self.nu = w.mean(0) + self.k_sd * w.std(0)
        self.S = np.maximum(0.0, self.S + self._inc(cs, ts) - self.nu)
        return float(self.S.max())


class ADWINScalar:
    """Half-window mean difference (as in the paper's ADWIN baseline)."""
    def __init__(self, win=50):
        self.win, self.h = win, []

    def update(self, x):
        self.h.append(x)
        if len(self.h) < self.win:
            return 0.0
        half = self.win // 2
        return abs(np.mean(self.h[-half:]) - np.mean(self.h[-self.win:-half]))


class PageHinkley:
    """Standard Page-Hinkley test for an increase in the mean:
    m_T = sum_t (x_t - mean_t - delta),  PH_T = m_T - min_{t<=T} m_t.
    (Returning max(0, m_T) instead would drift to -inf under the null and
    never alarm.)"""
    def __init__(self, delta=5e-4):
        self.mean, self.n, self.m, self.mmin, self.delta = 0.0, 0, 0.0, 0.0, delta

    def update(self, x):
        self.n += 1
        self.mean += (x - self.mean) / self.n
        self.m += x - self.mean - self.delta
        self.mmin = min(self.mmin, self.m)
        return self.m - self.mmin


class DDMBinary:
    """DDM on x > q95(warm-up). Returns (p + s) - (p_min + s_min) >= 0; the
    classical warning / drift levels correspond to thresholds 1*s_min / 2*s_min,
    here the threshold is calibrated to the matched ARL0 instead. (The
    statistic p + s - p_min - 2 s_min is clipped at 0 almost always under the
    null, so it cannot be calibrated.) The warm-up quantile is taken on
    single-round scores, which are about 8x the pooled-window scores it is
    applied to; exp_scalar_parity.py tests other mappings."""
    def __init__(self):
        self.warm, self.q, self.n, self.ones = [], None, 0, 0
        self.pmin, self.smin = np.inf, np.inf

    def warmup(self, x):
        self.warm.append(x)

    def update(self, x):
        if self.q is None:
            self.q = float(np.quantile(self.warm, 0.95)) if self.warm else 0.0
        self.n += 1
        self.ones += x > self.q
        p = self.ones / self.n
        s = np.sqrt(p * (1 - p) / self.n)
        if p + s < self.pmin + self.smin:
            self.pmin, self.smin = p, s
        return max(0.0, (p + s) - (self.pmin + self.smin))


# --------------------------------------------------------------------------
# Edge-parameter calibration (Delta_TV, Delta_0, Delta_cum) from null data
# --------------------------------------------------------------------------
def calibrate_edge_params(seeds, cfg=DEFAULT, rounds=400, burn=30,
                          q_tv=0.99, k_sd=1.0, q_cum=0.99):
    """Data-driven edge parameters, measured on null (benign) streams.

    With hand-set values (Delta_TV=0.015, Delta_0=0.005) the trigger and the
    tracker fire in every round, because one round of sampling noise in a
    20-observation histogram already moves TV by ~0.06, and the null TV to the
    reference is ~0.23. This routine sets:
      Delta_TV  = q_tv quantile of TV(H_n, H_last) under the null at lag
                  T_hb-1 (so that, without drift, essentially only heartbeats
                  transmit);
      Delta_0   = mean + k_sd * sd of the null TV(H_n, P0) (negative tracker
                  drift under the null);
      Delta_cum = q_cum quantile of the null tracker statistic.
    Returns (new Config, diagnostics dict).
    """
    tv_lag, tv_ref = [], []
    for seed in seeds:
        rng = np.random.default_rng(10_000 + seed)
        P = build_P0(rng, cfg)
        pi = np.ones(cfg.L) / cfg.L
        P0 = estimate_P0(rng, P, pi, cfg)
        w = Windows(cfg)
        H_last = None
        lag = 0
        for r in range(rounds):
            cs, ts = gen_round(rng, P, pi, cfg)
            w.add_round(cs, ts)
            H = smooth(w.cnt, cfg)
            n = w.cnt.sum(-1)
            if r < burn:
                H_last = H.copy()
                continue
            lag += 1
            if lag == cfg.THB - 1:
                tv_lag.append(weighted_tv(H, H_last, n))
            if lag >= cfg.THB:
                H_last, lag = H.copy(), 0
            tv_ref.append(weighted_tv(H, P0[None], n))
    tv_lag = np.concatenate(tv_lag)
    tv_ref = np.concatenate(tv_ref)
    dtv = float(np.quantile(tv_lag, q_tv))
    d0 = float(tv_ref.mean() + k_sd * tv_ref.std())
    # tracker statistic under the null with this slack
    S = np.zeros(cfg.N)
    path = []
    for x in tv_ref.reshape(-1, cfg.N):
        S = np.maximum(0.0, S + x - d0)
        path.append(S.copy())
    dcum = float(max(np.quantile(np.concatenate(path), q_cum), 1e-3))
    diag = {'tv_lag_mean': float(tv_lag.mean()), 'tv_ref_mean': float(tv_ref.mean()),
            'tv_ref_sd': float(tv_ref.std()), 'DTV': dtv, 'D0': d0, 'DCUM': dcum}
    return replace(cfg, DTV=dtv, D0=d0, DCUM=dcum), diag


# --------------------------------------------------------------------------
# One run: every detector on the SAME event stream
# --------------------------------------------------------------------------
def run_stream(seed, cfg=DEFAULT, scenario=None, m=0.5, q=None, pre=60,
               post=100, pi_c=None, pi_schedule=None, drop=0.0, burst=None,
               tuple_batches=(1, 5, 10), dtv=None, extra=None, fd_cfg=None,
               keep_agent=True, attack=None, warm_poison=0.0, scalars=True,
               base_dets=True):
    """Simulate warm-up (W0, estimates P0), `pre` null-monitoring rounds and
    `post` drift rounds (post may be 0 for a null run).

    scenario : None (null) | 'policy' | 'prompt' | 'deprec'
    q        : number of compromised agents (None = all)
    drop     : per-agent per-round link-failure probability during monitoring
    burst    : (start, end) rounds relative to onset with every link down
    dtv      : override Delta_TV
    fd_cfg   : Config with null-calibrated edge parameters. If given,
               'FogDrift' uses it, 'FogDrift-fixedTV' keeps the hand-set
               values (Delta_TV=0.015, Delta_0=0.005) and 'FogDrift-mixw'
               uses pi-weighted contexts; both are ablations.
    attack   : optional f(r_rel, P_true, Pd) -> P used in drift round r_rel
               (time-varying adaptive attacks); default = Pd every round.
    warm_poison: fraction of warm-up rounds drawn from Pd (K2 reference
               poisoning); P0 is then estimated from the poisoned warm-up.
    scalars  : False skips the raw-trace scalar baselines (faster).
    base_dets: False keeps only FogDrift + `extra` detectors (faster).
    Returns signals per detector (arrays over rounds), bytes, onset index.
    """
    if dtv is not None:
        cfg = replace(cfg, DTV=dtv)
    rng = np.random.default_rng(seed)
    link_rng = np.random.default_rng(seed + 50_000)
    P_true = build_P0(rng, cfg)
    pi0 = np.ones(cfg.L) / cfg.L if pi_c is None else pi_c
    if warm_poison > 0 and scenario is not None:
        P0 = estimate_P0(rng, P_true, pi0, cfg,
                         P_poison=drifted(P_true, scenario, m, seed),
                         alpha_poison=warm_poison)
    else:
        P0 = estimate_P0(rng, P_true, pi0, cfg)

    dets = {}
    if fd_cfg is not None:
        dets['FogDrift'] = HCDD(P0, fd_cfg, name='FogDrift')
        dets['FogDrift-fixedTV'] = HCDD(P0, cfg, name='FogDrift-fixedTV')
        dets['FogDrift-mixw'] = HCDD(P0, replace(fd_cfg, CTX_W='mixture'),
                                     name='FogDrift-mixw')
    else:
        dets['FogDrift'] = HCDD(P0, cfg, name='FogDrift')
    if base_dets:
        dets.update({
            'Cent-Hist': HCDD(P0, cfg, trigger=False, name='Cent-Hist'),
            'Cent-KL': HCDD(P0, cfg, trigger=False, ack=False, payload='raw',
                            name='Cent-KL'),
        })
        for B in tuple_batches:
            dets[f'CT(B={B})'] = CentralTuples(P0, cfg, B=B)
    else:
        dets = {'FogDrift': dets['FogDrift']}
    if extra:
        for name, factory in extra.items():
            dets[name] = factory(P0, cfg)
    pool = FleetPool(P0, cfg)
    cusum = MultinomialCUSUM(P0, cfg)
    adwin, ph, ddm = ADWINScalar(), PageHinkley(), DDMBinary()
    # CUSUM / DDM reference values come from a separate clean calibration
    # stream, never from the monitored rounds.
    for _ in range(cfg.W0):
        cs, ts = gen_round(rng, P_true, pi0, cfg)
        cusum.warmup(cs, ts)
        ddm.warmup(fleet_cond_kl(*_pool_counts(cs, ts, cfg), P0, cfg))

    R = pre + post
    onset = pre if scenario is not None else None
    if scenario is not None:
        Pd = drifted(P_true, scenario, m, seed)
        Pd_full = Pd
        if q is not None and q < cfg.N:
            Pa = np.broadcast_to(P_true, (cfg.N, cfg.L, cfg.M)).copy()
            comp = np.random.default_rng(seed + 7).choice(cfg.N, q, replace=False)
            Pa[comp] = Pd
            Pd = Pa
        else:
            comp = np.arange(cfg.N)
    else:
        comp = np.array([], int)

    sig = {k: {'fog_score': [], 'fog_amax': [], 'fog_has': [], 'agent': [],
               'n_tx': [], 'sent': [], 'deliv': []} for k in dets}
    scal = {k: [] for k in ['MMD-joint', 'MMD-cond', 'CUSUM', 'ADWIN',
                            'Page-Hinkley', 'DDM', 'FleetKL']}
    for r in range(R):
        if pi_schedule is not None:
            pi_r = pi_schedule(r)
        else:
            pi_r = pi0
        if onset is not None and r >= onset:
            P = Pd if attack is None else attack(r - onset, P_true, Pd)
        else:
            P = P_true
        cs, ts = gen_round(rng, P, pi_r, cfg)
        up = link_rng.random(cfg.N) >= drop
        if burst is not None and onset is not None and \
                onset + burst[0] <= r < onset + burst[1]:
            up[:] = False
        for k, d in dets.items():
            out = d.step(cs, ts, up if k != 'Cent-KL' else None)
            for key in sig[k]:
                sig[k][key].append(out[key])
        if not scalars:
            continue
        cnt, pi = pool.step(cs, ts)
        fkl = fleet_cond_kl(cnt, pi, P0, cfg)
        scal['FleetKL'].append(fkl)
        scal['MMD-joint'].append(mmd_joint(cnt, pi0, P0))
        scal['MMD-cond'].append(mmd_conditional(cnt, ctx_weights(pi, cfg), P0))
        scal['CUSUM'].append(cusum.step(cs, ts))
        scal['ADWIN'].append(adwin.update(fkl))
        scal['Page-Hinkley'].append(ph.update(fkl))
        scal['DDM'].append(ddm.update(fkl))

    out = {'onset': onset, 'R': R, 'compromised': comp, 'P0': P0}
    for k, d in dets.items():
        s = {key: np.array(v) for key, v in sig[k].items()
             if keep_agent or key != 'agent'}
        s['sent_KB'] = d.sent / R / 1024
        s['delivered_KB'] = d.delivered / R / 1024
        s['tx_frac'] = d.tx_agent_rounds / (R * cfg.N)
        out[k] = s
    for k, v in scal.items():
        if scalars:
            out[k] = {'score': np.array(v), 'sent_KB': pool.sent / R / 1024,
                      'delivered_KB': pool.sent / R / 1024}
    return out


def _pool_counts(cs, ts, cfg):
    cnt = np.zeros((cfg.L, cfg.M))
    np.add.at(cnt, (cs.ravel(), ts.ravel()), 1)
    return cnt, cnt.sum(-1)


# --------------------------------------------------------------------------
# Detection endpoint, alarm events, delay  (ONE convention everywhere)
# --------------------------------------------------------------------------
def run_starts(raw):
    """Start index of the current run of True values (or -1), along axis 0.
    Works for (R,) and (R,F) boolean arrays."""
    raw = np.asarray(raw, dtype=bool)
    R = raw.shape[0]
    idx = np.arange(R).reshape((R,) + (1,) * (raw.ndim - 1))
    last_false = np.maximum.accumulate(np.where(~raw, idx, -1), axis=0)
    return np.where(raw, last_false + 1, -1)


def stable_alarm(raw, kp):
    """Persistence: stable at r iff raw was true for the last kp rounds.
    Returns (stable bool array, start index of the underlying raw run)."""
    raw = np.asarray(raw, dtype=bool)
    start = run_starts(raw)
    idx = np.arange(raw.shape[0]).reshape((raw.shape[0],) + (1,) * (raw.ndim - 1))
    stable = (start >= 0) & (idx - start + 1 >= kp)
    return stable, start


def fog_raw_alerts(sig, tau_a, tau_l):
    """Eq. (4): alert_f = (fog score > tau_l) OR (any agent in f > tau_a)."""
    return ((sig['fog_score'] > tau_l) | (sig['fog_amax'] > tau_a)) & sig['fog_has']


def endpoint_fog(sig, tau_a, tau_l, kp=2):
    """Actionable endpoint = any fog with a stable (K_p) alert.
    Returns per-round any-fog alarm and per-fog (stable, start) arrays."""
    raw = fog_raw_alerts(sig, tau_a, tau_l)                    # (R,F)
    st, sr = stable_alarm(raw, kp)
    return st.any(1), st, sr


def endpoint_cloud(sig, tau_a, tau_l, tau_g, p=0.30, kp=2):
    """Cloud rule over fogs that reported, with the untrimmed mean of the fog
    scores (Eq. (6) omits the largest one; see exp_cloud_corroboration.py).
    Returns alarm and branch arrays."""
    _, st, _ = endpoint_fog(sig, tau_a, tau_l, kp)
    has = sig['fog_has']
    nrecv = np.maximum(has.sum(1), 1)
    corr = (st & has).sum(1) / nrecv >= p
    mean_s = np.where(has, sig['fog_score'], 0).sum(1) / nrecv
    avg, _ = stable_alarm(mean_s > tau_g, kp)      # same K_p persistence
    return corr | avg, corr, avg


def endpoint_scalar(score, thr, kp=2):
    st, sr = stable_alarm(score > thr, kp)
    return st, st[:, None], sr[:, None]


def count_events(stable_any):
    """Alarm events = rising edges of the stable alarm (each counts once)."""
    a = np.asarray(stable_any, dtype=bool)
    if a.size == 0:
        return 0
    return int(a[0]) + int(np.sum(a[1:] & ~a[:-1]))


def detection_delay(st, sr, onset, kp=2):
    """Delay = r - onset + 1 for the first round r >= onset at which some
    stable alarm holds whose underlying run STARTED at or after onset
    (an alarm already active at onset is not counted as a detection).
    Returns None if not detected (right-censored)."""
    st = st if st.ndim == 2 else st[:, None]
    sr = sr if sr.ndim == 2 else sr[:, None]
    for r in range(onset, st.shape[0]):
        if np.any(st[r] & (sr[r] >= onset)):
            return r - onset + 1
    return None
