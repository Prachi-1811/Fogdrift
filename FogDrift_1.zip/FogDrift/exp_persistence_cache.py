"""K_p persistence on cached summaries (Alg. 1, lines 14-19; Sec. III-G).

    python exp_persistence_cache.py          # ~15 min
    python exp_persistence_cache.py quick    # ~3 min, noisy

The fog re-scores its stored summaries in every round, also when an agent
sends nothing: an agent's score is unchanged until its next summary arrives
(at most T_hb rounds later), and persist_f counts rounds. One anomalous
summary can therefore hold alert_f for K_p = 2 rounds by itself.

Two persistence rules on the same signals:
  rounds   (paper)  persist_f + 1 in every round with alert_f, reset to 0
                    in a round without it
  summaries         persist_f + 1 only in rounds where the alert rests on new
                    evidence (an agent above tau_a whose summary arrived in
                    that round, or the fog score above tau_l in a round in
                    which some member's summary arrived); unchanged in a round
                    with alert_f on cached evidence only; reset to 0 without
                    alert_f. K_p then counts distinct summaries.
Each rule is calibrated on its own: tau_a and tau_l of calibration.json are
scaled by one common factor, bisected so that the any-fog ARL on
10 x 5000 calibration rounds equals 1000; it is then checked on 10 x 5000
held-out rounds.

Reported:
(a) per rule: factor, thresholds, calibration and held-out ARL;
(b) under the paper rule, the share of null alarm events and of detections
    whose K_p-th round rests on cached evidence only;
(c) detection delay, 30 seeds, onset at round 60, both rules at their own
    thresholds.

Outputs: results/persistence_cache.txt, results/persistence_cache.json
"""
import json
import os
import sys
import time
from dataclasses import fields

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
T = 1000
KP = fc.DEFAULT.KP
BURN = 30
ROUNDS = 5000
CAL_SEEDS = list(range(6000, 6010))
VAL_SEEDS = list(range(6100, 6110))
RUN_SEEDS = list(range(6200, 6230))
PRE = 60
if QUICK:
    CAL_SEEDS, VAL_SEEDS, ROUNDS, RUN_SEEDS = CAL_SEEDS[:3], VAL_SEEDS[:3], 1500, RUN_SEEDS[:8]
    print("QUICK MODE: noisy")
T0 = time.time()


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    return fc.Config(**{k: v for k, v in d.items() if k in {f.name for f in fields(fc.Config)}})


CFG = load_cfg()
TH = json.load(open('calibration.json'))[str(T)]['FogDrift']
TA0, TL0 = TH['tau_a'], TH['tau_l']
FOG_OF = np.arange(CFG.N) % CFG.F
UNIFORM = np.full(CFG.L, 1.0 / CFG.L)


def tiny(Pt):
    Pd = Pt.copy()
    Pd[:, 6] += 0.024
    return Pd / Pd.sum(1, keepdims=True)


ATTACKS = [
    ('step m=0.5', dict(m=0.5), 100),
    ('step m=0.15', dict(m=0.15), 100),
    ('10% of agents, m=0.5', dict(m=0.5, q=5), 100),
    ('one agent, m=0.5', dict(m=0.5, q=1), 100),
    ('ramp to 0.5 over 30', dict(m=0.5, attack=lambda r, Pt, Pd:
                                 fc.policy_poison(Pt, 0.5 * min(1, (r + 1) / 30))), 130),
    ('tiny shift (+0.024)', dict(m=0.5, attack=lambda r, Pt, Pd: tiny(Pt)), 100),
]


# --------------------------------------------------------------------------
def stream(seed, rounds, onset=None, m=0.5, q=None, attack=None):
    """Signals of one FogDrift stream plus which agents' summaries arrived."""
    rng = np.random.default_rng(seed)
    Pt = fc.build_P0(rng, CFG)
    P0 = fc.estimate_P0(rng, Pt, UNIFORM, CFG)
    det = fc.HCDD(P0, CFG)
    Pd = None
    if onset is not None:
        Pd = fc.drifted(Pt, 'policy', m, seed)
        if q is not None:
            Pa = np.broadcast_to(Pt, (CFG.N, CFG.L, CFG.M)).copy()
            Pa[np.random.default_rng(seed + 7).choice(CFG.N, q, replace=False)] = Pd
            Pd = Pa
    keys = ('agent', 'fog_score', 'fog_has')
    sig = {k: [] for k in keys + ('new',)}
    for r in range(rounds):
        P = Pt
        if onset is not None and r >= onset:
            P = Pd if attack is None else attack(r - onset, Pt, Pd)
        o = det.step(*fc.gen_round(rng, P, UNIFORM, CFG))
        for k in keys:
            sig[k].append(o[k])
        sig['new'].append(det.fts == det.r)
    return {k: np.array(v) for k, v in sig.items()}


def alerts(s, ta, tl):
    """Raw alert_f (R,F) and whether it rests on new evidence (R,F)."""
    R = s['agent'].shape[0]
    raw = np.zeros((R, CFG.F), bool)
    fresh = np.zeros((R, CFG.F), bool)
    for f in range(CFG.F):
        mem = FOG_OF == f
        a_hi = s['agent'][:, mem] > ta
        l_hi = s['fog_score'][:, f] > tl
        new_any = s['new'][:, mem].any(1)
        raw[:, f] = (a_hi.any(1) | l_hi) & s['fog_has'][:, f]
        fresh[:, f] = raw[:, f] & ((a_hi & s['new'][:, mem]).any(1) | (l_hi & new_any))
    return raw, fresh


def persist_summaries(raw, fresh, kp):
    """Stable alert and run start when persist_f counts new-evidence rounds."""
    R, F = raw.shape
    st = np.zeros((R, F), bool)
    sr = np.full((R, F), -1)
    p = np.zeros(F, int)
    start = np.full(F, -1)
    for r in range(R):
        start = np.where(raw[r] & (start < 0), r, np.where(raw[r], start, -1))
        p = np.where(raw[r], p + fresh[r], 0)
        st[r] = p >= kp
        sr[r] = start
    return st, sr


def endpoint(s, g, rule):
    raw, fresh = alerts(s, TA0 * g, TL0 * g)
    if rule == 'rounds':
        st, sr = fc.stable_alarm(raw, KP)
    else:
        st, sr = persist_summaries(raw, fresh, KP)
    return st, sr, fresh


def arl(streams, g, rule):
    al = [endpoint(fx.trim(s, BURN), g, rule)[0].any(1) for s in streams]
    return fx.arl_of(al)


def calibrate(streams, rule):
    lo, hi = 0.8, 1.6
    for _ in range(30):
        mid = 0.5 * (lo + hi)
        if arl(streams, mid, rule)[0] < T:
            lo = mid
        else:
            hi = mid
    return hi


def cached_share_null(streams, g):
    """Paper rule: share of alarm events whose K_p-th round is cache-only."""
    tot = cache = 0
    for s in streams:
        s = fx.trim(s, BURN)
        st, sr, fresh = endpoint(s, g, 'rounds')
        for f in range(CFG.F):
            r = np.flatnonzero(st[:, f] & ~np.concatenate([[False], st[:-1, f]]))
            tot += len(r)
            cache += int((~fresh[r, f]).sum())
    return cache, tot


def main():
    cal = [stream(s, ROUNDS) for s in CAL_SEEDS]
    log("calibration streams done")
    val = [stream(s, ROUNDS) for s in VAL_SEEDS]
    log("held-out streams done")
    res = {'rules': {}}
    G = {}
    for rule in ('rounds', 'summaries'):
        g = calibrate(cal, rule)
        G[rule] = g
        a_cal = arl(cal, g, rule)
        a_val = arl(val, g, rule)
        lo, hi = fx.poisson_ci(a_val[1], a_val[2])
        res['rules'][rule] = {'factor': g, 'tau_a': TA0 * g, 'tau_l': TL0 * g,
                              'ARL_cal': a_cal[0], 'ARL_val': a_val[0], 'events_val': a_val[1],
                              'lo': lo, 'hi': hi}
        log(f"{rule}: {res['rules'][rule]}")
    c, t = cached_share_null(val, G['rounds'])
    res['null_cached'] = {'cached': c, 'events': t}
    rows = []
    for name, kw, post in ATTACKS:
        d = {r: [] for r in G}
        cached = 0
        for s in RUN_SEEDS:
            sg = stream(s, PRE + post, onset=PRE, **kw)
            for rule, g in G.items():
                st, sr, fresh = endpoint(sg, g, rule)
                dl = fc.detection_delay(st, sr, PRE, KP)
                d[rule].append(dl)
                if rule == 'rounds' and dl is not None:
                    r = PRE + dl - 1
                    hit = st[r] & (sr[r] >= PRE)
                    cached += int(not (fresh[r] & hit).any())
        row = {'attack': name, 'cached_detections': cached}
        for rule in G:
            row[rule] = {'median': fx.med(d[rule]),
                         'detected': sum(x is not None for x in d[rule]), 'n': len(d[rule])}
        rows.append(row)
        log(f"delay {row}")
    res['delay'] = rows
    txt = report(res)
    print(txt)
    open('results/persistence_cache.txt', 'w').write(txt + "\n")
    json.dump(res, open('results/persistence_cache.json', 'w'), indent=2, default=float)


def report(res):
    L = [f"K_p = {KP} persistence on cached summaries. Calibrated edge parameters (edge_params.json); "
         f"thresholds = factor x (tau_a, tau_l) of calibration.json ({TA0:.3f}, {TL0:.4f}), factor "
         f"bisected per rule for ARL0 = {T} on {len(CAL_SEEDS)} x {ROUNDS} calibration rounds, "
         f"checked on {len(VAL_SEEDS)} x {ROUNDS} held-out rounds.",
         "rounds: persist_f counts rounds with alert_f (paper); summaries: it counts only rounds "
         "whose alert rests on a newly arrived summary and holds on cached-only rounds.", "",
         "(a) Calibration",
         f"{'rule':10s} {'factor':>7s} {'tau_a':>7s} {'tau_l':>7s} {'ARL cal':>8s} "
         f"{'held-out ARL [95% CI] (events)':>32s}"]
    for k, a in res['rules'].items():
        ci = f"{a['ARL_val']:.0f} [{a['lo']:.0f}, {a['hi']:.0f}] ({a['events_val']})"
        L.append(f"{k:10s} {a['factor']:7.3f} {a['tau_a']:7.3f} {a['tau_l']:7.4f} "
                 f"{a['ARL_cal']:8.0f} {ci:>32s}")
    n = res['null_cached']
    L += ["", f"(b) Paper rule: {n['cached']} of {n['events']} held-out null alarm events "
          f"({100 * n['cached'] / max(n['events'], 1):.0f}%) become stable on a round with cached "
          "evidence only.", "",
          f"(c) Detection delay, policy poisoning, onset at round {PRE}, {len(RUN_SEEDS)} seeds: "
          "median rounds (detected / runs); cached: detections (paper rule) whose detecting round "
          "rests on cached evidence only",
          f"{'attack':24s} {'rounds (paper)':>16s} {'summaries':>16s} {'cached':>8s}"]
    for r in res['delay']:
        cell = [f"{fx.fmt(r[k]['median'], 1)} ({r[k]['detected']}/{r[k]['n']})"
                for k in ('rounds', 'summaries')]
        L.append(f"{r['attack']:24s} {cell[0]:>16s} {cell[1]:>16s} "
                 f"{r['cached_detections']:>3d}/{r['rounds']['detected']:<3d}")
    return "\n".join(L)


if __name__ == '__main__':
    main()
