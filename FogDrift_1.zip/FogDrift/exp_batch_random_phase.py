"""Batched tuple baselines with onset at a random batch offset.

    python exp_batch_random_phase.py          # ~30 min
    python exp_batch_random_phase.py quick    # ~5 min, noisy

Tables IV-VII report Centralised-Tuples with onset at a batch boundary
(o = 0), its worst case: the first attack data arrive B rounds after onset.
Here every run draws its offset o ~ Uniform{0, ..., B-1} from its seed
(rng(seed + 50000)) and shifts the batch boundaries by o, so onset falls at
a random point of the reporting cycle. Everything else (seeds, harness,
thresholds from calibration.json, which do not depend on the phase) is that
of the original experiment:
  Table IV, Fig. 2   exp_matched_arl.py      CT(B=5), CT(B=10); ARL0 targets
                                              100, 500, 1000, 5000
  Table V            exp_localisation.py     CT(B=5), q = 1, 5, 10
  Table VI           exp_dropout.py          CT(B=5), CT(B=5)+ACK
  Table VII(a)       exp_bandwidth_cap.py    CT(B=5) under the byte cap
  Table VII(b), (c)  exp_deployment_stress.py CT(B=5) (with ACK), fog outage
                                              and heterogeneous workloads
Bytes per round do not depend on the phase and are not repeated.

Outputs: results/batch_random_phase.txt, results/batch_random_phase.json
"""
import json
import os
import sys
import time

import numpy as np

import fogdrift_core as fc
import fogdrift_ext as fx
import exp_matched_arl as ema
import exp_localisation as elo
import exp_dropout as edr
import exp_bandwidth_cap as ebc
import exp_deployment_stress as eds

os.makedirs('results', exist_ok=True)
QUICK = 'quick' in sys.argv[1:]
KP = fc.DEFAULT.KP
N_SEEDS = 6 if QUICK else 30
if QUICK:
    print("QUICK MODE: noisy")
T0 = time.time()
CUR = {}                                   # phase of the run being built, per B


def log(msg):
    print(f"[{(time.time() - T0) / 60:5.1f} min] {msg}", flush=True)


def set_phase(seed):
    rng = np.random.default_rng(seed + 50_000)
    CUR[5] = int(rng.integers(5))
    CUR[10] = int(rng.integers(10))


def med(v):
    x = np.array([np.inf if a is None else a for a in v], float)
    return float(np.median(x))


def summary(v):
    return {'median': med(v), 'detected': sum(x is not None for x in v), 'n': len(v)}


def ct(B, ack=False):
    return lambda P0, cfg: fc.CentralTuples(P0, cfg, B=B, ack=ack, phase=CUR[B])


# ---------------------------------------------------------------- Table IV
def table4(cfg, cal):
    extra = {'CT(B=5)': ct(5), 'CT(B=10)': ct(10)}
    targets = [k for k in ('100', '500', '1000', '5000') if k in cal]
    d = {(sc, det, t): [] for sc in ema.SCENARIOS for det in extra for t in targets}
    offsets = []
    for sc in ema.SCENARIOS:
        for seed in ema.SEEDS[:N_SEEDS]:
            set_phase(seed)
            offsets.append((CUR[5], CUR[10]))
            out = fc.run_stream(seed, scenario=sc, m=ema.M_DRIFT, pre=ema.PRE, post=ema.POST,
                                fd_cfg=cfg, base_dets=False, scalars=False, keep_agent=False,
                                extra=extra)
            for det in extra:
                for t in targets:
                    d[(sc, det, t)].append(ema.delay_of(out, det, cal[t].get(det)))
    log("Table IV done")
    res = {}
    for (sc, det, t), v in d.items():
        res.setdefault(det, {}).setdefault(t, {})[sc] = summary(v)
    for det in extra:
        for t in targets:
            allv = sum((d[(sc, det, t)] for sc in ema.SCENARIOS), [])
            res[det][t]['all'] = summary(allv)
            res[det][t]['all']['ci'] = list(ema.boot_ci(allv))
    o5 = [o[0] for o in offsets]
    res['offsets_B5'] = np.bincount(o5, minlength=5).tolist()
    return res


# ---------------------------------------------------------------- Table V
def table5(cfg, th):
    extra = {'CT(B=5)': ct(5)}
    res = {}
    for q in elo.QS:
        dl, p5, r5, t1 = [], [], [], []
        for seed in elo.SEEDS[:N_SEEDS]:
            set_phase(seed)
            out = fc.run_stream(seed, fd_cfg=cfg, base_dets=False, scalars=False,
                                keep_agent=True, extra=extra, scenario='policy', m=0.5,
                                q=q, pre=60, post=100)
            comp = set(out['compromised'].tolist())
            t = th['CT(B=5)']
            _, st, sr = fc.endpoint_fog(out['CT(B=5)'], t['tau_a'], t['tau_l'], KP)
            x = fc.detection_delay(st, sr, out['onset'], KP)
            dl.append(x)
            if x is None:
                continue
            order = np.argsort(-out['CT(B=5)']['agent'][out['onset'] + x - 1])
            hit = len(set(order[:5].tolist()) & comp)
            p5.append(hit / 5)
            r5.append(hit / q)
            t1.append(float(order[0] in comp))
        res[q] = dict(summary(dl), prec5=float(np.mean(p5)), rec5=float(np.mean(r5)),
                      top1=float(np.mean(t1)))
    log("Table V done")
    return res


# ---------------------------------------------------------------- Table VI
def table6(cfg, th):
    edr.EXTRA = {'CT(B=5)': ct(5), 'CT(B=5)+ACK': ct(5, ack=True)}
    res = {}
    for pi in edr.PIS:
        d = {k: [] for k in edr.EXTRA}
        for seed in edr.SEEDS[:N_SEEDS]:
            set_phase(seed)
            out = edr.run(seed, cfg, scenario='policy', m=0.5, pre=edr.PRE, post=edr.POST,
                          drop=pi)
            for k in d:
                d[k].append(edr.delay(out, k, th))
        res[pi] = {k: summary(v) for k, v in d.items()}
    log("Table VI done")
    return res


# ---------------------------------------------------------------- Table VII(a)
def table7a(cfg, th):
    make0 = ebc.make

    def make(det, P0, c, uplink):
        if det.startswith('CT'):
            B = int(det.split('=')[1].rstrip(')'))
            return fx.CappedCT(P0, c, B, uplink, phase=CUR[B])
        return make0(det, P0, c, uplink)

    ebc.make = make
    res = {}
    for cap in ebc.CAPS:
        v = []
        for seed in ebc.SEEDS[:N_SEEDS]:
            set_phase(seed)
            v.append(ebc.one_run('CT(B=5)', cfg, th['CT(B=5)'], seed, cap)[0])
        res[str(cap)] = summary(v)
    ebc.make = make0
    log("Table VII(a) done")
    return res


# ---------------------------------------------------------------- Table VII(b), (c)
def table7bc(cfg, th):
    make = lambda c: (lambda P0: fc.CentralTuples(P0, c, B=5, ack=True, phase=CUR[5]))
    res = {'outage': {}, 'hetero': None}
    for out in (0, 8, 16):
        v = []
        for seed in eds.SEEDS[:N_SEEDS]:
            set_phase(seed)
            v.append(eds.run_capped(make(cfg), cfg, seed, th['CT(B=5)'],
                                    outage=(0, out) if out else None)[0])
        res['outage'][out] = summary(v)
    v = []
    for seed in eds.SEEDS[:N_SEEDS]:
        set_phase(seed)
        v.append(eds.run_capped(make(cfg), cfg, seed, th['CT(B=5)'], hetero=True)[0])
    res['hetero'] = summary(v)
    log("Table VII(b), (c) done")
    return res


def f(x):
    return 'cens' if not np.isfinite(x) else f"{x:.1f}"


def report(r):
    L = ["Centralised-Tuples with onset at a random batch offset o ~ U{0..B-1} per run "
         f"(rng(seed + 50000)); otherwise the original experiments' seeds, harnesses and "
         f"thresholds. Median delay in rounds (detected/runs), {N_SEEDS} seeds per cell.",
         f"offsets drawn for B = 5 in Table IV runs (counts of o = 0..4): {r['t4']['offsets_B5']}", "",
         "Table IV / Fig. 2: delay by scenario and ARL0 target"]
    for det in ('CT(B=5)', 'CT(B=10)'):
        for t, row in r['t4'][det].items():
            L.append(f"  {det:9s} ARL0={t:>5s}  " + "  ".join(
                f"{sc}: {f(row[sc]['median'])} ({row[sc]['detected']}/{row[sc]['n']})"
                for sc in list(ema.SCENARIOS) + ['all']) +
                f"  all 95% CI [{row['all']['ci'][0]:.1f}, {row['all']['ci'][1]:.1f}]")
    L += ["", "Table V: CT(B=5), policy m = 0.5"]
    for q, row in r['t5'].items():
        L.append(f"  q={q:<3} delay {f(row['median'])} ({row['detected']}/{row['n']})  "
                 f"prec@5 {row['prec5']:.2f}  rec@5 {row['rec5']:.2f}  top-1 {row['top1']:.2f}")
    L += ["", "Table VI: random dropout"]
    for pi, row in r['t6'].items():
        L.append(f"  p_d={pi:<5} " + "  ".join(
            f"{k}: {f(v['median'])} ({v['detected']}/{v['n']})" for k, v in row.items()))
    L += ["", "Table VII(a): per-fog uplink byte cap, CT(B=5)"]
    for cap, v in r['t7a'].items():
        L.append(f"  cap={cap:>5s} KB  {f(v['median'])} ({v['detected']}/{v['n']})")
    L += ["", "Table VII(b): fog outage, CT(B=5)+ACK"]
    for out, v in r['t7bc']['outage'].items():
        L.append(f"  outage={out:<3} {f(v['median'])} ({v['detected']}/{v['n']})")
    v = r['t7bc']['hetero']
    L.append(f"Table VII(c): heterogeneous workloads, CT(B=5)+ACK  {f(v['median'])} "
             f"({v['detected']}/{v['n']})")
    return "\n".join(L)


def main():
    cfg = ema.load_cfg()
    cal = json.load(open('calibration.json'))
    th = cal['1000']
    r = {'t4': table4(cfg, cal), 't5': table5(cfg, th), 't6': table6(cfg, th),
         't7a': table7a(cfg, th), 't7bc': table7bc(cfg, th)}
    txt = report(r)
    print(txt)
    open('results/batch_random_phase.txt', 'w').write(txt + "\n")
    json.dump(r, open('results/batch_random_phase.json', 'w'), indent=1,
              default=lambda o: o if not isinstance(o, np.generic) else o.item())


if __name__ == '__main__':
    main()
