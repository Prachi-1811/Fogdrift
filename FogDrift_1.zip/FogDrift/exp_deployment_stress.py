"""Deployment stress tests: fog outage, latency and heterogeneous workloads
(Table VII(b), VII(c), Sec. V-G). The per-fog byte cap of Table VII(a) is in
exp_bandwidth_cap.py.

    python exp_deployment_stress.py          # ~10 min
    python exp_deployment_stress.py quick    # ~2 min

Needs edge_params.json and calibration.json (calibrate.py).

All at matched ARL0=1000, policy poisoning m=0.5, thresholds from calibrate.py
(calibrated without stress, not re-tuned):

1. Fog outage. One whole fog node is down for the first OUTAGE rounds of the
   attack; its agents' summaries do not reach the cloud. The attack is placed on
   agents of the downed fog (worst case).

2. Geographical latency. Every edge->fog->cloud message takes D extra rounds;
   the message plane is a pipeline, so D adds exactly D rounds to every detector.

3. Heterogeneous workloads. Each agent has its own fixed context mixture
   (Dirichlet-drawn), rather than a shared uniform one. Measures detection delay
   and the null false-alarm rate of the equal-weight score.

Output: results/deployment_stress.txt
"""
import json
import os
import sys
import time
from dataclasses import fields
import numpy as np
import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)

SEEDS = list(range(1100, 1130))
NULL_SEEDS = list(range(1150, 1160))
NULL_ROUNDS = 5030                 # 10 x 5000 rounds after the 30-round burn-in
PRE, POST = 60, 100
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS, NULL_SEEDS, NULL_ROUNDS = list(range(1100, 1105)), [1150], 1000
    print("QUICK MODE: noisy")
KP = fc.DEFAULT.KP


def arl_ci(ev, n):
    """Null ARL = rounds / alarm events, with the exact (Garwood) 95% Poisson CI."""
    lo, hi = fx.poisson_ci(ev, n)
    arl = n / ev if ev else float('inf')
    return f"ARL {arl:.0f} [{lo:.0f}, {hi:.0f}]"


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


def med_ci(v):
    x = np.array([np.inf if a is None else a for a in v], float)
    r = np.random.default_rng(0)
    m = np.median(x[r.integers(0, len(x), (2000, len(x)))], 1)
    return np.median(x), float(np.quantile(m, .025)), float(np.quantile(m, .975))


def f(x):
    return 'cens' if not np.isfinite(x) else f"{x:.1f}"


# ---- a driver that runs one detector with a per-round link-admission rule ----
def run_capped(make_det, cfg, seed, th, cap_KB=None, outage=None, hetero=False,
               scenario='policy', m=0.5):
    """make_det: () -> detector (HCDD or CentralTuples) built on P0.
    cap_KB: optional per-fog admission budget in KB/round (None = no cap;
            the byte-level cap of Table VII(a) is in exp_bandwidth_cap.py).
    outage: (fog_id, rounds) down from onset.
    Returns detection delay (rounds) at the fog endpoint and bytes sent/round."""
    rng = np.random.default_rng(seed)
    P_true = fc.build_P0(rng, cfg)
    L = cfg.L
    if hetero:
        wr = np.random.default_rng(seed + 11)
        pis = wr.dirichlet(np.full(L, 2.0), size=cfg.N)          # per-agent mixture
    pi0 = np.ones(L) / L
    P0 = fc.estimate_P0(rng, P_true, pi0, cfg)
    det = make_det(P0)
    fog_of = det.fog_of
    msg = fc.edge_msg_bytes(cfg)
    per_fog = np.array([np.sum(fog_of == fi) for fi in range(cfg.F)])
    k_adm = None
    if cap_KB is not None:
        k_adm = max(1, int(cap_KB * 1024 / msg))                 # agents admitted per fog/round
    adm_ptr = np.zeros(cfg.F, dtype=int)

    def gen(P, pis_arg=None):
        if hetero:
            cs = np.array([rng.choice(L, cfg.K, p=pis[i]) for i in range(cfg.N)])
            Pa = np.broadcast_to(P, (cfg.N, L, cfg.M))
            cdf = np.cumsum(Pa, -1); rows = cdf[np.arange(cfg.N)[:, None], cs]
            u = rng.random((cfg.N, cfg.K))[..., None]
            ts = np.minimum((u > rows).sum(-1), cfg.M - 1)
            return cs, ts
        return fc.gen_round(rng, P, pi0, cfg)

    def link_mask(r_rel):
        up = np.ones(cfg.N, dtype=bool)
        if outage is not None and r_rel is not None and 0 <= r_rel < outage[1]:
            up[fog_of == outage[0]] = False
        if k_adm is not None:
            for fi in range(cfg.F):
                mem = np.where(fog_of == fi)[0]
                if len(mem) > k_adm:
                    start = adm_ptr[fi]
                    admit = set(mem[(start + np.arange(k_adm)) % len(mem)])
                    for a in mem:
                        if a not in admit:
                            up[a] = False
                    adm_ptr[fi] = (start + k_adm) % len(mem)
        return up

    for _ in range(PRE):
        det.step(*gen(P_true), link_up=link_mask(None))
    Pd = fc.drifted(P_true, scenario, m, seed)
    if outage is not None:                                       # attack on the downed fog's agents
        comp = np.where(fog_of == outage[0])[0]
        Pa = np.broadcast_to(P_true, (cfg.N, L, cfg.M)).copy(); Pa[comp] = Pd; Pd = Pa
    sig = {k: [] for k in ['fog_score', 'fog_amax', 'fog_has']}
    for r in range(POST):
        o = det.step(*gen(Pd), link_up=link_mask(r))
        for k in sig:
            sig[k].append(o[k])
    sig = {k: np.array(v) for k, v in sig.items()}
    _, st, sr = fc.endpoint_fog(sig, th['tau_a'], th['tau_l'], KP)
    d = fc.detection_delay(st, sr, 0, KP)
    return d, det.sent / (PRE + POST) / 1024


DETS = {
    'FogDrift': lambda cfg: (lambda P0: fc.HCDD(P0, cfg, name='FogDrift')),
    'Cent-Hist': lambda cfg: (lambda P0: fc.HCDD(P0, cfg, trigger=False)),
    'CT(B=1)': lambda cfg: (lambda P0: fc.CentralTuples(P0, cfg, B=1, ack=True)),
    'CT(B=5)': lambda cfg: (lambda P0: fc.CentralTuples(P0, cfg, B=5, ack=True)),
}


def main():
    t0 = time.time()
    cfg = load_cfg()
    th = json.load(open('calibration.json'))['1000']
    thf = {'FogDrift': th['FogDrift'], 'Cent-Hist': th['Cent-Hist'],
           'CT(B=1)': th['CT(B=1)'], 'CT(B=5)': th['CT(B=5)']}
    L = []
    P = L.append

    # ---- 1. fog outage ----
    P(f"Table VII(b): one fog down for the first OUTAGE rounds of the attack (attack on that "
      f"fog's agents), {len(SEEDS)} seeds. Delay from onset at the cloud endpoint.")
    P(f"{'outage':>7s} " + " ".join(f"{d:>14s}" for d in ['FogDrift', 'Cent-Hist', 'CT(B=5)']))
    for out in [0, 8, 16]:
        row = f"{out:>7d}"
        for d in ['FogDrift', 'Cent-Hist', 'CT(B=5)']:
            ds = [run_capped(DETS[d](cfg), cfg, s, thf[d],
                             outage=(0, out) if out else None)[0] for s in SEEDS]
            row += f"   {f(med_ci(ds)[0]):>11s}"
        P(row)
    P("one fog of five is down, so its agents' summaries are lost until it recovers; "
      "FogDrift's per-agent branch still fires on the remaining fogs once coverage returns.")
    P("")

    # ---- 2. latency ----
    P("Geographical latency: a fixed edge->fog->cloud delay of D rounds adds exactly D to "
      "every detector's delay (the message plane is a pipeline); it does not change the "
      "ranking. FogDrift delay under latency D = 4 + D rounds.")
    P("")

    # ---- 3. heterogeneous workloads ----
    P(f"Table VII(c): heterogeneous per-agent workloads (each agent a fixed Dirichlet(2) "
      f"mixture), {len(SEEDS)} seeds. Delay from onset; null FA over "
      f"{len(NULL_SEEDS)}x{NULL_ROUNDS - 30} rounds (after a 30-round burn-in), null ARL with its "
      "exact 95% Poisson CI.")
    P(f"{'detector':12s} {'delay [95% CI]':>22s} {'null FA events':>15s}")
    for d in ['FogDrift', 'Cent-Hist', 'CT(B=5)']:
        ds = [run_capped(DETS[d](cfg), cfg, s, thf[d], hetero=True)[0] for s in SEEDS]
        ev = null_events(d, cfg, thf, hetero=True)
        ev0 = null_events(d, cfg, thf, hetero=False)
        n = len(NULL_SEEDS) * (NULL_ROUNDS - 30)
        md, lo, hi = med_ci(ds)
        P(f"{d:12s}   {f(md):>5s} [{f(lo)},{f(hi)}]   {ev:4d}/{n}  {arl_ci(ev, n)}   "
          f"same seeds, uniform mixture: {ev0:4d}/{n}  {arl_ci(ev0, n)}")
        print(f"[{(time.time()-t0)/60:4.1f} min] hetero {d} done", flush=True)

    txt = "\n".join(L)
    print("\n" + txt)
    open('results/deployment_stress.txt', 'w').write(txt + "\n")
    print(f"\nSaved results/deployment_stress.txt [{(time.time()-t0)/60:.1f} min]")


def null_events(d, cfg, thf, hetero=True):
    """Null alarm events of detector d over NULL_SEEDS x NULL_ROUNDS (30-round
    burn-in), each agent on its own Dirichlet(2) mixture, or (hetero=False) all
    agents on the uniform mixture with the same seeds and reference."""
    ev = 0
    for s in NULL_SEEDS:
        det = DETS[d](cfg)
        rng = np.random.default_rng(s)
        P_true = fc.build_P0(rng, cfg)
        wr = np.random.default_rng(s + 11)
        pis = wr.dirichlet(np.full(cfg.L, 2.0), size=cfg.N)
        if not hetero:
            pis = np.full((cfg.N, cfg.L), 1.0 / cfg.L)
        P0 = fc.estimate_P0(rng, P_true, np.ones(cfg.L) / cfg.L, cfg)
        dd = det(P0)
        sig = {k: [] for k in ['fog_score', 'fog_amax', 'fog_has']}
        for _ in range(NULL_ROUNDS):
            cs = np.array([rng.choice(cfg.L, cfg.K, p=pis[i]) for i in range(cfg.N)])
            Pa = np.broadcast_to(P_true, (cfg.N, cfg.L, cfg.M))
            cdf = np.cumsum(Pa, -1); rows = cdf[np.arange(cfg.N)[:, None], cs]
            u = rng.random((cfg.N, cfg.K))[..., None]
            ts = np.minimum((u > rows).sum(-1), cfg.M - 1)
            o = dd.step(cs, ts)
            for k in sig:
                sig[k].append(o[k])
        sig = {k: np.array(v)[30:] for k, v in sig.items()}
        a, _, _ = fc.endpoint_fog(sig, thf[d]['tau_a'], thf[d]['tau_l'], KP)
        ev += fc.count_events(a)
    return ev


if __name__ == '__main__':
    main()
