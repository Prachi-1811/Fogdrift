"""Link dropout and burst loss (Table VI, Sec. V-F).

    python exp_dropout.py          # ~20 min
    python exp_dropout.py quick    # ~2 min (sanity only)

Needs edge_params.json and calibration.json (calibrate.py).

Compared on the same event stream, thresholds from calibrate.py:
  FogDrift       event-triggered summaries, edge retries until ACK
  Cent-Hist      summary every round, retries until ACK
  CT(B=1|5)      tuples every B rounds, fire-and-forget (lost tuples are gone)
  CT(B=1|5)+ACK  undelivered tuples are buffered and retransmitted
Link model: each edge->fog message is lost independently with probability p_d
(random dropout; `pi` in the code), or all links are down for 16 rounds
(burst outage). When a link fails the edge still observes its own tool calls;
only the message is lost. Thresholds are calibrated at p_d = 0 and NOT re-tuned;
the null false-alarm rate under dropout is measured separately.

Bandwidth columns:
  sent      = every byte put on the uplink, including lost messages,
              retransmissions and ACKs (what the network actually carries)
  delivered = bytes that reached the fog/cloud
Outputs: results/dropout.txt, results/dropout.json,
         results/dropout_delay.png, results/dropout_bandwidth.png
"""
import json
import os
import sys
import time
from dataclasses import fields
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fogdrift_core as fc
import fogdrift_ext as fx

os.makedirs('results', exist_ok=True)

SEEDS = list(range(400, 430))
NULL_SEEDS = list(range(450, 460))
NULL_ROUNDS = 5030                 # 10 x 5000 rounds after the 30-round burn-in
PIS = [0.0, 0.25, 0.50, 0.75]
BURSTS = {'outage at onset [0,16)': (0, 16), 'outage after onset [5,21)': (5, 21)}
PRE, POST = 60, 100
if len(sys.argv) > 1 and sys.argv[1] == 'quick':
    SEEDS, NULL_SEEDS, NULL_ROUNDS = list(range(400, 405)), [450], 1000
    print("QUICK MODE: numbers are noisy")
KP = fc.DEFAULT.KP
DETS = ['FogDrift', 'Cent-Hist', 'CT(B=1)', 'CT(B=1)+ACK', 'CT(B=5)', 'CT(B=5)+ACK']
# ACK variants behave exactly like their plain version when nothing is lost,
# so they use the same pi = 0 thresholds.
TH_KEY = {'FogDrift': 'FogDrift', 'Cent-Hist': 'Cent-Hist', 'CT(B=1)': 'CT(B=1)',
          'CT(B=1)+ACK': 'CT(B=1)', 'CT(B=5)': 'CT(B=5)', 'CT(B=5)+ACK': 'CT(B=5)'}


def load_cfg():
    d = json.load(open('edge_params.json'))['config']
    names = {f.name for f in fields(fc.Config)}
    return fc.Config(**{k: v for k, v in d.items() if k in names})


EXTRA = {
    'Cent-Hist': lambda P0, cfg: fc.HCDD(P0, cfg, trigger=False, name='Cent-Hist'),
    'CT(B=1)': lambda P0, cfg: fc.CentralTuples(P0, cfg, B=1),
    'CT(B=1)+ACK': lambda P0, cfg: fc.CentralTuples(P0, cfg, B=1, ack=True),
    'CT(B=5)': lambda P0, cfg: fc.CentralTuples(P0, cfg, B=5),
    'CT(B=5)+ACK': lambda P0, cfg: fc.CentralTuples(P0, cfg, B=5, ack=True),
}


def run(seed, cfg, **kw):
    return fc.run_stream(seed, fd_cfg=cfg, base_dets=False, scalars=False,
                         keep_agent=False, extra=EXTRA, **kw)


def arl_ci(ev, n):
    """Null ARL = rounds / alarm events, with the exact (Garwood) 95% Poisson CI."""
    lo, hi = fx.poisson_ci(ev, n)
    arl = n / ev if ev else float('inf')
    return f"ARL {arl:.0f} [{lo:.0f}, {hi:.0f}]"


def per_round(cum):
    c = np.asarray(cum, float)
    return np.diff(np.concatenate([[0.0], c])) / 1024


def delay(out, d, th):
    t = th[TH_KEY[d]]
    _, st, sr = fc.endpoint_fog(out[d], t['tau_a'], t['tau_l'], KP)
    return fc.detection_delay(st, sr, out['onset'], KP)


def med(v):
    x = np.array([np.inf if a is None else a for a in v], float)
    return float(np.median(x))


def boot(v, B=2000):
    x = np.array([np.inf if a is None else a for a in v], float)
    r = np.random.default_rng(0)
    m = np.median(x[r.integers(0, len(x), (B, len(x)))], 1)
    return float(np.quantile(m, .025)), float(np.quantile(m, .975))


def f(v):
    return 'cens' if not np.isfinite(v) else f"{v:.1f}"


def draw_f10(data):
    """data[detector][pi] = [bytes sent per round before onset (KB), median delay]."""
    from matplotlib.ticker import FuncFormatter, NullFormatter
    plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})
    fig, ax = plt.subplots(figsize=(7.5, 5))
    label_pi = {'FogDrift': (6, -13), 'CT(B=5)+ACK': (0, 7), 'CT(B=1)+ACK': (0, 7)}
    for d, mk in zip(DETS, 'o^sDvP'):
        pts = [data[d][str(pi)] for pi in PIS]
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        ax.plot(xs, ys, marker=mk, label=d, ms=7 if d == 'FogDrift' else 5,
                lw=2 if d == 'FogDrift' else 1.2)
        if d in label_pi:
            for j, (x, y, pi) in enumerate(zip(xs, ys, PIS)):
                off = label_pi[d] if d != 'CT(B=1)+ACK' else ((0, 7) if j % 2 else (0, -13))
                ax.annotate(f"$\\pi$={pi:g}", (x, y), xytext=off,
                            textcoords='offset points', fontsize=7, ha='center')
    ax.set_xscale('log')
    ax.set_xticks([2, 3, 5, 10, 15]); ax.xaxis.set_minor_formatter(NullFormatter())
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}"))
    ax.set_ylim(1, 7)
    ax.set_xlabel('Bytes sent per round before the attack, incl. lost, retransmitted and ACK (KB, log)')
    ax.set_ylabel('Median detection delay (rounds)')
    ax.grid(True, which='both', alpha=.3, ls='--')
    ax.legend(fontsize=8, loc='lower right', ncol=2)
    plt.tight_layout(); plt.savefig('results/dropout_bandwidth.png', dpi=200)


def main():
    t0 = time.time()
    cfg = load_cfg()
    th = json.load(open('calibration.json'))['1000']
    L = []
    P = L.append

    # ---- random dropout, drift ----
    res = {pi: {d: {'delay': [], 's0': [], 's1': [], 'd0': [], 'd1': []} for d in DETS}
           for pi in PIS}
    for pi in PIS:
        for seed in SEEDS:
            out = run(seed, cfg, scenario='policy', m=0.5, pre=PRE, post=POST, drop=pi)
            on = out['onset']
            for d in DETS:
                r = res[pi][d]
                r['delay'].append(delay(out, d, th))
                s, dl = per_round(out[d]['sent']), per_round(out[d]['deliv'])
                r['s0'].append(s[:on].mean()); r['s1'].append(s[on:].mean())
                r['d0'].append(dl[:on].mean()); r['d1'].append(dl[on:].mean())
        print(f"[{(time.time()-t0)/60:4.1f} min] dropout pi={pi} done", flush=True)

    # ---- null false alarms under dropout ----
    nullfa = {pi: {d: [0, 0] for d in DETS} for pi in PIS}
    for pi in PIS:
        for seed in NULL_SEEDS:
            out = run(seed, cfg, scenario=None, pre=NULL_ROUNDS, post=0, drop=pi)
            for d in DETS:
                t = th[TH_KEY[d]]
                a = fc.endpoint_fog({k: v[30:] for k, v in out[d].items()
                                     if isinstance(v, np.ndarray)},
                                    t['tau_a'], t['tau_l'], KP)[0]
                nullfa[pi][d][0] += fc.count_events(a)
                nullfa[pi][d][1] += len(a)
        print(f"[{(time.time()-t0)/60:4.1f} min] null pi={pi} done", flush=True)

    P(f"Table VI: random link dropout, policy poisoning m=0.5, matched ARL0=1000 "
      f"(thresholds calibrated at pi=0), {len(SEEDS)} seeds")
    P("delay = median rounds [bootstrap 95% CI] (detected/runs); KB per round: "
      "sent = all bytes on the uplink incl. lost, retransmitted and ACK; deliv = reached the fog")
    P(f"null FA = alarm events / rounds on {len(NULL_SEEDS)}x{NULL_ROUNDS - 30} null rounds (after a "
      f"30-round burn-in) under the same dropout, and the null ARL with its exact 95% Poisson CI")
    hdr = f"{'pi':>5s} {'detector':12s} {'delay [95% CI]':>22s} {'det':>7s} " \
          f"{'sent pre':>9s} {'deliv pre':>9s} {'sent att':>9s} {'deliv att':>9s} {'null FA':>12s} {'null ARL [95% CI]':>22s}"
    P(hdr)
    for pi in PIS:
        for d in DETS:
            r = res[pi][d]
            lo, hi = boot(r['delay'])
            ndet = sum(x is not None for x in r['delay'])
            ev, n = nullfa[pi][d]
            P(f"{pi:5.2f} {d:12s} {f(med(r['delay'])):>6s} [{f(lo):>5s}, {f(hi):>5s}] "
              f"{ndet:3d}/{len(r['delay']):<3d} {np.mean(r['s0']):9.2f} {np.mean(r['d0']):9.2f} "
              f"{np.mean(r['s1']):9.2f} {np.mean(r['d1']):9.2f} {ev:4d}/{n:<6d} {arl_ci(ev, n)}")
        P("")

    # ---- burst outages ----
    P(f"Burst loss (Sec. V-F): 16-round outage of ALL links, otherwise no loss, {len(SEEDS)} seeds")
    P("delay from attack onset; 'peak' = largest bytes sent in one round after the outage "
      "ends; 'after' = mean bytes sent per round in the 10 rounds after the outage")
    P(f"{'scenario':26s} {'detector':12s} {'delay [95% CI]':>22s} {'det':>7s} "
      f"{'steady':>8s} {'after':>8s} {'peak':>8s}")
    burst = {}
    for name, (b0, b1) in BURSTS.items():
        acc = {d: {'delay': [], 'steady': [], 'after': [], 'peak': []} for d in DETS}
        for seed in SEEDS:
            out = run(seed, cfg, scenario='policy', m=0.5, pre=PRE, post=POST,
                      burst=(b0, b1))
            on = out['onset']
            for d in DETS:
                a = acc[d]
                a['delay'].append(delay(out, d, th))
                s = per_round(out[d]['sent'])
                a['steady'].append(s[:on].mean())
                a['after'].append(s[on + b1:on + b1 + 10].mean())
                a['peak'].append(s[on + b1:on + b1 + 10].max())
        burst[name] = acc
        for d in DETS:
            a = acc[d]
            lo, hi = boot(a['delay'])
            ndet = sum(x is not None for x in a['delay'])
            P(f"{name:26s} {d:12s} {f(med(a['delay'])):>6s} [{f(lo):>5s}, {f(hi):>5s}] "
              f"{ndet:3d}/{len(a['delay']):<3d} {np.mean(a['steady']):8.2f} "
              f"{np.mean(a['after']):8.2f} {np.mean(a['peak']):8.2f}")
        P("")
        print(f"[{(time.time()-t0)/60:4.1f} min] {name} done", flush=True)

    txt = "\n".join(L)
    print("\n" + txt)
    open('results/dropout.txt', 'w').write(txt + "\n")

    # delay and detection rate vs pi
    plt.rcParams.update({'font.size': 11, 'font.family': 'serif'})
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.2))
    for d, mk in zip(DETS, 'o^sDvP'):
        dl = [med(res[pi][d]['delay']) for pi in PIS]
        rt = [100 * np.mean([x is not None for x in res[pi][d]['delay']]) for pi in PIS]
        a1.plot(PIS, [v if np.isfinite(v) else np.nan for v in dl], marker=mk, label=d)
        a2.plot(PIS, rt, marker=mk, label=d)
    a1.set_xlabel(r'Link dropout probability $\pi$'); a1.set_ylabel('Median delay (rounds)')
    a2.set_xlabel(r'Link dropout probability $\pi$'); a2.set_ylabel('Detected within 100 rounds (%)')
    a2.set_ylim(0, 105)
    for a in (a1, a2):
        a.grid(alpha=.3, ls='--'); a.set_xticks(PIS)
    a1.legend(fontsize=8)
    plt.tight_layout(); plt.savefig('results/dropout_delay.png', dpi=200)

    # bytes sent before the attack vs delay, one point per pi
    json.dump({d: {str(pi): [float(np.mean(res[pi][d]['s0'])), med(res[pi][d]['delay'])]
                   for pi in PIS} for d in DETS}, open('results/dropout.json', 'w'), indent=1)
    draw_f10({d: {str(pi): [float(np.mean(res[pi][d]['s0'])), med(res[pi][d]['delay'])]
                  for pi in PIS} for d in DETS})
    print(f"\nSaved results/dropout.txt, dropout.json, dropout_delay.png, dropout_bandwidth.png "
          f"[{(time.time()-t0)/60:.1f} min]")


if __name__ == '__main__':
    main()
